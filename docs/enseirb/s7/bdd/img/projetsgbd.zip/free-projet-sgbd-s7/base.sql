CREATE DATABASE handball CHARACTER SET 'utf8';

USE handball;


CREATE TABLE Club (
    num_club SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    PRIMARY KEY(num_club)
)
ENGINE=InnoDB;

CREATE TABLE Categorie (
    num_categorie SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nom_categorie VARCHAR(40) NOT NULL,
    PRIMARY KEY(num_categorie)
)
ENGINE=InnoDB;

CREATE TABLE Personne (
    num_personne SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nom VARCHAR(40) NOT NULL,
    prenom VARCHAR(40) NOT NULL,
    date_naissance DATE NOT NULL,
    adresse VARCHAR(100),
    date_adhesion DATE NOT NULL,
    fonction VARCHAR(30),
    num_club SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY(num_personne),
    CONSTRAINT fk_personne_num_club FOREIGN KEY (num_club) REFERENCES Club(num_club) ON DELETE CASCADE
)
ENGINE=InnoDB;

CREATE TABLE Equipe (
    num_equipe SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    num_entraineur SMALLINT UNSIGNED NOT NULL,
    num_categorie SMALLINT UNSIGNED NOT NULL,
    niveau SMALLINT UNSIGNED NOT NULL,
    num_club SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY(num_equipe),
    CONSTRAINT fk_num_categorie FOREIGN KEY (num_categorie) REFERENCES Categorie(num_categorie) ON DELETE CASCADE,
    CONSTRAINT fk_num_club FOREIGN KEY (num_club) REFERENCES Club(num_club) ON DELETE CASCADE,
    CONSTRAINT fk_num_entraineur FOREIGN KEY (num_entraineur) REFERENCES Personne(num_personne) ON DELETE CASCADE
)
ENGINE=InnoDB;

CREATE TABLE Joueur (
    num_licence SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT UNIQUE,
    num_equipe SMALLINT UNSIGNED NOT NULL,
    num_joueur SMALLINT UNSIGNED NOT NULL UNIQUE,
    CONSTRAINT fk_num_equipe FOREIGN KEY (num_equipe) REFERENCES Equipe(num_equipe) ON DELETE CASCADE,
    CONSTRAINT fk_num_joueur FOREIGN KEY (num_joueur) REFERENCES Personne(num_personne) ON DELETE CASCADE
)
ENGINE=InnoDB;

CREATE TABLE Rencontre (
    num_rencontre SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    date_rencontre DATE NOT NULL,
    num_equipe_1 SMALLINT UNSIGNED NOT NULL,
    num_equipe_2 SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY(num_rencontre),
    CONSTRAINT fk_rencontre_num_equipe_1 FOREIGN KEY (num_equipe_1) REFERENCES Equipe(num_equipe) ON DELETE CASCADE,
    CONSTRAINT fk_rencontre_num_equipe_2 FOREIGN KEY (num_equipe_2) REFERENCES Equipe(num_equipe) ON DELETE CASCADE
)
ENGINE=InnoDB;

CREATE TABLE Action (
    num_joueur SMALLINT UNSIGNED NOT NULL,
    num_rencontre SMALLINT UNSIGNED NOT NULL,
    score SMALLINT UNSIGNED NOT NULL,
    faute SMALLINT UNSIGNED NOT NULL,
    titulaire SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (num_joueur, num_rencontre),
    CONSTRAINT fk_action_num_rencontre FOREIGN KEY (num_rencontre) REFERENCES Rencontre(num_rencontre) ON DELETE CASCADE,
    CONSTRAINT fk_action_num_joueur FOREIGN KEY (num_joueur) REFERENCES Personne(num_personne) ON DELETE CASCADE
)
ENGINE=InnoDB;

CREATE TABLE Erreur (
    num_erreur SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    msg_erreur VARCHAR(200) UNIQUE
)
ENGINE=InnoDB;

INSERT INTO Erreur (msg_erreur) VALUE ('Nombre incorrect de joueurs dans une equipe');
INSERT INTO Erreur (msg_erreur) VALUE ('Action d un Joueur qui n est pas dans une Equipe ayant participe a la Rencontre');
INSERT INTO Erreur (msg_erreur) VALUE ('Une equipe ne peut pas s affronter elle-meme lors d une Rencontre');
INSERT INTO Erreur (msg_erreur) VALUE ('Il doit y avoir 14 titulaires par Rencontre');
INSERT INTO Erreur (msg_erreur) VALUE ('La date de la Rencontre doit être passee ou aujourd hui');
INSERT INTO Erreur (msg_erreur) VALUE ('Les deux equipes s affrontant ne sont pas dans la meme categorie');