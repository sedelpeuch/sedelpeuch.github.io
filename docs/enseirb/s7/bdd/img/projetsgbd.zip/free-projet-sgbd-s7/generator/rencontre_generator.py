#!/usr/bin/env python3
# coding: utf-8

import random
import datetime

"""
Fichier générant un fichier csv
d'un nombre fixé de rencontres
"""


class rencontre:
    """
    une rencontre
    """

    def __init__(self, num_r, date, e1, e2):
        self.num_r = num_r
        self.date = date
        self.num_e1 = e1
        self.num_e2 = e2

    def print(self):
        print("num_r : {3}\ndate : {0}\ne1 : {1}\ne2 : {2}".format(self.date, self.num_e1, self.num_e2, self.num_r))


def creer_rencontre(num_r, e1, e2):
    j = random.randint(1, 28)
    m = random.randint(1, 11)
    a = random.randint(2017, 2020)
    today_day = int(datetime.datetime.today().strftime('%d'))
    if a == 2020 and m == 12 and j > today_day:
        j = today_day
    date = str(a) + "-" + str(m).zfill(2) + "-" + str(j).zfill(2)
    return rencontre(num_r, date, e1.num_e, e2.num_e)


def is_in_cate(i, e):
    if e.num_cate == i:
        return True
    return False


def equipe_par_cate(equipe_list, nb_cate):
    final = []
    for i in range(nb_cate):
        final.append([])
    for i in range(1, nb_cate + 1):
        for e in equipe_list:
            if e.num_cate == i:
                final[i - 1].append(e)
    return final


def creer_n_rencontre(equipe_list, nb_cate, n):
    equipe_cate = equipe_par_cate(equipe_list, nb_cate)
    renc_list = []
    i = 1
    for cate in equipe_cate:
        for _ in range(n):
            num_r = i
            e1 = random.choice(cate)
            e2 = random.choice(cate)
            while (e1 == e2) or (e1.num_club == e2.num_club):
                e2 = random.choice(cate)
            renc_list.append(creer_rencontre(num_r, e1, e2))
            i += 1;
    return renc_list
