# coding: utf-8


def gen_n_club(n):
    """
    retourne une liste [1, 2, ...,  n]
    """
    return list(range(1, n + 1))