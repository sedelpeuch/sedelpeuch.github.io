#!/usr/bin/env python3
# coding: utf-8

import random
import csv

"""
Creer fichier csv d'un nombre defini de membres"""

def creer_membre():
    j = random.randint(1, 29)
    m = random.randint(1, 12)
    a = random.randint(1980, 2010)
    date = str(j) + "/" + str(m) + "/" + str(a)
    return [date]

def creer_n_membres(n):
    liste_membres = []
    for _ in range(n):
        liste_membres.append(creer_membre())
    return liste_membres

def creer_csv(n):
    liste_membres = creer_n_membres(n)
    with open("membres.csv", "w") as csv_file:
        writer = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
        writer.writerow(["date_adhesion"])
        for membre in liste_membres:
            writer.writerow(membre)
