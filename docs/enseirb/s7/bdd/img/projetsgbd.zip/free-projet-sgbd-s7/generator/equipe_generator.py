# coding: utf-8

import random


class equipe:
    def __init__(self, num_e, num_coach, num_cate, niveau, num_club):
        self.num_e = num_e
        self.num_coach = num_coach
        self.num_cate = num_cate
        self.niveau = niveau
        self.num_club = num_club


def gen_equipe(num_e,num_coach, nb_cate, num_club):
    num_cate = random.randint(1, nb_cate)
    return equipe(num_e,num_coach, num_cate, 1, num_club)

def gen_n_equipe(coach_list, nb_cate):
    final_list = []
    for i, coach in enumerate(coach_list):
        used_cate = []
        final_list.append(gen_equipe(i+1, coach.num_p, nb_cate, coach.num_club))
    final_list = correct_niv(final_list)
    return final_list

def correct_niv(equipe_list):
    equipe = [equipe_list[0]]
    for e in equipe_list[1:]:
        for added_e in equipe:
            if e.num_cate == added_e.num_cate and e.num_club == added_e.num_club:
                e.niveau += 1
        equipe.append(e)
    return equipe