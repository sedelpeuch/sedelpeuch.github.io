# coding: utf-8


class joueur:
    def __init__(self, num_joueur, num_equipe):
        self.num_joueur = num_joueur
        self.num_equipe = num_equipe


def gen_joueur(num_joueur, num_equipe):
    return joueur(num_joueur, num_equipe)

def gen_n_joueur(pers_list):
    joueur_list = []
    for club in pers_list:
        for equipe in club:
            for p in (equipe):
                if (p.num_equipe != None):
                    joueur_list.append(gen_joueur(p.num_p, p.num_equipe))
    return joueur_list