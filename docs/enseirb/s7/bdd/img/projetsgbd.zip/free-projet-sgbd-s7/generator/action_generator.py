import random

class action:
    def __init__(self,num_j,num_r,score,faute,titu):
        self.num_j = num_j
        self.num_r = num_r
        self.score = score
        self.faute = faute
        self.titu = titu
    def print(self):
        print("num_j : {0} num_r : {1} score : {2}, faute : {3}, titu = {4}\n".format(self.num_j, self.num_r, self.score, self.faute, self.titu))

def gen_action(num_j, num_r, titu):
    score = 0
    faute = 0
    if titu == 1:
        score = random.randint(0, 5)
        faute = random.randint(0, 3)
    return action(num_j, num_r, score, faute, titu)

def joueur_equipe_list(joueur_list, num_equipe):
    equipe = []
    for j in joueur_list:
        if j.num_equipe == num_equipe:
            equipe.append(j)
    return equipe

def gen_n_action(joueur_list, rencontre_list):
    action_list = []
    for r in rencontre_list:
        e1 = joueur_equipe_list(joueur_list, r.num_e1)
        e2 = joueur_equipe_list(joueur_list, r.num_e2)
        tituE1 = random.sample(e1, k=7)
        tituE2 = random.sample(e2, k=7)
        for j in e1:
            titu = 0
            if j in tituE1:
                titu = 1
            action_list.append(gen_action(j.num_joueur, r.num_r, titu))
        for j in e2:
            titu = 0
            if j in tituE2:
                titu = 1
            action_list.append(gen_action(j.num_joueur, r.num_r, titu))
    return action_list


