# coding: utf-8

import club_generator
import personne_generator
import equipe_generator
import joueur_generator
import rencontre_generator
import action_generator

import csv


def create_coach_list(list_pers):
    coach = [list_pers[0][0][0]]
    for club in list_pers:
        for equipe in club:
            for p in equipe:
                if p.num_equipe != coach[-1].num_equipe and p.num_equipe != None:
                    coach.append(p)
    return coach


def create_csv_club(num_club_list):
    with open("generated_csv_file/Club.csv", "w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["num_club"])
        for num in num_club_list:
            writer.writerow([str(num)])
    return


def create_csv_personne(pers_list):
    with open("generated_csv_file/Personne.csv", "w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["nom", "prenom", "date_naissance", "adresse", "date_adhesion", "fonction", "num_club"])
        for club in pers_list:
            for equipe in club:
                for p in equipe:
                    nom = p.nom
                    prenom = p.prenom
                    date = p.date_naissance
                    adresse = p.adresse
                    adhesion = p.date_adh
                    fonc = p.fonction
                    num_c = str(p.num_club)
                    writer.writerow([nom, prenom, date, adresse, adhesion, fonc, num_c])
    return


def create_csv_equipe(equipe_list):
    with open("generated_csv_file/Equipe.csv", "w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["num_equipe", "num_entraineur", "num_categorie", "niveau", "num_club"])
        for e in equipe_list:
            num_e = str(e.num_e)
            num_coach = str(e.num_coach)
            num_cate = str(e.num_cate)
            niveau = str(e.niveau)
            num_club = str(e.num_club)
            writer.writerow([num_e,     num_coach, num_cate, niveau, num_club])
    return


def create_csv_joueur(joueur_list):
    with open("generated_csv_file/Joueur.csv", "w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["num_equipe", "num_joueur"])
        for j in joueur_list:
            num_e = str(j.num_equipe)
            num_j = str(j.num_joueur)
            writer.writerow([num_j, num_e])

    return


def create_csv_rencontre(rencontre_list):
    with open("generated_csv_file/Rencontre.csv", "w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["date_rencontre", "num_equipe_1", "num_equipe_2"])
        for r in rencontre_list:
            date_r = r.date
            num_e1 = str(r.num_e1)
            num_e2 = str(r.num_e2)
            writer.writerow([date_r, num_e1, num_e2])
    return


def create_csv_action(action_list):
    with open("generated_csv_file/Action.csv", "w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["num_joueur", "num_rencontre", "score", "faute", "titulaire"])
        for a in action_list:
            num_j = str(a.num_j)
            num_r = str(a.num_r)
            score = str(a.score)
            faute = str(a.faute)
            titu = str(a.titu)
            writer.writerow([num_j, num_r, score, faute, titu])

    return

def create_csv_categorie():
    with open("generated_csv_file/Categorie.csv","w") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["nom_categorie"])
        writer.writerow(["Poussin"])
        writer.writerow(["Benjamin"])
        writer.writerow(["Minime"])
        writer.writerow(["Cadet"])
        writer.writerow(["Junior"])
        writer.writerow(["Senior"])

    return

def create_csv(num_club_list, pers_list, equipe_list, joueur_list, rencontre_list, action_list):
    create_csv_club(num_club_list)
    create_csv_personne(pers_list)
    create_csv_equipe(equipe_list)
    create_csv_joueur(joueur_list)
    create_csv_rencontre(rencontre_list)
    create_csv_action(action_list)
    create_csv_categorie()


def main():
    print("[GENERATEUR DE DONNEES]\n")
    print("INFO :")
    print("\t- un club contient entre 1 et 5 équipes")
    print("\t- une équipe contient entre 7 et 15 joueurs\n\n")

    n_club = int(input("Combien d'équipes voulez vous générer : "))
    n_ren = int(input("Combien de rencontres par catégorie voulez vous générer : "))

    num_club_list = club_generator.gen_n_club(n_club)
    nb_cate = 5
    pers_list = personne_generator.creer_n_club(len(num_club_list))
    coach_list = create_coach_list(pers_list)
    equipe_list = equipe_generator.gen_n_equipe(coach_list, nb_cate)
    joueur_list = joueur_generator.gen_n_joueur(pers_list)
    rencontre_list = rencontre_generator.creer_n_rencontre(equipe_list, nb_cate, n_ren)
    action_list = action_generator.gen_n_action(joueur_list, rencontre_list)
    create_csv(num_club_list, pers_list, equipe_list, joueur_list, rencontre_list, action_list)

    print("\n")
    print("Fichiers csv générer dans 'generated_csv_file'")
main()
