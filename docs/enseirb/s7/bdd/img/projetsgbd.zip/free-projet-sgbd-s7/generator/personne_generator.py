# coding: utf-8


import random

"""
Fichier qui creer un fichier csv
avec un nombre defini de club.
Un club contient entre 1 et 5 equipes
Une equipe contient entre 7 et 15 joueurs
"""


liste_prenoms = ['louis',
                 'gabriel',
                 'léo',
                 'maël',
                 'paul',
                 'hugo',
                 'valentin',
                 'gabin',
                 'arthur',
                 'théo',
                 'jules',
                 'lucas',
                 'sacha',
                 'ethan',
                 'timéo',
                 'antoine',
                 'nathan',
                 'raphaël',
                 'thomas',
                 'tom',
                 'mathéo',
                 'mathis',
                 'samuel',
                 'tiago',
                 'baptiste',
                 'camille',
                 'louise',
                 'léa',
                 'ambre',
                 'agathe',
                 'jade',
                 'julia',
                 'mila',
                 'alice',
                 'chloé',
                 'emma',
                 'andréa',
                 'anna',
                 'lucie',
                 'eden',
                 'romane',
                 'élise',
                 'zoé',
                 'emy',
                 'léonie',
                 'mia',
                 'rose',
                 'candice',
                 'amélia']

liste_noms = ['Martin',
              'Bernard',
              'Thomas',
              'Petit',
              'Robert',
              'Richard',
              'Durand',
              'Dubois',
              'Moreau',
              'Laurent',
              'Simon',
              'Michel',
              'Lefèvre',
              'Leroy',
              'Roux',
              'David',
              'Bertrand',
              'Morel',
              'Fournier',
              'Girard',
              'Bonnet',
              'Dupont',
              'Lambert',
              'Fontaine',
              'Rousseau',
              'Vincent',
              'Muller',
              'Lefevre',
              'Faure',
              'Andre',
              'Mercier',
              'Blanc',
              'Guerin',
              'Boyer',
              'Garnier',
              'Chevalier',
              'Francois',
              'Legran',
              'Gauthier',
              'Garcia',
              'Perrin',
              'Robin',
              'Clement',
              'Morin',
              'Nicolas',
              'Henry',
              'Roussel',
              'Mathieu',
              'Gautier',
              'Masson']


class personne:
    """
    une personne
    """
    def __init__(self, num_p, nom, prenom, date_naissance, adresse, date_adh, fonction, num_club, num_equipe):
        self.num_p = num_p
        self.nom = nom
        self.prenom = prenom
        self.date_naissance = date_naissance
        self.adresse = adresse
        self.date_adh = date_adh
        self.fonction = fonction
        self.num_club = num_club
        self.num_equipe = num_equipe

    def print_p(self):
        print(self.nom ,
              self.prenom,
              self.date_naissance,
              self.adresse,
              self.fonction,
              self.num_club,
              self.num_equipe)

    def to_list(self):
        return([str(self.nom),
                str(self.prenom),
                str(self.date_naissance),
                str(self.adresse),
                str(self.date_adh),
                str(self.fonction),
                str(self.num_club)])

pers_counter = 1

def creer_personne(l_prenom, l_nom, num_club, num_equipe, fonction=""):
    """
    Retourne une personne créée 'aleatoirement'
    """
    global pers_counter
    prenom = random.choice(l_prenom)
    nom = random.choice(l_nom)
    j = random.randint(1, 28)
    m = random.randint(1, 12)
    a = random.randint(1980, 2010)
    date_n = str(a) + "-" + str(m).zfill(2) + "-" + str(j).zfill(2)
    date_a = str(a+5) + "-" + str(m).zfill(2) + "-" + str(j).zfill(2)
    adresse = str(random.randint(1, 150)) + " rue " + nom
    pers = personne(pers_counter, nom, prenom, date_n, adresse, date_a, fonction, num_club, num_equipe)
    pers_counter += 1

    return pers

def creer_equipe(l_prenom, l_nom, num_club, num_equipe):
    """
    Retourne une liste de personne composant une équipe
    Une equipe contient entre 7 (nb joueurs sur le terrain) et 15 joueurs (avec les remplaçants)
    """
    equipe = []
    nombre_joueur = random.randint(7, 15)
    for _ in range(nombre_joueur):
        equipe.append((creer_personne(l_prenom, l_nom, num_club, num_equipe)))
    return equipe

equipe_counter = 1

def creer_club(l_prenom, l_nom, num_club):
    """
    Retourne une liste d'equipe
    On considerera qu'un club est composé d'au minimum 1 equipe et au maximum 3 equipes
    """
    global equipe_counter
    club = []
    nb_equipe = random.randint(1, 5)
    for num_equipe in range(nb_equipe):
        club.append(creer_equipe(l_prenom, l_nom, num_club, equipe_counter))
        equipe_counter += 1
    club.append([creer_personne(l_prenom, l_nom, num_club, None, "president")])
    club.append([creer_personne(l_prenom, l_nom, num_club, None, "secretaire")])
    club.append([creer_personne(l_prenom, l_nom, num_club, None, "tresorier")])
    return club


def creer_n_club(n):
    """
    Retourne une liste de n club
    """

    all_club = []
    for num in range(n):
        all_club.append(creer_club(liste_prenoms, liste_noms, num+1))

    return all_club

def final_print(liste_club):
    for club in liste_club:
        for equipe in club:
            for p in equipe:
                p.print_p()
