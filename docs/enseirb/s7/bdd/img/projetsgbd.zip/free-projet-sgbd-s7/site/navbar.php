 <div class="navbar">
  <a href="/">Accueil</a>
  <div class="dropdown">
    <button class="dropbtn">Requêtes</button>
     <div class=dropdown-content>
        <a href="/requetesFront/inserer.php">Insérer</a>
        <a href="/requetesFront/stat.php">Statistiques</a>
        <a href="/requetesFront/rechercher.php">Recherche</a>
        <a href="/requetesFront/eliminar.php">Supprimer</a>
     </div>
  </div>
  <div class="dropdown">
    <button class="dropbtn">Base brute</button>
    <div class="dropdown-content">
        <a href="/brute/action-brute.php">Action</a>
        <a href="/brute/categorie-brute.php">Catégorie</a>
        <a href="/brute/club-brute.php">Club</a>
        <a href="/brute/equipe-brute.php">Équipe</a>
        <a href="/brute/joueur-brute.php">Joueur</a>
        <a href="/brute/personne-brute.php">Personne</a>
        <a href="/brute/rencontre-brute.php">Rencontre</a>
    </div>
  </div>
</div>