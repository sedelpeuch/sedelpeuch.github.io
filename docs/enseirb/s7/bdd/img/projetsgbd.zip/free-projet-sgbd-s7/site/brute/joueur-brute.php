<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title>SGBD Joueur</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root . "/navbar.php");
?>
<center>
<h1> Table brute de Joueur </h1>
</center>

<?php
$sql = "SELECT * FROM Joueur";
$result = $conn->query($sql);
while($data = mysqli_fetch_array($result))
{
    $tableau[]=$data;
    //détermine le nombre de colonnes
    $nbcol=4;
}

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','numero licence','</td>';
    echo '<th>','numero equipe','</td>';
    echo '<th>','numero joueur','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['num_licence'],'</td>';
    echo '<td>',$tableau[$i]['num_equipe'],'</td>';
    echo '<td>',$tableau[$i]['num_joueur'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
$conn->close();
?>

</body>
</html>
