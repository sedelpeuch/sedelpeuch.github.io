<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title>Statistiques</title>
<link rel="stylesheet" href="/css/main.css">
</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root."/navbar.php");
?>

<script type="text/javascript" src="/js/tab.js"></script>

<center>
<h1> Statistiques </h1>
</center>

 <!-- Tab links -->
<h2> Statistiques à consulter : </h2>
<div class="tab">
  <button class="button" onclick="openInsert(event, 'cla_eq')" id="defaultOpen" >Classement des équipes</button>
  <button class="button" onclick="openInsert(event, 'moy_score_saison')">Moyenne des scores saison</button>
  <button class="button" onclick="openInsert(event, 'moy_score_date')">Moyenne scores date</button>
  <button class="button" onclick="openInsert(event, 'cla_j_date')">Classement des joueurs à une date</button>
  <button class="button" onclick="openInsert(event, 'cla_j_saison')">Classement des joueurs pour une saison</button>
</div>

<div id="cla_eq" class="tabcontent">
  <h3>Classement des équipes</h3>
  <form action="/requetesBack/stat.php" method="post" target="_blank">
    <!--<p><label for="nb_coach">Saison (ex :  2019) :</label>-->
    <!--<input type="number" min="2017" name="saison" id="saison" required="true"></p>-->
    <p><label for="top">Nombre d'équipes à afficher :</label>
    <select name="top">
    <option value="-1">Toutes</option>
    <option value="10">10</option>
    <option value="50">50</option>
    <option value="100">100</option>
    </select></p>
    <input type="hidden" name="frmname" value="cla_eq">
    <input type="submit" value = "Consulter">
  </form>
</div>

<div id="moy_score_saison" class="tabcontent">
  <h3>Moyenne des scores pour une saison donnée (ex : 2019)</h3>
  <form action="/requetesBack/stat.php" method="post" target="_blank">
    <p><label for="saison">Saison (ex :  2019) :</label>
    <input type="number" min="2017" name="saison" id="saison" required="true"></p>
    <input type="hidden" name="frmname" value="moy_score_saison">
    <input type="submit" value = "Consulter">
  </form>
</div>

<div id="moy_score_date" class="tabcontent">
  <h3>Moyenne des scores pour une date donnée</h3>
  <form action="/requetesBack/stat.php" method="post" target="_blank">
    <p><label for="date">Date :</label>
    <input type="date" value="2020-12-03" name="date" id="date" required="true"></p>
    <input type="hidden" name="frmname" value="moy_score_date">
    <input type="submit" value = "Consulter">
  </form>
</div>

<div id="cla_j_date" class="tabcontent">
  <h3>Classement des joueurs pour une date donnée</h3>
  <form action="/requetesBack/stat.php" method="post" target="_blank">
    <p><label for="date">Date :</label>
    <input type="date" value="2020-12-03" name="date" id="date" required="true"></p>
    <input type="hidden" name="frmname" value="cla_j_date">
    <input type="submit" value = "Consulter">
  </form>
</div>

<div id="cla_j_saison" class="tabcontent">
  <h3>Classement des joueurs pour une saison donnée</h3>
  <form action="/requetesBack/stat.php" method="post" target="_blank">
    <p><label for="saison">Saison (ex : 2019) :</label>
    <input type="number" min="0" name="saison" id="saison" required="true"></p>
    <p><label for="cate">Numero categorie :</label>
    <input type="number" min="1" name="cate" id="cate" required="true"></p>
    <p><label for="top">Nombre de joueurs à afficher :</label>
    <select name="top">
    <option value="-1">Tous</option>
    <option value="10">10</option>
    <option value="50">50</option>
    <option value="100">100</option>
    </select></p>
    <input type="hidden" name="frmname" value="cla_j_saison">
    <input type="submit" value = "Consulter">
  </form>
</div>


<script> // Get the element with id="default" and click on it
document.getElementById("defaultOpen").click();
</script>