<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title> SGBD Action</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root . "/navbar.php");
?>
<center>
<h1> Table brute de Action </h1>
</center>

<?php
$sql = "SELECT * FROM Action";
$result = $conn->query($sql);
while($data = mysqli_fetch_array($result))
{
    $tableau[]=$data;
    //détermine le nombre de colonnes
    $nbcol=5;
}

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','numero joueur','</td>';
    echo '<th>','numero rencontre','</td>';
    echo '<th>','score','</td>';
    echo '<th>','faute','</td>';
    echo '<th>','titulaire','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['num_joueur'],'</td>';
    echo '<td>',$tableau[$i]['num_rencontre'],'</td>';
    echo '<td>',$tableau[$i]['score'],'</td>';
    echo '<td>',$tableau[$i]['faute'],'</td>';
    echo '<td>',$tableau[$i]['titulaire'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
$conn->close();
?>

</body>
</html>
