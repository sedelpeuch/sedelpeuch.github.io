<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title>Supprimer</title>
<link rel="stylesheet" href="/css/main.css">
</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root."/navbar.php");
?>

<script type="text/javascript" src="/js/tab.js"></script>

<center>
<h1> Supprimer des données dans la base </h1>
</center>

 <!-- Tab links -->
<h2> Données à supprimer : </h2>
<div class="tab">
  <button class="button" onclick="openInsert(event, 'Action')" id="defaultOpen" >Action</button>
  <button class="button" onclick="openInsert(event, 'Categorie')">Catégorie</button>
  <button class="button" onclick="openInsert(event, 'Club')">Club</button>
  <button class="button" onclick="openInsert(event, 'Equipe')">Équipe</button>
  <button class="button" onclick="openInsert(event, 'Joueur')">Joueur</button>
  <button class="button" onclick="openInsert(event, 'Personne')">Personne</button>
  <button class="button" onclick="openInsert(event, 'Rencontre')">Rencontre</button>
</div>

<!-- Tab content -->
<div id="Action" class="tabcontent">
  <h3>Supprimer une action</h3>
    <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="num_j">Numéro du joueur:</label>
        <input type="number" name="num_j" id="num_j" min="0" required="true">
    </p>
    <p>
        <label for="num_r">Numéro de rencontre:</label>
        <input type="number" name="num_r" id="num_r" min="0" required="true">
    </p>
    <input type="hidden" name="frmname" value="action">
    <input type="submit" value="Supprimer">
  </form>
</div>

<div id="Categorie" class="tabcontent">
  <h3>Supprimer une catégorie</h3>
  <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="categorie">Numéro catégorie:</label>
        <input type="num" name="categorie" id="categorie">
    </p>
    <input type="hidden" name="frmname" value="categorie">
    <input type="submit" value="Supprimer">
  </form>
</div>

<div id="Club" class="tabcontent">
  <h3>Supprimer un club</h3>
  <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="club">Numéro de club:</label>
        <input type="number" name="club" id="club" min="0" required="true">
    </p>
    <input type="hidden" name="frmname" value="club">
    <input type="submit" value = "Supprimer">
  </form>
</div>

<div id="Equipe" class="tabcontent">
  <h3>Supprimer une équipe</h3>
  <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="equipe">Numéro équipe:</label>
        <input type="number" name="equipe" id="equipe" min="0" required="true">
    </p>
    <input type="hidden" name="frmname" value="equipe">
    <input type="submit" value="Supprimer">
  </form>
</div>

<div id="Joueur" class="tabcontent">
  <h3>Supprimer un joueur</h3>
  <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="num_j">Numéro du joueur:</label>
        <input type="number" name="num_j" id="num_j" min="0" required="true">
    </p>
    <input type="hidden" name="frmname" value="joueur">
    <input type="submit" value="Supprimer">
  </form>
</div>

<div id="Personne" class="tabcontent">
  <h3>Supprimer une personne</h3>
  <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="num_p">Numéro de personne:</label>
        <input type="number" name="num_p" id="num_p" min="0" required="true">
    </p>
    <input type="hidden" name="frmname" value="personne">
    <input type="submit" value="Supprimer">
  </form>
</div>

<div id="Rencontre" class="tabcontent">
  <h3>Supprimer une rencontre</h3>
  <form action="/requetesBack/eliminar.php" method="post" target="_blank">
    <p>
        <label for="num_r">Numéro de rencontre:</label>
        <input type="number" name="num_r" id="num_r" min="0" required="true">
    </p>
    <input type="hidden" name="frmname" value="rencontre">
    <input type="submit" value="Supprimer">
  </form>
</div>

<script> // Get the element with id="default" and click on it
document.getElementById("defaultOpen").click();
</script>