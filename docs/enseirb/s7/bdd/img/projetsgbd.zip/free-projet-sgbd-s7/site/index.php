<?php
include_once 'connectDB.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title> SGBD Home</title>
	<style>
		<?php
		include 'css/main.css';
		?>
	</style>

</head>
<body>
	<?php
	include 'navbar.php';
	?>

	<center>
		<h1>BONJOUR BIENVENUE PRENEZ PLACE</h1>
	</center>

</body>
</html>
