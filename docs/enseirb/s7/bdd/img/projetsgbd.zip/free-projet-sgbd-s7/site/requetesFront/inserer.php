<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title>Insérer</title>
<link rel="stylesheet" href="/css/main.css">
</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root."/navbar.php");
?>

<script type="text/javascript" src="/js/tab.js"></script>

<center>
<h1> Insérer des données dans la base </h1>
</center>

 <!-- Tab links -->
<h2> Données à insérer : </h2>
<div class="tab">
  <button class="button" onclick="openInsert(event, 'Action')" id="defaultOpen" >Action</button>
  <button class="button" onclick="openInsert(event, 'Categorie')">Catégorie</button>
  <button class="button" onclick="openInsert(event, 'Club')">Club</button>
  <button class="button" onclick="openInsert(event, 'Equipe')">Équipe</button>
  <button class="button" onclick="openInsert(event, 'Joueur')">Joueur</button>
  <button class="button" onclick="openInsert(event, 'Personne')">Personne</button>
  <button class="button" onclick="openInsert(event, 'Rencontre')">Rencontre</button>
  <button class="button" onclick="openInsert(event, 'FeuilleMatch')">Feuille de match</button>
</div>

<!-- Tab content -->
<div id="Action" class="tabcontent">
  <h3>Inserer une action</h3>
    <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p>
        <label for="num_j">Numéro du joueur:</label>
        <input type="number" name="num_j" id="num_j" min="0" required="true">
    </p>
    <p>
        <label for="num_r">Numéro de rencontre:</label>
        <input type="number" name="num_r" id="num_r" min="0" required="true">
    </p>
    <p>
        <label for="score">Score:</label>
        <input type="number" name="score" id="score" min="0" required="true">
    </p>
    <p>
        <label for="faute">Nombre de fautes:</label>
        <input type="number" name="nb_f" id="nb_f" min="0" required="true">
    </p>
    <p>
        <label for="titu">Titulaire:</label>
        <input type="checkbox" name="titu" id="titu">
    </p>
    <input type="hidden" name="frmname" value="action">
    <input type="submit" value="Inserer">
  </form>
</div>

<div id="Categorie" class="tabcontent">
  <h3>Inserer une catégorie</h3>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p>
        <label for="categorie">Nom catégorie:</label>
        <input type="text" name="categorie" id="categorie">
    </p>
    <input type="hidden" name="frmname" value="categorie">
    <input type="submit" value="Inserer">
  </form>
</div>

<div id="Club" class="tabcontent">
  <h3>Insérer un club</h3>
  <p>Cliquer le bouton pour insérer un nouveau club</p>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <input type="hidden" name="frmname" value="club">
    <input type="submit" value = "Ajouter un club">
  </form>
</div>

<div id="Equipe" class="tabcontent">
  <h3>Insérer une équipe</h3>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p><label for="nb_coach">Numéro coach :</label>
    <input type="number" min="0" name="num_coach" id="num_coach" required="true"></p>
    <p><label for="nb_cate">Numéro categorie :</label>
    <input type="number" min="0" name="num_cate" id="num_cate" required="true"></p>
    <p><label for="nb_coach">Niveau :</label>
    <input type="number" min="0" name="niveau" id="niveau" required="true"></p>
    <p><label for="nb_coach">Numéro club : </label>
    <input type="number" min="0" name="num_club" id="num_club" required="true"></p>
    <p><input type="hidden" name="frmname" value="equipe"></p>
    <p><input type="submit" value="inserer"></p>
  </form>
</div>

<div id="Joueur" class="tabcontent">
  <h3>Insérer un joueur</h3>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p><label for="num_equipe">Numéro équipe du joueur :</label>
    <input type="number" min="0" name="num_equipe" id="num_equipe" required="true"></p>
    <p><label for="nb_cate">Numéro personne associé :</label>
    <input type="number" min="0" name="num_j" id="num_j" required="true"></p>
    <p><input type="hidden" name="frmname" value="joueur"></p>
    <p><input type="submit" value="inserer"></p>
  </form>
</div>

<div id="Personne" class="tabcontent">
  <h3>Insérer une personne</h3>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p><label for="nom">Nom : </label>
    <input type="text" name="nom" id="nom" required="true"></p>
    <p><label for="prenom">Prénom :</label>
    <input type="text" name="prenom" id="prenom" required="true"></p>
    <p><label for="date_n">Date de naissance :</label>
    <input type="date" value="2020-12-03" name="date_n" id="date_n" required="true"></p>
    <p><label for="adr">Adresse :</label>
    <input type="text" name="ad" id="ad" required="true"></p>
    <p><label for="date_a">Date adhésion au club :</label>
    <input type="date" value="2020-12-03" name="date_a" id="date_a" required="true"></p>
    <p><label for="fonction">Fonction au sein du bureau du club :</label>
    <select name="fonction">
    <option value="aucune">Aucune</option>
    <option value="president">Président</option>
    <option value="secretaire">Secrétaire</option>
    <option value="tresorier">Trésorier</option>
    </select></p>
    <p><label for="num_c">Numéro du club dans lequel est la personne:</label>
    <input type="number" min="0" name="num_c" id="num_c" required="true"></p>
    <p><input type="submit" value="inserer"></p>
    <p><input type="hidden" name="frmname" value="personne"></p>
  </form>
</div>

<div id="Rencontre" class="tabcontent">
  <h3>Insérer une rencontre</h3>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p><label for="date">Date de la rencontre :</label>
    <input type="date" value="2020-12-03" name="date" id="date" required="true"></p>
    <p><label for="e1">Numéro équipe 1 :</label>
    <input type="number" min="0" name="e1" id="e1" required="true"></p>
    <p><label for="e1">Numéro équipe 2 :</label>
    <input type="number" min="0" name="e2" id="e2" required="true"></p>
    <input type="hidden" name="frmname" value="rencontre">
    <input type="submit" value = "inserer">
  </form>
</div>


<div id="FeuilleMatch" class="tabcontent">
  <h3>Insérer une feuille de match</h3>
  <form action="/requetesBack/inserer.php" method="post" target="_blank">
    <p><label for="date">Date de la rencontre :</label>
    <input type="date" value="2020-12-03" name="date" id="date" required="true"></p>
    <p><label for="e1">Numéro équipe 1 :</label>
    <input type="number" min="0" name="e1" id="e1" size="2" required="true"></p>
    <h3>Actions équipe 1</h3>

    <p>N° joueur : <input type="number" min="0" name="a1e1[ ]" size="2" required="true"/>
       score : <input type="number" min="0" name="a1e1[ ]" size="2" required="true"/>
       faute : <input type="number" min="0" name="a1e1[ ]" size="2" required="true"/></p>
    <p>N° joueur : <input type="number" min="0" name="a2e1[]" size="2" required="true">
       score : <input type="number" min="0" name="a2e1[]" size="2" required="true">
       faute : <input type="number" min="0" name="a2e1[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a3e1[]" size="2" required="true">
       score : <input type="number" min="0" name="a3e1[]" size="2" required="true">
       faute : <input type="number" min="0" name="a3e1[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a4e1[]" size="2" required="true">
       score : <input type="number" min="0" name="a4e1[]" size="2" required="true">
       faute : <input type="number" min="0" name="a4e1[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a5e1[]" size="2" required="true">
       score : <input type="number" min="0" name="a5e1[]" size="2" required="true">
       faute : <input type="number" min="0" name="a5e1[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a6e1[]" size="2" required="true">
       score : <input type="number" min="0" name="a6e1[]" size="2" required="true">
       faute : <input type="number" min="0" name="a6e1[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a7e1[]" size="2" required="true">
       score : <input type="number" min="0" name="a7e1[]" size="2" required="true">
       faute : <input type="number" min="0" name="a7e1[]" size="2" required="true"></p>

    <p><label for="e1">Numéro équipe 2 :</label>
    <input type="number" min="0" name="e2" id="e2" size="2" required="true"></p>

    <h3>Actions équipe 2</h3>

    <p>N° joueur : <input type="number" min="0" name="a1e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a1e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a1e2[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a2e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a2e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a2e2[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a3e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a3e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a3e2[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a4e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a4e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a4e2[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a5e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a5e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a5e2[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a6e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a6e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a6e2[]" size="2" required="true"></p>
    <p>N° joueur : <input type="number" min="0" name="a7e2[]" size="2" required="true">
       score : <input type="number" min="0" name="a7e2[]" size="2" required="true">
       faute : <input type="number" min="0" name="a7e2[]" size="2" required="true"></p>

    <input type="hidden" name="frmname" value="feuilleMatch">
    <input type="submit" value = "inserer">
  </form>
</div>


<script> // Get the element with id="default" and click on it
document.getElementById("defaultOpen").click();
</script>