<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title>SGBD Personne</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root . "/navbar.php");
?>
<center>
<h1> Table brute de Personne </h1>
</center>

<?php
$sql = "SELECT * FROM Personne";
$result = $conn->query($sql);
while($data = mysqli_fetch_array($result))
{
    $tableau[]=$data;
    //détermine le nombre de colonnes
    $nbcol=8;
}

    echo '<table class="center">';
    echo '<tr>';
    echo '<th>','numero personne','</th>';
    echo '<th>','nom','</th>';
    echo '<th>','prenom','</th>';
    echo '<th>','date de naissance','</th>';
    echo '<th>','adresse','</th>';
    echo '<th>','date adhesion','</th>';
    echo '<th>','fonction','</th>';
    echo '<th>','numero club','</th>';
    echo '</tr>';
    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['num_personne'],'</td>';
    echo '<td>',$tableau[$i]['nom'],'</td>';
    echo '<td>',$tableau[$i]['prenom'],'</td>';
    echo '<td>',$tableau[$i]['date_naissance'],'</td>';
    echo '<td>',$tableau[$i]['adresse'],'</td>';
    echo '<td>',$tableau[$i]['date_adhesion'],'</td>';
    echo '<td>',$tableau[$i]['fonction'],'</td>';
    echo '<td>',$tableau[$i]['num_club'],'</td>';
    echo '</tr>';
    }
    echo '</table>';
$conn->close();
?>
</body>
</html>
