<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>
<?php

switch ($_REQUEST['frmname']){
    case "categorie":
        // Escape user inputs for security
        $categorie = mysqli_real_escape_string($conn, $_REQUEST['categorie']);
        insertCate($categorie, $conn);
        break;
    case "action":
        // Escape user inputs for security
        $num_j = mysqli_real_escape_string($conn, $_REQUEST['num_j']);
        $num_r = mysqli_real_escape_string($conn, $_REQUEST['num_r']);
        $score = mysqli_real_escape_string($conn, $_REQUEST['score']);
        $faute = mysqli_real_escape_string($conn, $_REQUEST['nb_f']);
        $titulaire = mysqli_real_escape_string($conn, $_REQUEST['titu']);
        insertAction($num_j, $num_r, $score, $faute, $titulaire, $conn);
        break;
    case "club":
        insertClub($conn);
        break;
    case "equipe":
        $num_coach = mysqli_real_escape_string($conn, $_REQUEST['num_coach']);
        $num_cate = mysqli_real_escape_string($conn, $_REQUEST['num_cate']);
        $niveau = mysqli_real_escape_string($conn, $_REQUEST['niveau']);
        $num_club = mysqli_real_escape_string($conn, $_REQUEST['num_club']);
        insertEquipe($num_coach, $num_cate, $niveau, $num_club, $conn);
        break;
    case "joueur":
        $num_equipe = mysqli_real_escape_string($conn, $_REQUEST['num_equipe']);
        $num_j = mysqli_real_escape_string($conn, $_REQUEST['num_j']);
        insertJoueur($num_equipe, $num_j, $conn);
        break;
    case "personne":
        $nom = mysqli_real_escape_string($conn, $_REQUEST['nom']);
        $prenom = mysqli_real_escape_string($conn, $_REQUEST['prenom']);
        $date_n = mysqli_real_escape_string($conn, $_REQUEST['date_n']);
        $ad = mysqli_real_escape_string($conn, $_REQUEST['ad']);
        $date_a = mysqli_real_escape_string($conn, $_REQUEST['date_a']);
        $fonc = mysqli_real_escape_string($conn, $_REQUEST['fonction']);
        $num_c = mysqli_real_escape_string($conn, $_REQUEST['num_c']);
        insertPersonne($nom, $prenom, $date_n, $ad , $date_a, $fonc, $num_c, $conn);
        break;
    case "rencontre":
        $date = mysqli_real_escape_string($conn, $_REQUEST['date']);
        $e1 = mysqli_real_escape_string($conn, $_REQUEST['e1']);
        $e2 = mysqli_real_escape_string($conn, $_REQUEST['e2']);
        insertRencontre($date, $e1, $e2, $conn);
        break;
    case "feuilleMatch":
        $date = mysqli_real_escape_string($conn, $_REQUEST['date']);
        $e1 = mysqli_real_escape_string($conn, $_REQUEST['e1']);
        $a1e1 = $_REQUEST['a1e1'];
        $a2e1 = $_REQUEST['a2e1'];
        $a3e1 = $_REQUEST['a3e1'];
        $a4e1 = $_REQUEST['a4e1'];
        $a5e1 = $_REQUEST['a5e1'];
        $a6e1 = $_REQUEST['a6e1'];
        $a7e1 = $_REQUEST['a7e1'];
        $e2 = mysqli_real_escape_string($conn, $_REQUEST['e2']);
        $a1e2 = $_REQUEST['a1e2'];
        $a2e2 = $_REQUEST['a2e2'];
        $a3e2 = $_REQUEST['a3e2'];
        $a4e2 = $_REQUEST['a4e2'];
        $a5e2 = $_REQUEST['a5e2'];
        $a6e2 = $_REQUEST['a6e2'];
        $a7e2 = $_REQUEST['a7e2'];
        insertFeuilleMatch($date,
                           $e1,
                           $e2,
                           $a1e1,
                           $a2e1,
                           $a3e1,
                           $a4e1,
                           $a5e1,
                           $a6e1,
                           $a7e1,
                           $a1e2,
                           $a2e2,
                           $a3e2,
                           $a4e2,
                           $a5e2,
                           $a6e2,
                           $a7e2,
                           $conn);
        break;
    default:
        echo "commande inconnue ou non implémentée";
        break;
}

function doRequest($request, $conn){
    if(mysqli_query($conn, $request)){
        echo "Entrée ajoutée avec succes.";
    } else{
        echo "ERREUR: Execution impossible de $request.<br>";
        echo "Erreur retournée : ". mysqli_error($conn);
    }
}

function insertCate($categorie, $conn){
    $sql = "INSERT INTO Categorie (nom_categorie) VALUES ('$categorie')";
    doRequest($sql, $conn);

    // Close connection
    mysqli_close($conn);
}

function insertAction($num_j, $num_r, $score, $faute, $titulaire, $conn){
    if ($titulaire == 'on'){
        $titulaire = 1;
    }
    else{
        $titulaire = 0;
    }
    $sql = "INSERT INTO Action (num_joueur, num_rencontre, score, faute, titulaire) VALUES ('$num_j', '$num_r', '$score', '$faute', $titulaire)";
    doRequest($sql, $conn);

    // Close connection
    mysqli_close($conn);
}

function insertClub($conn){

    $sql = "INSERT INTO Club VALUES ();";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function insertEquipe($num_coach, $num_cate, $niveau, $num_club, $conn){

    $sql = "INSERT INTO Equipe (num_entraineur, num_categorie, niveau, num_club) VALUES ('$num_coach', '$num_cate', '$niveau', '$num_club')";

    doRequest($sql, $conn);

    mysqli_close($conn);

}

function insertJoueur($num_equipe, $num_j, $conn){

    $sql = "INSERT INTO Joueur (num_equipe, num_joueur) VALUES ('$num_equipe', '$num_j')";

    doRequest($sql, $conn);

    mysqli_close($conn);

}

function insertPersonne($nom,  $prenom, $date_n, $ad, $date_a, $fonc, $num_c, $conn){

    if ($fonction == "aucune"){
        $fonction = "";
    }

    $sql= "INSERT INTO Personne (nom, prenom, date_naissance, adresse, date_adhesion, fonction, num_club) VALUES ('$nom', '$prenom', '$date_n', '$ad', '$date_a', $fonction, '$num_c')";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function insertRencontre($date,  $e1, $e2, $conn){

    $sql= "INSERT INTO Rencontre (date_rencontre, num_equipe_1, num_equipe_2) VALUES ('$date', '$e1', '$e2')";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function getNumRencontre($date, $e1, $e2, $conn){

    $sql = "SELECT num_rencontre FROM Rencontre WHERE date_rencontre='$date' and num_equipe_1='$e1' and num_equipe_2='$e2'";

    $result = $conn->query($sql);
    $result = mysqli_fetch_array($result);
    $num = $result[0];

    return $num;

}

function insertFeuilleMatch($date,$e1,$e2, $a1e1,$a2e1,$a3e1,$a4e1,$a5e1,$a6e1,$a7e1,$a1e2,$a2e2,$a3e2,$a4e2,$a5e2,$a6e2,$a7e2, $conn){
    $sql= "INSERT INTO Rencontre (date_rencontre, num_equipe_1, num_equipe_2) VALUES ('$date', '$e1', '$e2')";

    if(!mysqli_query($conn, $sql)){
        echo "ERREUR: Execution impossible de $sql.<br>";
        echo "Erreur retournée : ". mysqli_error($conn);
        mysqli_close($conn);
        exit();
    }

    $num_r = getNumRencontre($date, $e1, $e2, $conn);

    $args = func_get_args ();

    for($i = 3; $i <= 16; $i++){
        $nj = $args[$i][0];
        $nj = mysqli_real_escape_string($conn, $nj);
        $sc = $args[$i][1];
        $sc = mysqli_real_escape_string($conn, $sc);
        $f = $args[$i][2];
        $f = mysqli_real_escape_string($conn, $f);
        $req = "INSERT INTO Action (num_joueur, num_rencontre, score, faute, titulaire) VALUES ('$nj', $num_r, '$sc', '$f', '1')";
        if(!mysqli_query($conn, $req)){
            echo "ERREUR: Execution impossible de $req.<br>";
            echo "Erreur retournée : ". mysqli_error($conn);
            mysqli_close($conn);
            exit();
        }
    }

    echo "Ajout effectué";
}
?>