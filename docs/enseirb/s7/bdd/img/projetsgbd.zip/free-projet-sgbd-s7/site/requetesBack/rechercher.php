<?php
$root = $_SERVER['DOCUMENT_ROOT'];
include_once $root . "/connectDB.php";
?>

<!DOCTYPE html>
<html>
<head>

  <title>Recherche</title>
  <link rel="stylesheet" href="/css/main.css">

</head>
<body>

  <?php
$root = $_SERVER['DOCUMENT_ROOT'];
include_once $root . "/navbar.php";
?>


<?php

switch ($_REQUEST['frmname']) {

case "action":
  $num_j = mysqli_real_escape_string($conn, $_REQUEST['num_j']);
  $num_r = mysqli_real_escape_string($conn, $_REQUEST['num_r']);
  $score = mysqli_real_escape_string($conn, $_REQUEST['score']);
  $faute = mysqli_real_escape_string($conn, $_REQUEST['nb_f']);
  searchAction($num_j, $num_r, $score, $faute, $conn);
  break;

case "categorie":
  $num_cate = mysqli_real_escape_string($conn, $_REQUEST['num_cate']);
  $nom_cate = mysqli_real_escape_string($conn, $_REQUEST['nom_cate']);
  searchCate($num_cate, $nom_cate, $conn);
  break;

case "club":
  $num_club = mysqli_real_escape_string($conn, $_REQUEST['club']);
  searchClub($num_club, $conn);
  break;

case "equipe":
  $num_equ = mysqli_real_escape_string($conn, $_REQUEST['num_equ']);
  searchEquipe($num_equ, $conn);
  break;

case "joueur":
  $nom = mysqli_real_escape_string($conn, $_REQUEST['nom']);
  $prenom = mysqli_real_escape_string($conn, $_REQUEST['prenom']);
  $date_n = mysqli_real_escape_string($conn, $_REQUEST['date_n']);
  $inco_date_nai = mysqli_real_escape_string($conn, $_REQUEST['inco_date_nai']);
  $ad = mysqli_real_escape_string($conn, $_REQUEST['ad']);
  $num_c = mysqli_real_escape_string($conn, $_REQUEST['num_c']);
  $date_a = mysqli_real_escape_string($conn, $_REQUEST['date_a']);
  $inco_date_c = mysqli_real_escape_string($conn, $_REQUEST['inco_date_c']);
  $num_equipe = mysqli_real_escape_string($conn, $_REQUEST['num_equipe']);
  $num_j = mysqli_real_escape_string($conn, $_REQUEST['num_j']);
  searchJoueur($nom, $prenom, $date_n, $inco_date_nai, $ad, $num_c, $date_a, $inco_date_c, $num_equipe, $num_j, $conn);
  break;

case "personne":
  $nom = mysqli_real_escape_string($conn, $_REQUEST['nom']);
  $prenom = mysqli_real_escape_string($conn, $_REQUEST['prenom']);
  $date_n = mysqli_real_escape_string($conn, $_REQUEST['date_n']);
  $inco_date_nai = mysqli_real_escape_string($conn, $_REQUEST['inco_date_nai']);
  $ad = mysqli_real_escape_string($conn, $_REQUEST['ad']);
  $date_a = mysqli_real_escape_string($conn, $_REQUEST['date_a']);
  $inco_date_c = mysqli_real_escape_string($conn, $_REQUEST['inco_date_c']);
  $fonc = mysqli_real_escape_string($conn, $_REQUEST['fonction']);
  $num_c = mysqli_real_escape_string($conn, $_REQUEST['num_c']);
  searchPersonne($nom, $prenom, $date_n, $inco_date_nai, $ad, $date_a, $inco_date_c, $fonc, $num_c, $conn);
  break;

case "rencontre":
  $date = mysqli_real_escape_string($conn, $_REQUEST['date']);
  $e1 = mysqli_real_escape_string($conn, $_REQUEST['e1']);
  $e2 = mysqli_real_escape_string($conn, $_REQUEST['e2']);
  $inco_date_r = mysqli_real_escape_string($conn, $_REQUEST['inco_date']);
  searchRencontre($date, $inco_date_r, $e1, $e2, $conn);
  break;

case "feuilleMatch":
  $e1 = mysqli_real_escape_string($conn, $_REQUEST['e1']);
  $e2 = mysqli_real_escape_string($conn, $_REQUEST['e2']);
  $date = mysqli_real_escape_string($conn, $_REQUEST['date']);
  searchFeuilleMatch($e1, $e2, $date, $conn);
  break;

default:
  echo "commande inconnue ou non implémentée";
  break;
}

function searchCate($num_cate, $nom_cate, $conn) {
  if ($nom_cate != '') {
    $nom_cate = $nom_cate . '%';
  }
  echo "<center><h1> Résultat de la recherche catégorie</h1></center>";

  $sql = "CALL pVoirCategorie('" . $num_cate . "', '" . $nom_cate . "')";

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'N° categorie', '</td>';
  echo '<th>', 'Nom categorie', '</td>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableau[$i]['num_categorie'], '</td>';
    echo '<td>', $tableau[$i]['nom_categorie'], '</td>';
    echo '</tr>';
  }

  echo '</table>';
  $conn->close();
}

function searchAction($num_j, $num_r, $score, $faute, $conn) {
  if ($nom_cate != '') {
    $nom_cate = $nom_cate . '%';
  }
  echo "<center><h1> Résultat de la recherche Action</h1></center>";

  $sql = "CALL pVoirAction(" . $num_j . ", " . $num_r . ", " . $score . ", " . $faute . ")";

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'N° rencontre', '</td>';
  echo '<th>', 'N° joueur', '</td>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'Score', '</td>';
  echo '<th>', 'Fautes', '</td>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableau[$i]['num_rencontre'], '</td>';
    echo '<td>', $tableau[$i]['num_joueur'], '</td>';
    echo '<td>', $tableau[$i]['nom'], '</td>';
    echo '<td>', $tableau[$i]['prenom'], '</td>';
    echo '<td>', $tableau[$i]['score'], '</td>';
    echo '<td>', $tableau[$i]['faute'], '</td>';
    echo '</tr>';
  }

  echo '</table>';
  $conn->close();
}

function searchClub($num_club, $conn) {
  echo "<center><h1> Résultat de la recherche du club " . $num_club . "</h1></center>";

  $sql = "CALL pVoirClub('" . $num_club . "')";

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'Date naissance', '</td>';
  echo '<th>', 'N° licence', '</td>';
  echo '<th>', 'N° équipe', '</td>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableau[$i]['nom'], '</td>';
    echo '<td>', $tableau[$i]['prenom'], '</td>';
    echo '<td>', $tableau[$i]['date_naissance'], '</td>';
    echo '<td>', $tableau[$i]['num_licence'], '</td>';
    echo '<td>', $tableau[$i]['num_equipe'], '</td>';
    echo '</tr>';
  }

  echo '</table>';
  $conn->close();
}

function searchEquipe($num_equ, $conn) {
  echo "<center><h1> Résultat de la recherche d'Équipe</h1></center>";

  $sql = "CALL pVoirEquipe('" . $num_equ . "')";

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo "<center><h2> Équipe " . $tableau[1]['num_equipe'] . "</h2><h2> N° Coach : " . $tableau[1]['num_entraineur'] . "</h2><h2>Catégorie : " . $tableau[1]['nom_categorie'] . "</h2></center>";

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'N° joueur', '</td>';
  echo '<th>', 'N° licence', '</td>';
  echo '<th>', 'Scores', '</td>';
  echo '<th>', 'Fautes', '</td>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableau[$i]['nom'], '</td>';
    echo '<td>', $tableau[$i]['prenom'], '</td>';
    echo '<td>', $tableau[$i]['num_joueur'], '</td>';
    echo '<td>', $tableau[$i]['num_licence'], '</td>';
    echo '<td>', $tableau[$i]['score'], '</td>';
    echo '<td>', $tableau[$i]['fautes'], '</td>';
    echo '</tr>';
  }

  echo '</table>';
  $conn->close();
}

function searchJoueur($nom, $prenom, $date_n, $inco_date_nai, $ad, $num_c, $date_a, $inco_date_c, $num_equipe, $num_j, $conn) {
  if ($inco_date_nai == 'on') {
    $date_n = '0000-01-01';
  }
  if ($inco_date_c == 'on') {
    $date_a = '0000-01-01';
  }
  echo "<center><h1> Résultat de la recherche d'un joueur </h1></center>";

  $sql = "call pVoirJoueur('" . $nom . "', '" . $prenom . "', '" . $date_n . "', '" . $ad . "', " . $num_c . ", '" . $date_a . "', " . $num_equipe . ", " . $num_j . ")";
  // echo $sql;

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'Date naissance', '</td>';
  echo '<th>', 'Adresse', '</td>';
  echo '<th>', 'N° Club', '</td>';
  echo '<th>', 'Date Adhésion', '</td>';
  echo '<th>', 'N° Equipe', '</td>';
  echo '<th>', 'N° Joueur', '</td>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableau[$i]['nom'], '</td>';
    echo '<td>', $tableau[$i]['prenom'], '</td>';
    echo '<td>', $tableau[$i]['date_naissance'], '</td>';
    echo '<td>', $tableau[$i]['adresse'], '</td>';
    echo '<td>', $tableau[$i]['num_club'], '</td>';
    echo '<td>', $tableau[$i]['date_adhesion'], '</td>';
    echo '<td>', $tableau[$i]['num_equipe'], '</td>';
    echo '<td>', $tableau[$i]['num_joueur'], '</td>';
    echo '</tr>';
  }

  echo '</table>';
  $conn->close();
}

function searchPersonne($nom, $prenom, $date_n, $inco_date_nai, $ad, $date_a, $inco_date_c, $fonc, $num_c, $conn) {
  if ($fonc == "inconnue") {
    $fonc = "";
  }
  if ($inco_date_nai == 'on') {
    $date_n = '0000-01-01';
  }
  if ($inco_date_c == 'on') {
    $date_a = '0000-01-01';
  }
  echo "<center><h1> Résultat de la recherche d'une personne </h1></center>";

  $sql = "call pVoirPersonne('" . $nom . "', '" . $prenom . "', '" . $date_n . "', '" . $ad . "', " . $num_c . ", '" . $date_a . "', '" . $fonc . "')";
  // echo $sql;

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'Date naissance', '</td>';
  echo '<th>', 'Adresse', '</td>';
  echo '<th>', 'N° Club', '</td>';
  echo '<th>', 'Date Adhésion', '</td>';
  echo '<th>', 'Fonction', '</td>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableau[$i]['nom'], '</td>';
    echo '<td>', $tableau[$i]['prenom'], '</td>';
    echo '<td>', $tableau[$i]['date_naissance'], '</td>';
    echo '<td>', $tableau[$i]['adresse'], '</td>';
    echo '<td>', $tableau[$i]['num_club'], '</td>';
    echo '<td>', $tableau[$i]['date_adhesion'], '</td>';
    echo '<td>', $tableau[$i]['fonction'], '</td>';
    echo '</tr>';
  }

  echo '</table>';
  $conn->close();
}

function searchRencontre($date, $inco_date_r, $e1, $e2, $conn) {
  if ($inco_date_r == 'on') {
    $date = '0000-01-01';
  }
  echo "<center><h1> Résultat de la recherche d'une rencontre </h1></center>";

  $sql = "call pVoirRencontre('" . $date . "', " . $e1 . ", " . $e2 . ")";
  //echo $sql;

  $result = $conn->query($sql);

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($result)) {
    $tableau[] = $data;
    $nbcol = 1;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'N° rencontre', '</td>';
  echo '<th>', 'Date', '</td>';
  echo '<th>', 'Équipe 1', '</td>';
  echo '<th>', 'Équipe 2', '</th>';
  echo '<th>', 'Voir feuille match', '</th>';
  echo '</tr>';

  $nb = count($tableau);
  for ($i = 0; $i < $nb; $i++) {

    $e1 = $tableau[$i]['equ_1'];
    $e2 = $tableau[$i]['equ_2'];
    $date = $tableau[$i]['date_rencontre'];
    $num = $tableau[$i]['num_rencontre'];
    echo '<tr>';
    echo '<td>', $num, '</td>';
    echo '<td>', $date, '</td>';
    echo '<td>', $e1, '</td>';
    echo '<td>', $e2, '</td>';
    echo '<td>';
    echo "<form action='/requetesBack/rechercher.php' method='post' target='_blank'>";
    echo "<input type='hidden' name='frmname' value='feuilleMatch'>";
    echo "<input type='hidden' name='e1' value='$e1'>";
    echo "<input type='hidden' name='e2' value='$e2'>";
    echo "<input type='hidden' name='date' value='$date'>";
    echo "<input type='submit' value='Voir'>";
    echo "</form>";
    echo "</td>";
    echo "</tr>";
  }

  echo '</table>';
  $conn->close();
}

function searchFeuilleMatch($e1, $e2, $date, $conn) {

  echo "<center><h2> Feuille de match entre l'équipe N° $e1 et l'équipe N° $e2 du $date </h2></center>";

  $sql = "CALL pVoirFeuilleMatchResume('$date', '$e1', '$e2')";
  $resume = $conn->query($sql);

  echo "<center><h3> Resumé du match </h3></center>";

  // détermine le nbr de colonnes.
  while ($data = mysqli_fetch_array($resume)) {
    $tableauR1[] = $data;
    $nbcol = 5;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  //echo '<th>', 'N° rencontre', '</td>';
  echo '<th>', 'N° équipe', '</td>';
  echo '<th>', 'N° club', '</td>';
  echo '<th>', 'Score', '</td>';
  echo '<th>', 'N° catégorie', '</td>';
  echo '</tr>';

  $nb = count($tableauR1);
  for ($i = 0; $i < $nb; $i++) {
    mysqli_use_result($conn);
    echo '<tr>';
    //echo '<td>', $tableauR1[$i]['num_rencontre'], '</td>';
    echo '<td>', $tableauR1[$i]['num_equipe'], '</td>';
    echo '<td>', $tableauR1[$i]['num_club'], '</td>';
    echo '<td>', $tableauR1[$i]['scores'], '</td>';
    echo '<td>', $tableauR1[$i]['num_categorie'], '</td>';
    echo '</tr>';
  }

  echo '</table>';

  $conn->next_result();

  echo "<center><h3> Détail des actions de l'équipe N°$e1 </h3></center>";

  $sql = "CALL pVoirFeuilleMatchDetail('$date', '$e1')";
  //echo $sql;

  $resume = $conn->query($sql);
  echo mysqli_error($conn);

  // détermine le nbr de lignes.
  while ($data = mysqli_fetch_array($resume)) {
    $tableauR2[] = $data;
    $nbcol = 4;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Score', '</td>';
  echo '<th>', 'Fautes', '</td>';
  echo '</tr>';

  $nb = count($tableauR2);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableauR2[$i]['prenom'], '</td>';
    echo '<td>', $tableauR2[$i]['nom'], '</td>';
    echo '<td>', $tableauR2[$i]['scores'], '</td>';
    echo '<td>', $tableauR2[$i]['fautes'], '</td>';
    echo '</tr>';
  }

  echo '</table>';

  $conn->next_result();

  echo "<center><h3> Détail des actions de l'équipe N°$e2 </h3></center>";

  $sql = "CALL pVoirFeuilleMatchDetail('$date', '$e2')";
  //echo $sql;

  $resume = $conn->query($sql);
  echo mysqli_error($conn);

  // détermine le nbr de lignes.
  while ($data = mysqli_fetch_array($resume)) {
    $tableauR3[] = $data;
    $nbcol = 4;
  }

  echo '<table id="" class="center">';
  echo '<tr>';
  echo '<th>', 'Prénom', '</td>';
  echo '<th>', 'Nom', '</td>';
  echo '<th>', 'Score', '</td>';
  echo '<th>', 'Fautes', '</td>';
  echo '</tr>';

  $nb = count($tableauR3);
  for ($i = 0; $i < $nb; $i++) {

    echo '<tr>';
    echo '<td>', $tableauR3[$i]['prenom'], '</td>';
    echo '<td>', $tableauR3[$i]['nom'], '</td>';
    echo '<td>', $tableauR3[$i]['scores'], '</td>';
    echo '<td>', $tableauR3[$i]['fautes'], '</td>';
    echo '</tr>';
  }

  echo '</table>';

  $conn->close();
}

?>