<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title> SGBD Rencontre</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root . '/navbar.php');
?>

<center>
<h1> Table brute de Rencontre </h1>
</center>

<form action="joueur-search.php" method="post">
Nom: <input type="text" name="nom"><br>
Prenom: <input type="text" name="prenom"><br>
<input type="submit">
</form>
                   
<?php
function searchJoueur()
{
    $sql = "SELECT * FROM Rencontre";
    $result = $conn->query($sql);
    showTable($result);
}

function showTable($result){
while($data = mysqli_fetch_array($result))
{
    $tableau[]=$data;
    //détermine le nombre de colonnes
    $nbcol=4;
}

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','numero rencontre','</td>';
    echo '<th>','date rencontre','</td>';
    echo '<th>','score 1','</td>';
    echo '<th>','score 2','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['num_rencontre'],'</td>';
    echo '<td>',$tableau[$i]['date_rencontre'],'</td>';
    echo '<td>',$tableau[$i]['score_1'],'</td>';
    echo '<td>',$tableau[$i]['score_2'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
// $conn->close();
}

if(isset($_POST['submit']))
{
   searchJoueur();
}

?>
</body>
</html>
