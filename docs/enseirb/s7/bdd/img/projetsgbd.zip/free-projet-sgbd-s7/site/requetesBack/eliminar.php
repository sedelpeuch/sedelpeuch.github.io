<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>
<?php

switch ($_REQUEST['frmname']){

    case "action":
        $num_j = mysqli_real_escape_string($conn, $_REQUEST['num_j']);
        $num_r = mysqli_real_escape_string($conn, $_REQUEST['num_r']);
        deleteAction($num_j, $num_r, $conn);
        break;

    case "categorie":
        $categorie = mysqli_real_escape_string($conn, $_REQUEST['categorie']);
        deleteCate($categorie, $conn);
        break;

    case "club": // no
        $club = mysqli_real_escape_string($conn, $_REQUEST['club']);
        deleteClub($club, $conn);
        break;

    case "equipe":
        $equipe = mysqli_real_escape_string($conn, $_REQUEST['equipe']);
        deleteEquipe($equipe, $conn);
        break;

    case "joueur":
        $num_j = mysqli_real_escape_string($conn, $_REQUEST['num_j']);
        deleteJoueur($num_j, $conn);
        break;

    case "personne":
        $num_p = mysqli_real_escape_string($conn, $_REQUEST['num_p']);
        deletePersonne($num_p, $conn);
        break;

    case "rencontre":
        $num_r = mysqli_real_escape_string($conn, $_REQUEST['num_r']);
        deleteRencontre($num_r, $conn);
        break;

    default:
        echo "commande inconnue ou non implémentée";
        break;
}

function doRequest($request, $conn){
    if(mysqli_query($conn, $request)){
        echo "Entité supprimée avec succès.";
    } else{
        echo "ERREUR: Execution impossible de $request.<br>";
        echo "Erreur retournée : ". mysqli_error($conn);
    }
}

function deleteCate($categorie, $conn){

    $sql = "DELETE FROM Categorie WHERE num_categorie = $categorie;";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function deleteAction($num_j, $num_r, $conn){

    $sql = "DELETE FROM Action WHERE num_joueur = $num_j AND num_rencontre = $num_r;";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function deleteClub($club, $conn){

    $sql = "DELETE FROM Club WHERE num_club = $club;";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function deleteEquipe($equipe, $conn){

    $sql = "DELETE FROM Equipe WHERE num_equipe = $equipe;";

    doRequest($sql, $conn);

    mysqli_close($conn);

}

function deleteJoueur($num_j, $conn){

    $sql = "DELETE FROM Joueur WHERE num_joueur = $num_j;";

    doRequest($sql, $conn);

    mysqli_close($conn);

}

function deletePersonne($num_p, $conn){

    $sql = "DELETE FROM Personne WHERE num_personne = $num_p;";

    doRequest($sql, $conn);

    mysqli_close($conn);
}

function deleteRencontre($num_r, $conn){

    $sql = "DELETE FROM Rencontre WHERE num_rencontre = $num_r;";

    doRequest($sql, $conn);

    mysqli_close($conn);
}


?>