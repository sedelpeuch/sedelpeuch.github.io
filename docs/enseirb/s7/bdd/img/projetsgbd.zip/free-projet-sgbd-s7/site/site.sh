printf "Lancement du site sur localhost:8000\n"

php -S localhost:8000