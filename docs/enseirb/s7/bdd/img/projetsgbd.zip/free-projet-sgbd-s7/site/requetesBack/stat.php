<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>


<!DOCTYPE html>
<html>
<head>

<title> SGBD Statistiques</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root . "/navbar.php");
?>


<?php

switch ($_REQUEST['frmname']){
    case "cla_eq":
        $top = mysqli_real_escape_string($conn, $_REQUEST['top']);
        showClaEq($top, $conn);
        break;
    case "moy_score_saison":
        $saison = mysqli_real_escape_string($conn, $_REQUEST['saison']);
        showMoySa($saison, $conn);
        break;
    case "moy_score_date":
        $date = mysqli_real_escape_string($conn, $_REQUEST['date']);
        showMoyDa($date, $conn);
        break;
    case "cla_j_date":
        $date = mysqli_real_escape_string($conn, $_REQUEST['date']);
        showClaJoDate($date, $conn);
        break;
    case "cla_j_saison":
        $saison = mysqli_real_escape_string($conn, $_REQUEST['saison']);
        $cate = mysqli_real_escape_string($conn, $_REQUEST['cate']);
        $top = mysqli_real_escape_string($conn, $_REQUEST['top']);
        showClaJoSaison($saison, $cate, $top, $conn);
        break;
    default:
        echo "commande inconnue ou non implémentée";
        break;
}

function showClaEq($top, $conn){
    echo "<center>
          <h1> Classment des equipes </h1>
          </center>";

    $sql = "CALL pClassementEquipes";

    $result = $conn->query($sql);

    while($data = mysqli_fetch_array($result))
    {
        $tableau[]=$data;
        //détermine le nombre de colonnes
        $nbcol=4;
    }

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','Place','</td>';
    echo '<th>','Equipe','</td>';
    echo '<th>','Matchs gagnés','</td>';
    echo '<th>','Matchs nuls','</td>';
    echo '<th>','Matchs perdus','</td>';
    echo '</tr>';

    $nb=count($tableau);

    if ($top == -1 or $top > $nb)
        $top = $nb;

    for($i=0;$i<$top;$i++){

    echo '<tr>';
    echo '<td>',$i+1,'</td>';
    echo '<td>',$tableau[$i]['Equipe'],'</td>';
    echo '<td>',$tableau[$i]['Gagnes'],'</td>';
    echo '<td>',$tableau[$i]['Nuls'],'</td>';
    echo '<td>',$tableau[$i]['Perdus'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
    $conn->close();
}

function showMoySa($saison,$conn){
    echo "<center>";
    echo "<h1> Moyenne des scores pour la saison ". $saison . "</h1>
          </center>";

    $sql = "CALL pMoyenneScoresSaison('". $saison ."')";

    $result = $conn->query($sql);

    while($data = mysqli_fetch_array($result))
    {
        $tableau[]=$data;
        //détermine le nombre de colonnes
        $nbcol=1;
    }

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','Moyenne scores','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['moyenne_scores_saison'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
    $conn->close();
}

function showMoyDa($date,$conn){
    echo "<center>";
    echo "<h1> Moyenne des scores pour la date ". $date . "</h1>
          </center>";

    $sql = "CALL pMoyenneScoresDate('". $date ."')";

    $result = $conn->query($sql);

    while($data = mysqli_fetch_array($result))
    {
        $tableau[]=$data;
        //détermine le nombre de colonnes
        $nbcol=1;
    }

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>', 'Date', '</td>';
    echo '<th>','Moyenne scores','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['date_rencontre'],'</td>';
    echo '<td>',$tableau[$i]['moyenne_scores'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
    $conn->close();
}

function showClaJoDate($date, $conn){
    echo "<center>";
    echo "<h1> Classement des joueurs pour la date ". $date . "</h1>
          </center>";

    $sql = "CALL pClassementJoueursDate('". $date ."')";

    $result = $conn->query($sql);

    while($data = mysqli_fetch_array($result))
    {
        $tableau[]=$data;
        //détermine le nombre de colonnes
        $nbcol=1;
    }

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>', 'Prenom', '</td>';
    echo '<th>','Nom','</td>';
    echo '<th>', 'Score', '</td>';
    echo '<th>','Fautes','</td>';
    echo '<th>', 'Numero equipe', '</td>';
    echo '<th>','Numero categorie','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['prenom'],'</td>';
    echo '<td>',$tableau[$i]['nom'],'</td>';
    echo '<td>',$tableau[$i]['score'],'</td>';
    echo '<td>',$tableau[$i]['fautes'],'</td>';
    echo '<td>',$tableau[$i]['num_equipe'],'</td>';
    echo '<td>',$tableau[$i]['num_categorie'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
    $conn->close();
}

function showClaJoSaison($saison, $cate, $top, $conn){
    echo "<center>";
    echo "<h1> Classement des joueurs pour la saison ". $saison . "</h1>
          </center>";

    $sql = "CALL pClassementJoueursSaison(" . "'$saison'" . "," . "'$cate'" . ")";

    $result = $conn->query($sql);

    while($data = mysqli_fetch_array($result))
    {
        $tableau[]=$data;
        //détermine le nombre de colonnes
        $nbcol=6;
    }


    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>', 'Place', '</td>';
    echo '<th>', 'Prenom', '</td>';
    echo '<th>','Nom','</td>';
    echo '<th>', 'Score', '</td>';
    echo '<th>','Fautes','</td>';
    echo '<th>', 'Numero equipe', '</td>';
    echo '<th>','Numero categorie','</td>';
    echo '</tr>';

    $nb=count($tableau);

    if ($top == -1 or $top > $nb)
        $top = $nb;

    for($i=0;$i<$top;$i++){

    echo '<tr>';
    echo '<td>',$i+1,'</td>';
    echo '<td>',$tableau[$i]['prenom'],'</td>';
    echo '<td>',$tableau[$i]['nom'],'</td>';
    echo '<td>',$tableau[$i]['score'],'</td>';
    echo '<td>',$tableau[$i]['fautes'],'</td>';
    echo '<td>',$tableau[$i]['num_equipe'],'</td>';
    echo '<td>',$tableau[$i]['num_categorie'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
    $conn->close();
}

?>
