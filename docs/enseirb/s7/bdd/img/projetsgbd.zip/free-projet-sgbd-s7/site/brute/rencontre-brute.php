<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title>SGBD Rencontre</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root . '/navbar.php');
?>

<center>
<h1> Table brute de Rencontre </h1>
</center>

<?php
$sql = "SELECT * FROM Rencontre";
$result = $conn->query($sql);
while($data = mysqli_fetch_array($result))
{
    $tableau[]=$data;
    //détermine le nombre de colonnes
    $nbcol=4;
}

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','numero rencontre','</td>';
    echo '<th>','date rencontre','</td>';
    echo '<th>','equipe 1','</td>';
    echo '<th>','equipe 2','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['num_rencontre'],'</td>';
    echo '<td>',$tableau[$i]['date_rencontre'],'</td>';
    echo '<td>',$tableau[$i]['num_equipe_1'],'</td>';
    echo '<td>',$tableau[$i]['num_equipe_2'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
$conn->close();
?>

</body>
</html>
