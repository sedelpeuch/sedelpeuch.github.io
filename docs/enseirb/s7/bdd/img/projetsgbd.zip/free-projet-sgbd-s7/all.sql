DROP DATABASE IF EXISTS handball;
system  echo "creating base"
SOURCE base.sql;
system echo "inserting data"
SOURCE insert.sql;
system echo "creating procedures"
SOURCE procedures.sql;
system echo "creating tests and triggers"
source tests.sql;
USE handball;

system clear;
system echo "+---------------------------------------------+";
system echo "|   \033[32mLa base de donnée \033[1mhandball\033[0m\033[32m a été crée\033[0m     |";
system echo "+---------------------------------------------+";
