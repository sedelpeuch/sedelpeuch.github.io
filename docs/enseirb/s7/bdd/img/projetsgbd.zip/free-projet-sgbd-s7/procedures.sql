DELIMITER | --change le delimiter de ';' à '|' obligatoire pour créer une proc
-- ça ne change le delimiter que pour la session courante
-- à la fin du fichier, on remet le délimiteur sur ';' 

-- convention utilisée : les paramètres sont précédés de p_
-- 						 les procédures commencent par p puis leur nom est écrit en camelCase
--						 les vues commencent par v puis leur nom est écrit en camelCase



-- montre le joueur à partir des données qu'on donne (qu'on les ait ou pas)
DROP PROCEDURE IF EXISTS pVoirJoueur|
CREATE PROCEDURE pVoirJoueur(IN p_nom VARCHAR(40),
							 IN p_prenom VARCHAR(40),
							 IN p_date_nai DATE,
							 IN p_adresse VARCHAR(100),
							 IN p_num_club INT,
							 IN p_date_club DATE,
							 IN p_num_equipe INT,
							 IN p_num_joueur INT)
BEGIN
SELECT nom, prenom, date_naissance, adresse, num_club, date_adhesion, num_equipe, num_joueur
FROM Joueur J
INNER JOIN Personne P ON J.num_joueur=P.num_personne 

WHERE nom          LIKE CASE WHEN p_nom=""                  THEN '%' ELSE p_nom        END
AND prenom         LIKE CASE WHEN p_prenom=""               THEN '%' ELSE p_prenom     END
AND date_naissance LIKE CASE WHEN p_date_nai="0000-01-01"   THEN '%' ELSE p_date_nai   END
AND adresse        LIKE CASE WHEN p_adresse=""              THEN '%' ELSE p_adresse    END
AND num_club       LIKE CASE WHEN p_num_club=-1             THEN '%' ELSE p_num_club   END
AND date_adhesion  LIKE CASE WHEN p_date_club="0000-01-01"  THEN '%' ELSE p_date_club  END
AND num_equipe     LIKE CASE WHEN p_num_equipe=-1           THEN '%' ELSE p_num_equipe END
AND num_joueur     LIKE CASE WHEN p_num_joueur=-1           THEN '%' ELSE p_num_joueur END;

END|



-- montre la personne à partir des données qu'on donne (qu'on les ait ou pas)
DROP PROCEDURE IF EXISTS pVoirPersonne|
CREATE PROCEDURE pVoirPersonne(IN p_nom VARCHAR(40),
							   IN p_prenom VARCHAR(40),
							   IN p_date_nai DATE,
							   IN p_adresse VARCHAR(100),
							   IN p_num_club INT,
							   IN p_date_club DATE,
							   IN p_fonction_c VARCHAR(40))
BEGIN
SELECT nom, prenom, date_naissance, adresse, num_club, date_adhesion, fonction
FROM Personne P

WHERE nom          LIKE CASE WHEN p_nom=""                  THEN '%' ELSE p_nom        END
AND prenom         LIKE CASE WHEN p_prenom=""               THEN '%' ELSE p_prenom     END
AND date_naissance LIKE CASE WHEN p_date_nai="0000-01-01"   THEN '%' ELSE p_date_nai   END
AND adresse        LIKE CASE WHEN p_adresse=""              THEN '%' ELSE p_adresse    END
AND num_club       LIKE CASE WHEN p_num_club=-1             THEN '%' ELSE p_num_club   END
AND date_adhesion  LIKE CASE WHEN p_date_club="0000-01-01"  THEN '%' ELSE p_date_club  END
AND fonction       LIKE CASE WHEN p_fonction_c=""           THEN '%' ELSE p_fonction_c END;

END|



-- montre la personne à partir des données qu'on donne (qu'on les ait ou pas)
DROP PROCEDURE IF EXISTS pVoirCategorie|
CREATE PROCEDURE pVoirCategorie(IN p_num_cat INT,
							    IN p_nom_cat VARCHAR(40))
BEGIN
SELECT num_categorie, nom_categorie
FROM Categorie C

WHERE num_categorie LIKE CASE WHEN p_num_cat=-1 THEN '%' ELSE p_num_cat END
AND nom_categorie   LIKE CASE WHEN p_nom_cat="" THEN '%' ELSE p_nom_cat END;

END|



-- montre l'équipe numéro p_num
DROP PROCEDURE IF EXISTS pVoirEquipe|
CREATE PROCEDURE pVoirEquipe(IN p_num INT)
BEGIN
SELECT nom, prenom, J.num_joueur, num_licence, SUM(Act.score) as score, SUM(Act.faute) as fautes, J.num_equipe, num_entraineur, nom_categorie
FROM Personne P
INNER JOIN Joueur J ON J.num_joueur = P.num_personne
INNER JOIN Action Act ON Act.num_joueur = J.num_joueur
INNER JOIN Equipe E ON J.num_equipe = E.num_equipe
INNER JOIN Categorie C ON E.num_categorie = C.num_categorie
WHERE E.num_equipe = p_num
GROUP BY nom, prenom, num_licence, J.num_joueur;
END|



-- montre le club numéro p_num
DROP PROCEDURE IF EXISTS pVoirClub|
CREATE PROCEDURE pVoirClub(IN p_num INT)
BEGIN
SELECT nom, prenom, date_naissance, num_licence, E.num_equipe
FROM Personne P
INNER JOIN Equipe E ON P.num_club = E.num_club
INNER JOIN Joueur J ON P.num_personne = J.num_joueur
WHERE E.num_club = p_num;
END|



-- montre l'action à partir des données qu'on donne (qu'on les ait ou pas)
DROP PROCEDURE IF EXISTS pVoirAction|
CREATE PROCEDURE pVoirAction(IN p_num_j INT,
						     IN p_num_r INT,
						     IN p_score INT,
						     IN p_faute INT)
BEGIN
SELECT num_rencontre, num_joueur, nom, prenom, score, faute
FROM Action A
INNER JOIN Personne P ON num_joueur = num_personne

WHERE num_rencontre LIKE CASE WHEN p_num_r=-1 THEN '%' ELSE p_num_r END
AND num_joueur      LIKE CASE WHEN p_num_j=-1 THEN '%' ELSE p_num_j END
AND score 			LIKE CASE WHEN p_score=-1 THEN '%' ELSE p_score END
AND faute        	LIKE CASE WHEN p_faute=-1 THEN '%' ELSE p_faute END;
END|


-- montre la rencontre à partir des données qu'on donne (qu'on les ait ou pas)
SET @maximum = -1;
SET @minimum = -1;
DROP PROCEDURE IF EXISTS pVoirRencontre|
CREATE PROCEDURE pVoirRencontre(IN p_date DATE,
						        IN p_equ_1 INT,
						        IN p_equ_2 INT)
BEGIN
SET @maximum = GREATEST(p_equ_1, p_equ_2);
SET @minimum = LEAST(p_equ_1, p_equ_2);

SELECT numR as num_rencontre, date_rencontre, EquA as equ_1, EquB as equ_2
FROM vRencontresResultat
INNER JOIN Rencontre R ON numR = R.num_rencontre 
WHERE date_rencontre LIKE CASE WHEN p_date="0000-01-01" THEN '%' ELSE p_date  END
AND EquA           LIKE CASE WHEN @minimum=-1          THEN '%' ELSE @minimum END
AND EquB           LIKE CASE WHEN @maximum=-1          THEN '%' ELSE @maximum END
ORDER BY numR ASC, EquA ASC, EquB ASC;
END|



-- montre les scores des matchs joués à la date p_date
-- la date doit être donnée sous le format 'yyyy-mm-dd'
DROP PROCEDURE IF EXISTS pVoirScoreMatch|
CREATE PROCEDURE pVoirScoreMatch(IN p_date DATE)
BEGIN
SELECT R.num_rencontre, num_equipe, date_rencontre, SUM(Act.score) AS scores
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
WHERE R.date_rencontre = p_date
GROUP BY num_rencontre, num_equipe, date_rencontre;
END|



-- montre la feuille résumée des matchs joués à la date p_date, et avec les bonnes équipes
-- Ne donne que le numéro de rencontre , les 2 équipes, leurs clubs, leur catégorie et leurs scores.
-- la date doit être donnée sous le format 'yyyy-mm-dd'
DROP PROCEDURE IF EXISTS pVoirFeuilleMatchResume|
CREATE PROCEDURE pVoirFeuilleMatchResume(IN p_date DATE, IN p_equ_1 INT, IN p_equ_2 INT)
BEGIN
-- Resumé matchs : numéros de rencontre, numéros d'équipe, n°club, n°catégorie, et scores
SELECT R.num_rencontre, E.num_equipe, num_club, SUM(Act.score) AS scores, Cat.num_categorie 
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
INNER JOIN Equipe E ON J.num_equipe = E.num_equipe
INNER JOIN Categorie Cat ON E.num_categorie = Cat.num_categorie
WHERE R.date_rencontre = p_date
AND (E.num_equipe = p_equ_1 OR E.num_equipe = p_equ_2) 
GROUP BY num_rencontre, num_equipe, num_club, nom_categorie;
END|



-- montre la feuille des matchs (version de base) joués à la date p_date, et avec les bonnes équipes
-- Donne le n° d'équipe, les joueurs (nom et prénom) et les scores et fautes de chacun
-- la date doit être donnée sous le format 'yyyy-mm-dd'
DROP PROCEDURE IF EXISTS pVoirFeuilleMatchDetail|
CREATE PROCEDURE pVoirFeuilleMatchDetail(IN p_date DATE, IN p_equ INT)
BEGIN
-- détail équipes : n°équipe, prenom & nom joueurs, leur score et leurs fautes
SELECT P.prenom, P.nom, Act.score AS scores, Act.faute AS fautes 
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
INNER JOIN Personne P ON P.num_personne = J.num_joueur
WHERE R.date_rencontre = p_date
AND J.num_equipe = p_equ;
END|



-- montre les rencontres auquelles le club p_num a participé
DROP PROCEDURE IF EXISTS pVoirRencontresClub|
CREATE PROCEDURE pVoirRencontresClub(IN p_num INT)
BEGIN
SELECT E.num_equipe, R.num_rencontre
FROM Club C
INNER JOIN Equipe E ON C.num_club = E.num_club
INNER JOIN Joueur J ON E.num_equipe = J.num_equipe
INNER JOIN Action Act ON J.num_joueur = Act.num_joueur
INNER JOIN Rencontre R ON Act.num_rencontre = R.num_rencontre
WHERE C.num_club = p_num
GROUP BY num_rencontre, num_equipe;
END|



-- Affiche la moyenne des scores des équipes d'une même journée
-- Exemple : si pour le jour J, on a 2 rencontres x et y, et que 
-- 15 et 25 points sont marqués lors de la rencontre x et 30 et 10
-- lors de la rencontre y, alors pMoyenneScoresDate('yyyy-mm-dd'); donne le tableau
-- +----------------+----------------+
-- | date_rencontre | moyenne_scores |
-- +----------------+----------------+
-- | yyyy-mm-dd     |        20.0000 |
-- +----------------+----------------+

DROP PROCEDURE IF EXISTS pMoyenneScoresDate|
CREATE PROCEDURE pMoyenneScoresDate(IN p_date DATE)
BEGIN
SELECT date_rencontre, AVG(scores) as moyenne_scores
FROM
(SELECT R.num_rencontre, date_rencontre, num_equipe, SUM(Act.score) AS scores
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
WHERE R.date_rencontre = p_date
GROUP BY date_rencontre, num_rencontre, num_equipe) as ScoresRencontre
GROUP BY date_rencontre;
END|



-- Moyenne des scores depuis le début de la saison en cours.
-- Usage : pMoyenneScoresSaison('2019') renvoie la moyenne des scores
-- par équipe des matchs sur la saison sept 2019 - aout 2020
DROP PROCEDURE IF EXISTS pMoyenneScoresSaison| -- arbre
CREATE PROCEDURE pMoyenneScoresSaison(IN p_date YEAR)
BEGIN
SELECT IFNULL(AVG(scores), 0) as moyenne_scores_saison
FROM
(SELECT R.num_rencontre, date_rencontre, num_equipe, SUM(Act.score) AS scores
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
WHERE R.date_rencontre > DATE_ADD('0000-09-01', INTERVAL p_date YEAR)
AND R.date_rencontre < DATE_ADD('0001-09-01', INTERVAL p_date YEAR) 
GROUP BY num_rencontre, date_rencontre, num_equipe) as ScoresSaison;
END|



-- Donne le classement des joueurs pour une date donnée.
-- Les joueurs sont classés par catégorie puis par score puis par fautes
DROP PROCEDURE IF EXISTS pClassementJoueursDate|
CREATE PROCEDURE pClassementJoueursDate(IN p_date DATE, IN p_cate INT)
BEGIN
SELECT P.prenom, P.nom, Act.score AS score, Act.faute AS fautes, J.num_equipe, Cat.num_categorie
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
INNER JOIN Personne P ON P.num_personne = J.num_joueur
INNER JOIN Equipe E ON J.num_equipe = E.num_equipe
INNER JOIN Categorie Cat ON E.num_categorie = Cat.num_categorie
WHERE R.date_rencontre = p_date
AND E.num_categorie LIKE CASE WHEN p_cate=-1 THEN '%' ELSE p_cate END
ORDER BY num_categorie DESC, score DESC, fautes ASC;
END|



-- Donne le classement des joueurs pour une saison donnée.
-- Les joueurs sont classés par catégorie puis par score puis par fautes
DROP PROCEDURE IF EXISTS pClassementJoueursSaison|
CREATE PROCEDURE pClassementJoueursSaison(IN p_date YEAR, IN p_cate INT)
BEGIN
SELECT P.prenom, P.nom, Act.score AS score, Act.faute AS fautes, J.num_equipe, Cat.num_categorie
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
INNER JOIN Personne P ON P.num_personne = J.num_joueur
INNER JOIN Equipe E ON J.num_equipe = E.num_equipe
INNER JOIN Categorie Cat ON E.num_categorie = Cat.num_categorie
WHERE R.date_rencontre > DATE_ADD('0000-09-01', INTERVAL p_date YEAR)
AND R.date_rencontre < DATE_ADD('0001-09-01', INTERVAL p_date YEAR) 
AND E.num_categorie LIKE CASE WHEN p_cate=-1 THEN '%' ELSE p_cate END
ORDER BY num_categorie DESC, score DESC, fautes ASC;
END|



-- Vue utilisée pour le classement des équipes
CREATE OR REPLACE VIEW vRencontresEtScores AS
SELECT R.num_rencontre as numR, E.num_equipe as numE, SUM(Act.score) AS scores
FROM Rencontre R
INNER JOIN Action Act ON R.num_rencontre = Act.num_rencontre
INNER JOIN Joueur J ON Act.num_joueur = J.num_joueur
INNER JOIN Equipe E ON J.num_equipe = E.num_equipe
INNER JOIN Categorie Cat ON E.num_categorie = Cat.num_categorie
GROUP BY numR, numE, num_club|

-- Vue utilisée pour le classement des équipes
CREATE OR REPLACE VIEW vRencontresResultat AS
SELECT A.numR, A.numE as EquA, B.numE as EquB, A.scores as Ascores, B.scores as Bscores
FROM vRencontresEtScores as A
INNER JOIN vRencontresEtScores as B
ON A.numR = B.numR
WHERE A.numE != B.numE|

-- Création la vue du classement des équipes
-- Donne le classement des Équipes en les triant par nombre de matchs gagnés puis nuls puis perdus
CREATE OR REPLACE VIEW vClassementEquipes AS

SELECT Equipe.num_equipe as Equipe, ifnull(matchs_gagnes, 0) as Gagnes, ifnull(matchs_nuls, 0) as Nuls, ifnull(matchs_perdus, 0) as Perdus
FROM Equipe
LEFT JOIN
-- #########################  NULS  #########################
(SELECT EquA as Equipe, COUNT(EquA) as matchs_nuls
FROM vRencontresResultat
WHERE Ascores = Bscores
GROUP BY EquA) as count_nuls ON Equipe.num_equipe = count_nuls.Equipe

LEFT JOIN
-- ######################### GAGNÉS #########################
(SELECT EquA as Equipe, COUNT(EquA) as matchs_gagnes
FROM vRencontresResultat
WHERE Ascores > Bscores
GROUP BY EquA) as count_gagnes ON Equipe.num_equipe = count_gagnes.Equipe

LEFT JOIN
-- ######################### PERDUS #########################
(SELECT EquA as Equipe, COUNT(EquA) as matchs_perdus
FROM vRencontresResultat
WHERE Ascores < Bscores
GROUP BY EquA) as count_perdus ON Equipe.num_equipe = count_perdus.Equipe

ORDER BY matchs_gagnes DESC, matchs_nuls DESC, matchs_perdus ASC|



-- procédure qui renvoie le classement des équipes.
-- elle ne fait qu'afficher la vue vClassementEquipes. 
DROP PROCEDURE IF EXISTS pClassementEquipes|
CREATE PROCEDURE pClassementEquipes()
BEGIN
SELECT * from vClassementEquipes;
END|



DROP PROCEDURE IF EXISTS pMatchsEquipe|
CREATE PROCEDURE pMatchsEquipe(IN p_int INT)
BEGIN
SELECT * from vClassementEquipes
WHERE Equipe = p_int;
END|



DROP PROCEDURE IF EXISTS pTests|
CREATE PROCEDURE pTests()
BEGIN

select "pVoirJoueur('','','0000-01-01','',-1,'0000-01-01',-1,-1)" AS 'TEST PROCEDURE 1/17:';
CALL pVoirJoueur('eva','','0000-01-01','',-1,'0000-01-01',-1,-1);
select "pVoirPersonne('','','0000-01-01','',-1,'0000-01-01','')" AS 'TEST PROCEDURE 2/17:';
CALL pVoirPersonne('','','0000-01-01','',-1,'0000-01-01','');
select "pVoirCategorie(1, '')" AS 'TEST PROCEDURE 3/17:';
CALL pVoirCategorie(1, '');
select "pVoirEquipe(1)" AS 'TEST PROCEDURE 4/17:';
CALL pVoirEquipe(1);
select "PpVoirClub(1)" AS 'TEST PROCEDURE 5/17:';
CALL pVoirClub(1);
select "pVoirAction(-1,-1,-1,-1)" AS 'TEST PROCEDURE 6/17:';
CALL pVoirAction(-1,-1,-1,-1);
select"pVoirRencontre('0000-01-01',-1,-1)" AS 'TEST PROCEDURE 7/17:';
CALL pVoirRencontre('0000-01-01',-1,-1);
select "pVoirScoreMatch('2017-11-21')" AS 'TEST PROCEDURE 8/17:';
CALL pVoirScoreMatch('2017-11-21');
select "pVoirFeuilleMatchResume('2020-02-07', 2, 45)" AS 'TEST PROCEDURE 9/17:';
CALL pVoirFeuilleMatchResume('2020-02-07', 2, 45);
select "pVoirFeuilleMatchDetail'2020-02-07', 45)" AS 'TEST PROCEDURE 10/17:';
CALL pVoirFeuilleMatchDetail('2020-02-07', 45);
select "pVoirRencontresClub(1)" AS 'TEST PROCEDURE 11/17:';
CALL pVoirRencontresClub(1);
select "pMoyenneScoresDate('2017-11-21')" AS 'TEST PROCEDURE 12/17:';
CALL pMoyenneScoresDate('2017-11-21');
select "pMoyenneScoresSaison('2019')" AS 'TEST PROCEDURE 13/17:';
CALL pMoyenneScoresSaison('2019');
select "pClassementJoueursDate('2017-11-21', -11)" AS 'TEST PROCEDURE 14/17:';
CALL pClassementJoueursDate('2017-11-21', -1);
select "pClassementJoueursSaison('2019', -1)" AS 'TEST PROCEDURE 15/17:';
CALL pClassementJoueursSaison('2019', -1);
select "pClassementEquipes()" AS 'TEST PROCEDURE 16/17:';
CALL pClassementEquipes();
select "pMatchsEquipe(1)" AS 'TEST PROCEDURE 17/17:';
CALL pMatchsEquipe(1);

END|

DELIMITER ;


-- drop database handball; source base.sql; source insert.sql; source procedures.sql;
-- dernier commit : petit fix de la procédure de recherche de rencontre.


