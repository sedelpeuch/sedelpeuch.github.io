LOAD DATA INFILE '/var/lib/mysql-files/Club.csv'
INTO TABLE Club
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(num_club);

LOAD DATA INFILE '/var/lib/mysql-files/Personne.csv'
INTO TABLE Personne
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(nom, prenom, date_naissance, adresse, date_adhesion, fonction, num_club);



LOAD DATA INFILE '/var/lib/mysql-files/Categorie.csv'
INTO TABLE Categorie
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(nom_categorie);

LOAD DATA INFILE '/var/lib/mysql-files/Equipe.csv'
INTO TABLE Equipe
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(num_equipe, num_entraineur, num_categorie, niveau, num_club);

LOAD DATA INFILE '/var/lib/mysql-files/Rencontre.csv'
INTO TABLE Rencontre
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(date_rencontre, num_equipe_1, num_equipe_2);

LOAD DATA INFILE '/var/lib/mysql-files/Joueur.csv'
INTO TABLE Joueur
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(num_joueur, num_equipe);

LOAD DATA INFILE '/var/lib/mysql-files/Action.csv'
    INTO TABLE Action
    FIELDS TERMINATED BY ','
    ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
    IGNORE 1 ROWS
(num_joueur, num_rencontre, score, faute, titulaire);
