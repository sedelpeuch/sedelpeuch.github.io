## Groupe 

+ DECOU Nathan 
+ DELPEUCH Sébastien 
+ PRINGALLE Antoine
+ TROLES Killian

## Manuel d'utilisation

Dans un premier temps il faut posséder les paquets suivants `mysql`, `php`,
`python3`, `php-mysql`, `apache2` et `mysql-server`. Sur Ubuntu les paquets sont installables grâce à la commande `sudo apt install <nom>`.

Une fois les différents paquets installés vous devez récupérer notre livrable. L'archive comprenant le livrable est disponible [ici](https://sdelpeuch.github.io/projetsgbd.zip).

Si vous n'avez pas de jeu de données il vous faut créer ce dernier. Pour cela
déplacez vous à la racine du projet et exécutez la commande 

``` python
python3 generator/main.py
```


Cela va générer des fichiers `.csv` dans le dossier `generated_csv_file/`. Il faut ensuite placer ces fichiers dans le dossier sécurisé de mysql (ou définir le dossier précédent comme sécurisé pour mysql). Sur ubuntu ce dossier se trouve dans `/var/lib/mysql-file/`. Si vous avez déjà un jeu de données, il suffit de les placer dans le dossier sécurisé.

Il faut ensuite démarrer et se connecter à mysql en lançant simplement la
commande  `mysql`. Une fois connecté vous pouvez réaliser la commande `source
all.sql` pour initialiser la base. Vous pouvez lancer une série de test via la
commande `CALL allTests()` pour vérifier que la base est correcte.

À ce stade vous pouvez, si vous le souhaitez quitter mysql avec `exit`. Pour
lancer l'interface vous devez vous déplacer dans le dossier `site/`, dans ce
dossier vous devez modifier le fichier `connectdb.php`, plus particulièrement
les champs `$username` et `$password` (ce sont les mêmes identifiant que pour
se connecter à mysql). 

Si vous ne possédez pas s'identifiant particulier pour mysql et que vous lancez
ce dernier avec `sudo mysql` il faudra alors mettre le `$username` à `root` et le
`$password` vide. Il faudra ensuite lancer la commande `sudo php -S
localhost:8000` et se rendre à l'adresse `localhost:8000`.

Sinon une fois le fichier enregistré lancer le script `site.sh` puis allez dans votre navigateur à l'adresse `localhost:8000`.

Vous pouvez maintenant naviguer dans le site et réaliser les différentes opérations souhaitées, la description de l'utilisation du site n'est pas réalisée ici puisqu'elle est relativement intuitive. Une précision est tout de même apportée, lorsque vous faites des insertions ou des suppressions avec les formulaires aucune vérification n'est réalisée directement sur les formulaires. Si votre saisie est incorecte vous obtiendrez une erreur provenant de mysql.

Si vous ne parvenez pas à lancer le projet contactez l'équipe.
