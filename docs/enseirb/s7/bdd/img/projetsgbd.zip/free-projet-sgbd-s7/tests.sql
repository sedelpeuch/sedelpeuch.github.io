DELIMITER | --change le delimiter de ';' à '|' obligatoire pour créer une proc
-- ça ne change le delimiter que pour la session courante
-- à la fin du fichier, on remet le délimiteur sur ';'



DROP PROCEDURE IF EXISTS tNombreJoueursEquipe|
CREATE PROCEDURE tNombreJoueursEquipe(IN p_equipe INT, OUT p_nombreJoueurs INT)
BEGIN
SELECT COUNT(*) INTO p_nombreJoueurs
FROM Joueur
WHERE num_equipe = p_equipe;
END|

DROP PROCEDURE IF EXISTS assertNombreJoueursEquipe|
CREATE PROCEDURE assertNombreJoueursEquipe()
BEGIN
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE equipe INT;
    DECLARE curEquipe CURSOR FOR SELECT num_equipe FROM Equipe;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN curEquipe;

    getJoueur: LOOP
        FETCH curEquipe INTO equipe;
        IF done THEN
            LEAVE getJoueur;
        END IF;
        CALL tNombreJoueursEquipe(equipe, @nombreJoueurs);
        IF @nombreJoueurs NOT BETWEEN 7 AND 15 THEN
            SELECT CONCAT('Nombre incorrect de joueurs : Equipe ', equipe, ', Nombre : ', @nombreJoueurs)
                AS 'ERREUR';
            INSERT INTO Erreur (msg_erreur) VALUE ('Nombre incorrect de joueurs dans une equipe');
        END IF;
    END LOOP getJoueur;

    CLOSE curEquipe;
END|

-- Verifie si l'equipe dans laquelle joue le Joueur a bien participe a la rencontre
DROP PROCEDURE IF EXISTS tJoueurAParticipeRencontre|
CREATE PROCEDURE tJoueurAParticipeRencontre(IN p_joueur INT, IN p_rencontre INT, OUT aParticipe INT)
BEGIN
    SELECT COUNT(*) INTO aParticipe
    FROM Rencontre R
    INNER JOIN Joueur J ON p_joueur = J.num_joueur
    WHERE R.num_rencontre = p_rencontre
    AND (J.num_equipe = R.num_equipe_1
        OR J.num_equipe = R.num_equipe_2);
END |

DROP PROCEDURE IF EXISTS assertActionJoueurAParticipe|
CREATE PROCEDURE assertActionJoueurAParticipe()
BEGIN
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE joueur INT;
    DECLARE rencontre INT;
    DECLARE curAction CURSOR FOR SELECT num_joueur, num_rencontre FROM Action;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN curAction;

    getAction: LOOP
        FETCH curAction INTO joueur, rencontre;
        IF done THEN
            LEAVE getAction;
        END IF;
        CALL tJoueurAParticipeRencontre(joueur, rencontre, @actionCorrecte);
        IF @actionCorrecte = 0 THEN
            SELECT CONCAT('Action incorrecte : Joueur ', joueur, ' n a pas participe a la Rencontre ', rencontre)
                AS 'ERREUR';
            INSERT INTO Erreur (msg_erreur)
            VALUE ('Action d un Joueur qui n est pas dans une Equipe ayant participe a la Rencontre');
        END IF;
    END LOOP getAction;

    CLOSE curAction;
END|

DROP PROCEDURE IF EXISTS tRencontreMemeEquipe|
CREATE PROCEDURE tRencontreMemeEquipe(IN p_rencontre INT, OUT p_boolean INT)
BEGIN
    SELECT COUNT(*) INTO p_boolean
    FROM Rencontre
    WHERE num_rencontre = p_rencontre
    AND num_equipe_1 = num_equipe_2;
END |


DROP PROCEDURE IF EXISTS assertRencontre|
CREATE PROCEDURE assertRencontre()
BEGIN
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE rencontre INT;
    DECLARE curRencontre CURSOR FOR SELECT num_rencontre FROM Rencontre;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN curRencontre;

    getRencontre: LOOP
        FETCH curRencontre INTO rencontre;
        IF done THEN
            LEAVE getRencontre;
        END IF;

        -- Verifie qu'une equipe ne joue pas contre elle meme dans une Rencontre
        CALL tRencontreMemeEquipe(rencontre, @estMemeEquipe);
        IF @estMemeEquipe = 1 THEN
            SELECT CONCAT('Rencontre ', rencontre, ' incorrecte : les deux equipes participantes sont identiques')
                       AS 'ERREUR';
            INSERT INTO Erreur (msg_erreur)
                VALUE ('Une equipe ne peut pas s affronter elle-meme lors d une Rencontre');
        END IF;

        -- Verifie qu'il y a bien 14 joueurs titulaires pour chaque Rencontre
        CALL tActionNombreTitulairesRencontre(rencontre, @nbTitulaires);
        IF @nbTitulaires != 14 THEN
            SELECT CONCAT('Rencontre ', rencontre, ' : nombre incorrect de titulaires : ', @nbTitulaires, ' (voir Action)')
            AS 'ERREUR';
            INSERT INTO Erreur (msg_erreur) VALUE ('Il doit y avoir 14 titulaires par Rencontre');
        END IF;

        -- Verifie que la date des Rencontres est bien passee ou aujourd'hui
        CALL tRencontreDatePassee(rencontre, @datePassee);
        IF @datePassee = 0 THEN
            SELECT CONCAT('Rencontre ', rencontre, ' : date incorrecte (pas encore passee)')
            AS 'ERREUR';
            INSERT INTO Erreur (msg_erreur) VALUE ('La date de la Rencontre doit etre passee ou aujourd hui');
        END IF;

        -- Verifie que les 2 equipes qui s'affrontent jouent dans la meme Categorie
        CALL tRencontreEquipes(rencontre, @equipe_1, @equipe_2);
        CALL tRencontreMemeCategorie(@equipe_1, @equipe_2, @memeCatagorie);
        IF @memeCatagorie = 0 THEN
            SELECT CONCAT('Rencontre ', rencontre, ' : les categories des deux equipes s affrontant ne sont pas les memes')
            AS 'ERREUR';
            INSERT INTO Erreur (msg_erreur) VALUE ('Les deux equipes s affrontant ne sont pas dans la meme categorie');
        END IF;
    END LOOP getRencontre;

    CLOSE curRencontre;
END|

DROP PROCEDURE IF EXISTS tActionNombreTitulairesRencontre|
CREATE PROCEDURE tActionNombreTitulairesRencontre(IN p_rencontre INT, OUT p_nombre INT)
BEGIN
    SELECT COUNT(*) INTO p_nombre
    FROM Action
    WHERE num_rencontre = p_rencontre
    AND titulaire = 1;
END |

DROP PROCEDURE IF EXISTS tRencontreDatePassee|
CREATE PROCEDURE tRencontreDatePassee(IN p_rencontre INT, OUT p_boolean INT)
BEGIN
    SELECT COUNT(*) INTO p_boolean
    FROM Rencontre
    WHERE num_rencontre = p_rencontre
    AND date_rencontre <= CURDATE();
END |

DROP PROCEDURE IF EXISTS tRencontreEquipes|
CREATE PROCEDURE tRencontreEquipes(IN p_rencontre INT, OUT p_equipe_1 INT, OUT p_equipe_2 INT)
BEGIN
    SELECT num_equipe_1 INTO p_equipe_1
    FROM Rencontre
    WHERE num_rencontre = p_rencontre;
    SELECT num_equipe_2 INTO p_equipe_2
    FROM Rencontre
    WHERE num_rencontre = p_rencontre;
END |

DROP PROCEDURE IF EXISTS tRencontreMemeCategorie|
CREATE PROCEDURE tRencontreMemeCategorie(IN p_equipe_1 INT, IN p_equipe_2 INT, OUT p_boolean INT)
BEGIN
    DECLARE categorie_1 INT;
    DECLARE categorie_2 INT;

    SELECT num_categorie INTO categorie_1
    FROM Equipe
    WHERE num_equipe = p_equipe_1;

    SELECT num_categorie INTO categorie_2
    FROM Equipe
    WHERE num_equipe = p_equipe_2;

    IF categorie_1 = categorie_2 THEN
        SET p_boolean := 1;
    ELSE
        SET p_boolean := 0;
    END IF;
END |


DROP PROCEDURE IF EXISTS allTests|
CREATE PROCEDURE allTests()
BEGIN
    CALL assertNombreJoueursEquipe();       -- Verifie que chaque Equipe a entre 7 et 15 joueurs
    CALL assertActionJoueurAParticipe();    -- Verifie pour chaque Action que le joueur a bien joue la Rencontre
    CALL assertRencontre();                 -- Verifie que les deux equipes de la Rencontre ne sont pas les memes
                                            -- et qu'il y a exactement 14 titulaires par Rencontre
                                            -- et que la date de Rencontre est passee ou aujourd'hui
END|


-- ====== TRIGGERS ======

DROP TRIGGER IF EXISTS tInsertJoueur|
CREATE TRIGGER tInsertJoueur BEFORE INSERT
ON Joueur FOR EACH ROW
BEGIN
    CALL tNombreJoueursEquipe(NEW.num_equipe, @nb);
    IF @nb >= 15 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Nombre incorrect de joueurs dans une equipe');
    END IF;
END|

DROP TRIGGER IF EXISTS tDeleteJoueur|
CREATE TRIGGER tDeleteJoueur BEFORE DELETE
ON Joueur FOR EACH ROW
BEGIN
    CALL tNombreJoueursEquipe(OLD.num_equipe, @nb);
    IF @nb <= 7 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Nombre incorrect de joueurs dans une equipe');
    END IF;
END |

DROP TRIGGER IF EXISTS tUpdateJoueur|
CREATE TRIGGER tUpdateJoueur BEFORE UPDATE
ON Joueur FOR EACH ROW
BEGIN
    IF NEW.num_equipe != OLD.num_equipe THEN
        CALL tNombreJoueursEquipe(OLD.num_equipe, @nbOld);
        CALL tNombreJoueursEquipe(NEW.num_equipe, @nbNew);
        IF @nbOld <= 7 OR @nbNew >= 15 THEN
            INSERT INTO Erreur (msg_erreur) VALUE ('Nombre incorrect de joueurs dans une equipe');
        END IF;
    END IF;
END |


DROP TRIGGER IF EXISTS tInsertAction|
CREATE TRIGGER tInsertAction BEFORE INSERT
ON Action FOR EACH ROW
BEGIN
    CALL tJoueurAParticipeRencontre(NEW.num_joueur, NEW.num_rencontre, @equipeAParticipe);
    IF @equipeAParticipe = 0 THEN
        INSERT INTO Erreur (msg_erreur)
        VALUE ('Action d un Joueur qui n est pas dans une Equipe ayant participe a la Rencontre');
    END IF;

    CALL tActionNombreTitulairesRencontre(NEW.num_rencontre, @nbTitulaires);
    IF @nbTitulaires = 14 AND NEW.titulaire = 1 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Il doit y avoir 14 titulaires par Rencontre');
    END IF;
END |

DROP TRIGGER IF EXISTS tUpdateAction|
CREATE TRIGGER tUpdateAction BEFORE UPDATE
ON Action FOR EACH ROW
BEGIN
    CALL tJoueurAParticipeRencontre(NEW.num_joueur, NEW.num_rencontre, @equipeAParticipe);
    IF @equipeAParticipe = 0 THEN
        INSERT INTO Erreur (msg_erreur)
            VALUE ('Action d un Joueur qui n est pas dans une Equipe ayant participe a la Rencontre');
    END IF;

    CALL tActionNombreTitulairesRencontre(OLD.num_rencontre, @nbTitulairesOld);
    IF @nbTitulairesOld = 14 AND OLD.titulaire = 1 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Il doit y avoir 14 titulaires par Rencontre');
    END IF;

    CALL tActionNombreTitulairesRencontre(NEW.num_rencontre, @nbTitulairesNew);
    IF @nbTitulairesNew = 14 AND NEW.titulaire = 1 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Il doit y avoir 14 titulaires par Rencontre');
    END IF;
END |

DROP TRIGGER IF EXISTS tDeleteAction|
CREATE TRIGGER tDeleteAction BEFORE DELETE
    ON Action FOR EACH ROW
BEGIN
    CALL tActionNombreTitulairesRencontre(OLD.num_rencontre, @nbTitulaires);
    IF @nbTitulaires = 14 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Il doit y avoir 14 titulaires par Rencontre');
    END IF;
END |

DROP TRIGGER IF EXISTS tInsertRencontre|
CREATE TRIGGER tInsertRencontre BEFORE INSERT
ON Rencontre FOR EACH ROW
BEGIN
    IF NEW.num_equipe_1 = NEW.num_equipe_2 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Une equipe ne peut pas s affronter elle-meme lors d une Rencontre');
    END IF;

    IF NEW.date_rencontre > CURDATE() THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('La date de la Rencontre doit etre passee ou aujourd hui');
    END IF;

    CALL tRencontreMemeCategorie(NEW.num_equipe_1, NEW.num_equipe_2, @memeCatagorie);
    IF @memeCatagorie = 0 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Les deux equipes s affrontant ne sont pas dans la meme categorie');
    END IF;
END |

DROP TRIGGER IF EXISTS tUpdateRencontre|
CREATE TRIGGER tUpdateRencontre BEFORE UPDATE
ON Rencontre FOR EACH ROW
BEGIN
    IF NEW.num_equipe_1 = NEW.num_equipe_2 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Une equipe ne peut pas s affronter elle-meme lors d une Rencontre');
    END IF;

    IF NEW.date_rencontre > CURDATE() THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('La date de la Rencontre doit etre passee ou aujourd hui');
    END IF;


    CALL tRencontreMemeCategorie(NEW.num_equipe_1, NEW.num_equipe_2, @memeCatagorie);
    IF @memeCatagorie = 0 THEN
        INSERT INTO Erreur (msg_erreur) VALUE ('Les deux equipes s affrontant ne sont pas dans la meme categorie');
    END IF;
END |

DELIMITER  ;

