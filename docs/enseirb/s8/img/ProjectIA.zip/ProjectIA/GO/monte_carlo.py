# -*- coding: utf-8 -*-
''' This is the file you have to modify for the tournament. Your default AI player must be called by this module, in the
myPlayer class.

Right now, this class contains the copy of the randomPlayer. But you have to change this!
'''
import random
import time
import Goban
from playerInterface import *
import copy
import signal


def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((te - ts) * 1000)
        else:
            print('%r  %2.2f ms' % \
                  (method.__name__, (te - ts) * 1000))
        return result

    return timed


# handling timeout
def handler(signum, frame):
    print("I've timeout")
    raise Exception("Timeout")


class myPlayer(PlayerInterface):
    ''' Example of a random player for the go. The only tricky part is to be able to handle
    the internal representation of moves given by legal_moves() and used by push() and
    to translate them to the GO-move strings "A1", ..., "J8", "PASS". Easy!

    '''

    def __init__(self):
        self._board = Goban.Board()
        self._mycolor = None
        self._time_left = 60 * 8
        self._hash_dic = {}

    def getPlayerName(self):
        return "monte carlo"

    @timeit
    def getPlayerMove(self):
        t = time.time()
        signal.alarm(15)
        signal.signal(signal.SIGALRM, handler)
        if self._board.is_game_over():
            print("i have {0}s left".format(self._time_left))
            print("Referee told me to play but the game is over!")
            return "PASS"
        move = self.monte_carlo(iterations=5, popu_ratio=0.5)
        self._board.push(move)
        self._time_left -= time.time() - t
        signal.alarm(0)
        return Goban.Board.flat_to_name(move)

    def playOpponentMove(self, move):
        print("Opponent played ", move)  # New here
        # the board needs an internal represetation to push the move.  Not a string
        self._board.push(Goban.Board.name_to_flat(move))

    def newGame(self, color):
        self._mycolor = color
        self._opponent = Goban.Board.flip(color)

    def endGame(self, winner):
        if self._mycolor == winner:
            print("I won!!!")
        else:
            print("I lost :(!!")

    def monte_carlo(self, iterations, popu_ratio):
        legal_moves = self._board.legal_moves()
        population = max(30, int(len(legal_moves)*popu_ratio))
        print("popu sample size", population)
        moves = random.choices(legal_moves[:-1] + [-1], k=population)
        best_move = random.choice(moves)
        max_win = 0
        for m in moves:
            try:
                if self._board.is_game_over():
                    return best_move
                self._board.push(m)
                wins = 0
                for _ in range(iterations):
                    res = self.random_game_ite(depth=20)
                    if res == self._mycolor:
                        wins += 1
                if wins > max_win:
                    max_win = wins
                    best_move = m
                self._board.pop()
            except Exception:
                return best_move
        return best_move

    def random_game_to_game_over(self):
        board = copy.deepcopy(self._board)
        while (not board.is_game_over()):
            moves = board.legal_moves()
            m = random.choice(moves)
            board.push(m)
        if board.is_game_over():
            result = board.result()
            if result == "1-0":
                return board.WHITE
            elif result == "0-1":
                return board.BLACK
            else:
                return 0

    def random_game_ite(self, depth=10):
        board = copy.deepcopy(self._board)
        for _ in range(depth):
            if board.is_game_over():
                result = board.result()
                if result == "1-0":
                    return board.WHITE
                elif result == "0-1":
                    return board.BLACK
                else:
                    return 0
            moves = board.legal_moves()
            m = random.choice(moves)
            board.push(m)
        hash = str(board._currentHash)
        if hash in self._hash_dic.keys():
            CRED = '\033[91m'
            CEND = '\033[0m'
            print(CRED+"I've already calculated that outcome"+CEND)
            return self._hash_dic[hash]

        b_score, w_score = board.compute_score()
        if b_score > w_score:
            actual_winner = board.BLACK
        elif b_score < w_score:
            actual_winner = board.WHITE
        else:
            actual_winner = 0
        self._hash_dic[hash] = actual_winner
        return actual_winner
