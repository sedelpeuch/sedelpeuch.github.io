# -*- coding: utf-8 -*-
"""
En accord avec les consignes nous avons placé notre joueur par défaut dans ce fichier. Ce fichier est donc une copie du
du fichier alpha_beta.py
"""
import random
import time
import Goban
from playerInterface import *
import heuristic


def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((te - ts) * 1000)
        else:
            print('%r  %2.2f ms' % \
                  (method.__name__, (te - ts) * 1000))
        return result

    return timed


class myPlayer(PlayerInterface):
    """
    Classe permettant de respecter l'interface du joueur tout en implémentant le joueur alphaBeta
    """
    def __init__(self):
        # Mémorisation du nombre de tours pour que la profondeur de parcours en début de partie soit faible
        self._nb_turn = 0
        self._board = Goban.Board()
        self._mycolor = None
        # Mémorisation du dernier coup adverse que nous obtenons avec playOpponentMove
        self.last_opponent_move = None
        # Définition de l'heuristique en utilisant notre classe heuristic
        self._heuristic = heuristic.HeuristicBoard(self._board, self._mycolor).heuristic_on_lines

    def getPlayerName(self):
        return "AlphaBeta Player"

    def getPlayerMove(self):
        """
        Cette fonction appelle best_move avec différentes profondeur pour l'alpha beta en fonction de la situation :
        + Si il reste moins de 20 coups possibles : profondeur 3
        + Si il reste moins de 10 coups possibles : profondeur 4
        + Si moins de 10 coups ont été joués depuis le début de la partie : profondeur 1
        + Sinon : profondeur 2
        @return: le coup que nous voulons jouer
        """
        self._nb_turn += 1
        # Mettre fin à la partie
        if self._board.is_game_over():
            return "PASS"
        moves = self._board.legal_moves()
        if len(moves) < 20:
            move = self.best_move(moves, 3)
        elif len(moves) < 10:
            move = self.best_move(moves, 4)
        elif self._nb_turn < 10:
            move = self.best_move(moves, 1)
        else:
            move = self.best_move(moves, 2)
        self._board.push(move)
        return Goban.Board.flat_to_name(move)

    def playOpponentMove(self, move):
        """
        Permet de mettre à jour notre plateau avec le coup adverse et de le mémoriser
        @param move: le coup adverse
        """
        print("Opponent played ", move)
        # Mémorisation du dernier coup joué par l'adversaire
        self.last_opponent_move = move
        self._board.push(Goban.Board.name_to_flat(move))

    def newGame(self, color):
        self._mycolor = color
        self._opponent = Goban.Board.flip(color)

    def endGame(self, winner):
        if self._mycolor == winner:
            print("I won!!!")
        else:
            print("I lost :(!!")

    @timeit
    def best_move(self, moves, depth):
        """
        Cette fonction est la fonction principale de notre joueur. En fonction d'une liste de coups possibles et de la
        profondeur de recherche souhaitée elle va parcourir l'arbre des parties (avec l'algorithme alphaBeta) et trouver
        quelle partie à l'heuristique la plus avantageuse pour nous.
        @param moves: Les coups possibles (retour de la fonction legals_moves ou weak_legals_moves)
        @param depth: La profondeur de recherche souhaitée pour l'alphaBeta
        @return: le coup associé à la branche de l'arbre des parties la plus avantageuse pour nous
        """
        # Initialisation
        best_score = -100000
        best_move = random.choice(moves)
        if self._board.is_game_over():
            return -1

        # Si le joueur précédent à PASS et que nous avons un meilleur score que lui nous passons aussi pour mettre fin
        # à la partie
        if self.last_opponent_move == 'PASS':
            if self._board.compute_score()[self._mycolor - 1] > self._board.compute_score()[
                self._board.flip(self._mycolor) - 1]:
                return -1

        # Permet de mélanger les coups pour ne pas remplir le plateau de bas à gauche à en haut à droite
        # et provoquer plus de situations où il y a des captures possibles
        random.shuffle(moves)
        for m in moves:
            self._board.push(m)
            tmp = self.min_alpha_beta(-10000, 10000, depth - 1, self._mycolor)
            if tmp > best_score:
                best_score = tmp
                best_move = m
            self._board.pop()
        return best_move

    def min_alpha_beta(self, alpha, beta, depth, color):
        """
        Implémentation de l'algorithme alphaBeta version minimisante
        """
        if depth == 0 or self._board.is_game_over():
            return self._heuristic(color)
        for m in self._board.weak_legal_moves():
            self._board.push(m)
            val = self.max_alpha_beta(alpha, beta, depth - 1, color)
            self._board.pop()
            if val <= beta:
                beta = val
            if alpha >= beta:
                return alpha
        return beta

    def max_alpha_beta(self, alpha, beta, depth, color):
        """
        Implémentation de l'algorithme alphaBeta version maximisante
        """
        if depth == 0 or self._board.is_game_over():
            return self._heuristic(color)
        for m in self._board.weak_legal_moves():
            self._board.push(m)
            val = self.min_alpha_beta(alpha, beta, depth - 1, color)
            self._board.pop()
            if val >= alpha:
                alpha = val
            if alpha >= beta:
                return beta
        return alpha

    @property
    def mycolor(self):
        return self._mycolor
