"""
Fichier permettant d'implémenter l'heuristique que nous utilisons pour nos algorithmes miniMax et alphaBeta
"""
import Goban

class HeuristicBoard():
    """
    Classe regroupant les différentes fonctions utiles pour l'heuristique
    """
    def __init__(self, board, mycolor):
        self._board = board
        self._mycolor = mycolor
        # Dictionnaire ayant pour clé un hash et pour valeur la valeur de l'heuristique correspondante à ce hash
        self._hash_dict = {}

    def keep_hash_cost(self, value):
        """
        Enregistre le couple clé : valeur dans _hash_dict
        @param value: la valeur de l'heuristique pour cette configuration de partie
        """
        self._hash_dict[str(self._board._currentHash)] = value

    def check_hash(self):
        """
        Vérifie si le hash de la partie en cours est déjà enregistrée dans notre dictionnaire de hash
        @return: la valeur correspondante au hash si nous la connaissant, 0 sinon
        """
        if str(self._board._currentHash) in self._hash_dict:
            return self._hash_dict[str(self._board._currentHash)]
        return 0

    def heuristic_on_lines(self, color):
        """
        Coeur de l'heuristique calculant la valeur selon trois critères :
        1. fin de partie (x10 000)
        2. contrôle du centre (x1)
        3. capture de pions adverses et conservation de nos pions (x100)
        @return: la valeur de l'heuristique calculée pour une partie donnée
        """
        # Vérification que l'on ne connait pas cette partie
        value = self.check_hash()
        if value != 0:
            return value

        # Détection d'une fin de partie
        if self._board.is_game_over() and color == self._board.BLACK:
            self.keep_hash_cost(10000)
            return 10000
        elif self._board.is_game_over() and color != self._board.WHITE:
            self.keep_hash_cost(10000)
            return -10000

        # Vérification du contrôle du centre
        for i in range(0, 8):
            # On pondère la première ligne pour la remplir en dernier
            if self._board[Goban.Board.flatten((i, 0))] == color:
                value += 1
            if self._board[Goban.Board.flatten((i, 8))] == color:
                value += 1
            if self._board[Goban.Board.flatten((0, i))] == color:
                value += 1
            if self._board[Goban.Board.flatten((8, i))] == color:
                value += 1

        for i in range(1, 7):
            # On pondère la deuxième ligne pour la remplir dans un second temps
            if self._board[Goban.Board.flatten((i, 7))] == color:
                value += 1
            if self._board[Goban.Board.flatten((i, 1))] == color:
                value += 1
            if self._board[Goban.Board.flatten((7, i))] == color:
                value += 1
            if self._board[Goban.Board.flatten((1, i))] == color:
                value += 1

        for i in range(3, 5):
            # On pondère la quatrième ligne pour la remplir en parallèle de la ligne deux
            if self._board[Goban.Board.flatten((i, 5))] == color:
                value += 2
            if self._board[Goban.Board.flatten((i, 3))] == color:
                value += 2
            if self._board[Goban.Board.flatten((5, i))] == color:
                value += 2
            if self._board[Goban.Board.flatten((3, i))] == color:
                value += 2

        for i in range(2, 6):
            # On pondère la troisième ligne pour la remplir en premier
            if self._board[Goban.Board.flatten((i, 6))] == color:
                value += 3
            if self._board[Goban.Board.flatten((i, 2))] == color:
                value += 3
            if self._board[Goban.Board.flatten((6, i))] == color:
                value += 3
            if self._board[Goban.Board.flatten((2, i))] == color:
                value += 3

        if self._board[Goban.Board.flatten((4, 4))] == color:
            value += 3

        # Capture des pions adverse et conservation de nos pions
        if color == self._board.BLACK:
            value -= self._board._nbWHITE*100
            value -= self._board._capturedBLACK*100
            value += self._board._capturedWHITE*100
        else:
            value += self._board._capturedBLACK*100
            value -= self._board._capturedWHITE*100
            value -= self._board._nbBLACK*100

        # Enregistrement du couple hash : valeur
        self.keep_hash_cost(value)
        return value
