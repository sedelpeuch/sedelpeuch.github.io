# Joueurs de GO

## Membres

+ Decou Nathan
+ Delpeuch Sébastien
+ Ferron Aymeric

## Résumé

Si dessous un résumé de notre heuristique et de ses joueurs. Toutes les fonctions que nous avons implémentées
possèdes des docstrings directement dans leur implémentation.

### Heuristique

Pour simplifier les modifications et éviter la duplication de code nous avons mis en place le fichier heuristic.py
permettant de définir les heuristiques que nous utilisons. Notre heuristique principale, que nous utilisons pour les
joueurs MiniMax et AlphaBeta, se décompose en 3 catégories. La catégorie principale valant le plus de points (10 000)
est la victoire de notre joueur. Vient ensuite le fait de capturer des pions adverses, de ne pas se faire capturer
nos pions (une centaine de points). Finalement nous nous sommes inspirés d'une vidéo (lien en fin de fichier) pour déterminer que le fait
de capturer le centre du plateau était intéressant pour notre joueur nous avons donc mis un gain faible à la capture
du centre (entre 1 et 3 points).

Finalement il existe une petite amélioration de l'heuristique se basant sur le hash
d'une partie. Comme le hash permet de définir une configuration de partie, à chaque fois que nous calculons
l'heuritisque d'une partie nous écrivons le hash et la valeur correspondante dans un dictionnaire. Ainsi avant de
calculer l'heuristique nous vérifions dans le dictionnaire si nous connaissons déjà ce hash ou non. Si oui cela
permet de calculer l'heuristique en temps presque constant et non en temps linéaire en fonction de la largeur d'un
plateau.

En somme notre heuristique fonctionne comme suit :

1. Par défaut nous cherchons à contrôler le centre du plateau (x1)
2. Dés que nous le pouvons nous capturons des pièces ennemies et évitons de perdre les notres (x100)
3. Si l'on détecte une victoire pour nous nous la réalisons (x10 000)

### MiniMax

Nous avons implémenté trois joueurs utilisant des stratégies différentes. Le premier se trouve dans miniMaxPlayer.py
et consiste principalement à une mise en jambe pour se familiariser avec l'interface de jeu en mettant en place un
algorithme miniMax (il l'utilise de manière naïve à une profondeur de 2). Ce joueur n'a pas vocation à faire des
résultats convainquant mais gagne contre le joueur aléatoire.

### AlphaBeta

Une fois que nous avions compris l'interface de jeu nous avons pu améliorer nos stratégies. Une grande amélioration
du joueur minimax se trouve dans l'algorithme Alpha - Beta. La coupure Alpha et la coupure Beta permettent de
réaliser des descentes plus profondes en un temps raisonnable et ainsi améliorer les résultats du joueur. Nous avons
donc mis en place cet algorithme dans le fichier alpha_beta.py. Compte tenu de ce que nous avons dit dans
l'heuristique et ce que permet les coupures alpha et les coupures beta nous pouvons réaliser une amélioration de
notre joueur par rapport à un simple alpha - beta.

En effet nous modifions la profondeur de parcours en fonction des situations. En début de partie nous cherchons à
contrôler le centre, nous avons donc une profondeur la plus faible possible (1) ce qui permet de consommer très peu
de temps CPU pour trouver les positions du centre à capturer (nous pourrions améliorer ça avec un dictionnaire
d'ouverture). Une fois que le centre est capturé notre heuristique tend à aller chercher les configurations de
parties maximisant la capture de pièces adverses et minimisant la perte de nos pièces nous augmentons alors la
profondeur de notre parcours (2) pour pouvoir voir plus de configuration de capture et ne pas jouer un coup par
défaut qui ne nous avancerait pas. Enfin si l'on voit qu'il reste moins de 20 coups possibles ou moins de 10 coups
possible nous augmentons la profondeur à 3 ou 4 pour pouvoir voir plus facilement si une fin de partie gagnante est
atteignable pour nous.

Cette amélioration permet à notre joueur d'être relativement robuste sans pour autant consommer un temps CPU
conséquent. In fine c'est le joueur le plus performant de nos 3 joueurs.

### MonteCarlo


### Ressources

https://www.youtube.com/watch?v=Xhg7oiyp4yI&list=PL3AkxoMrZclSMOHtiXV73IutGJvjJprOK&index=7&ab_channel=FulguroGo-TutorielduJeudeGoFulguroGo-TutorielduJeudeGo