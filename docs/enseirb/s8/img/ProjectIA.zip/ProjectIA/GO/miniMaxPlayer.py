# -*- coding: utf-8 -*-
"""
Ce fichier implémente le joueur se basant sur l'algorithme miniMax
"""

import time
import Goban
import random
from playerInterface import *
import heuristic


def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((te - ts) * 1000)
        else:
            print('%r  %2.2f ms' % \
                  (method.__name__, (te - ts) * 1000))
        return result

    return timed


class myPlayer(PlayerInterface):
    """
    Classe permettant de respecter l'interface du joueur tout en implémentant le joueur miniMax
    """

    def __init__(self):
        self._board = Goban.Board()
        self._mycolor = None
        # Mémorisation du dernier coup adverse que nous obtenons avec playOpponentMove
        self.last_opponent_move = None
        # Définition de l'heuristique en utilisant notre classe heuristic
        self._heuristic = heuristic.HeuristicBoard(self._board, self._mycolor).heuristic_on_lines
        self._nbturn = 0

    def getPlayerName(self):
        return "MiniMax Player"

    def getPlayerMove(self):
        """
        Cette fonction calcule le coup le plus profitable pour nous selon un algorithme miniMax avec une profondeur de
        parcours de 2
        @return: le coup calculé
        """
        self._nbturn += 1
        if self._board.is_game_over():
            print("Referee told me to play but the game is over!")
            return "PASS"
        moves = self._board.legal_moves()  # Dont use weak_legal_moves() here!
        move = self.best_move(moves, 2)
        self._board.push(move)
        return Goban.Board.flat_to_name(move)

    def playOpponentMove(self, move):
        self.last_opponent_move = move
        self._board.push(Goban.Board.name_to_flat(move))

    def newGame(self, color):
        self._mycolor = color
        self._opponent = Goban.Board.flip(color)

    def endGame(self, winner):
        if self._mycolor == winner:
            print("I won!!!")
        else:
            print("I lost :(!!")

    def best_move(self, moves, depth):
        """
        Cette fonction est la fonction principale de notre joueur. En fonction d'une liste de coups possibles et de la
        profondeur de recherche souhaitée elle va parcourir l'arbre des parties (avec l'algorithme miniMax) et trouver
        quelle partie à l'heuristique la plus avantageuse pour nous.
        @param moves: Les coups possibles (retour de la fonction legals_moves ou weak_legals_moves)
        @param depth: La profondeur de recherche souhaitée pour le miniMax
        @return: le coup associé à la branche de l'arbre des parties la plus avantageuse pour nous
        """
        best = -100000
        best_move = random.choice(moves)
        if self.last_opponent_move == -1:
            return "PASS"
        random.shuffle(moves)
        for move in moves:
            self._board.push(move)
            score = self.minimax(depth - 1, self._mycolor)
            self._board.pop()
            if score > best:
                best = score
                best_move = move
        return best_move

    def minimax(self, depth, maximizing):
        """
        Algorithme miniMax, la partie maximisante et minimisante sont rassemblées dans la fonction et discriminée grâce
        à un if sur un booléen passé en paramètre
        @param depth: la profondeur souhaitée
        @param maximizing: True si l'on est en phase maximisante, False sinon
        @return: la valeur maximale ou minimale de l'arbre des parties
        """
        if depth == 0 or self._board.is_game_over():
            if maximizing:
                return self._heuristic(self._board.BLACK)
            return self._heuristic(self._board.WHITE)
        if maximizing:
            value = -10000
            moves = self._board.legal_moves()
            for m in moves:
                self._board.push(m)
                value = max(value, self.minimax(depth - 1, False))
                self._board.pop()
            return value
        else:
            value = 10000
            moves = self._board.legal_moves()
            for m in moves:
                self._board.push(m)
                value = min(value, self.minimax(depth - 1, True))
                self._board.pop()
            return value
