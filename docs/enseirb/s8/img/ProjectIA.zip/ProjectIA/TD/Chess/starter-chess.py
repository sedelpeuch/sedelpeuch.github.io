from random import choice
import chess
import time

def randomMove(b):
    """Renvoie un mouvement au hasard sur la liste des mouvements possibles. Pour avoir un choix au hasard, il faut
    construire explicitement tous les mouvements. Or, generate_legal_moves() nous donne un itérateur."""
    return choice([m for m in b.generate_legal_moves()])


class PlayerRandom:
    def deroulementRandom(self, b):
        """Déroulement d'une partie d'échecs au hasard des coups possibles. Cela va donner presque exclusivement
        des parties très longues et sans gagnant. Cela illustre cependant comment on peut jouer avec la librairie
        très simplement."""
        print("----------")
        print(b)
        if b.is_game_over():
            print("Resultat : ", b.result())
            return
        b.push(randomMove(b))
        PlayerRandom.deroulementRandom(self, b)
        b.pop()

class PlayerMinMax:

    def best_move(self, b, maximum_depth):
        moves = b.legal_moves
        max_depth = 3
        self.mini_max(self, b, True, maximum_depth)


    def mini_max(self, b, player, maximum_depth):
        if maximum_depth == 0 :
            return heuristic(b, player)
        moves = b.legal_moves
        max = -10000
        for m in moves:
            b.push(m)
            temp = self.maxi_min(self, b, player, maximum_depth-1)
            b.pop()
            if temp > max:
                max = temp
        return max

    def maxi_min(self, b, player, maximum_depth):
        if maximum_depth == 0:
            return heuristic(b, player)
        moves = b.legal_moves
        min_value = 10000
        for m in moves:
            b.push(m)
            temp = self.mini_max(self, b, player, maximum_depth-1)
            b.pop()
            if min_value < temp:
                min_value = temp
        print(min_value)
        return min_value

    def best_move(self, board, player, depth):
        global n_explored_nodes
        n_explored_nodes = 0
        best = -10000
        best_move = None
        for move in board.generate_legal_moves():
            board.push(move)
            score = self.mini_max(self, board, player, depth - 1)
            board.pop()
            if score > best:
                best = score
                best_move = move
        return best_move


class PlayerAlphaBeta:

    def alpha_beta(self, b, depth, alpha, beta, maximizing_player):
        global n_explored_nodes
        n_explored_nodes += 1
        if depth == 0 or b.is_game_over():
            return heuristic(b, maximizing_player)
        m = b.legal_moves
        value = -10000
        for i in m:
            value = max(value, self.beta_alpha(self, b, depth - 1, alpha, beta, maximizing_player))
            alpha = max(alpha, value)
            if alpha > beta:
                break
        return value

    def beta_alpha(self, b, depth, alpha, beta, minimizing_player):
        if depth == 0 or b.is_game_over():
            return heuristic(b, minimizing_player)
        value = +10000
        m = b.legal_moves
        for i in m:
            value = min(value, self.alpha_beta(self, b, depth - 1, alpha, beta, minimizing_player))
            beta = min(beta, value)
            if beta <= alpha:
                break
        return value


def heuristic(b, maximizing_player):
    value = 0
    map = b.piece_map()
    for p in map:
        if map[p].color == maximizing_player:
            value += piece_weight(map[p].piece_type)
        if map[p].color != maximizing_player:
            value -= piece_weight(map[p].piece_type)
    return value


def piece_weight(chessPieceType):
    if chessPieceType == 1:
        return 1
    if chessPieceType == 2 or chessPieceType == 3:
        return 3
    if chessPieceType == 4:
        return 5
    if chessPieceType == 5:
        return 9
    if chessPieceType == 6:
        return 200
    else:
        return 0


board = chess.Board()
while not board.is_game_over():
    print(board)
    start = time.time()
    white_move = PlayerMinMax.best_move(PlayerMinMax, board, True, depth=3)
    end = time.time()
    print("Move :", white_move, "Time :", end-start)
    board.push(white_move)
    if board.is_game_over():
        print("White win")
        break
    start = time.time()
    black_move = PlayerMinMax.best_move(PlayerMinMax, board, False, depth=3)
    end = time.time()
    board.push(black_move)
    if board.is_game_over():
        print("Black win")
        break

