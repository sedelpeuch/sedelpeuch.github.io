# -*- coding: utf-8 -*-

import time
import Tictactoe 
from random import randint,choice

NOEUD = 1
FEUILLES_G = 1
FEUILLES_P = 1
FEUILLES_N = 1

def RandomMove(b):
    '''Renvoie un mouvement au hasard sur la liste des mouvements possibles'''
    return choice(b.legal_moves())

def deroulementRandom(b):
    '''Effectue un déroulement aléatoire du jeu de morpion.'''
    print("----------")
    print(b)
    if b.is_game_over():
        res = getResult(b)
        if res == 1:
            print("Victoire de X")
        elif res == -1:
            print("Victoire de O")
        else:
            print("Egalité")
        return
    b.push(RandomMove(b))
    deroulementRandom(b)
    b.pop()

def deroulementTotal(b):
    global NOEUD,FEUILLES_G,FEUILLES_N,FEUILLES_P
    # print("----------")
    # print(b)
    if b.is_game_over():
        res = getResult(b)
        if res == 1:
            # print("Victoire de X")
            FEUILLES_G +=1
        elif res == -1:
            # print("Victoire de O")
            FEUILLES_P += 1
        else:
            # print("Egalité")
            FEUILLES_N += 1
        return
    moves = b.legal_moves()
    for m in range(len(moves)):
        b.push(moves[m])
        NOEUD += 1
        deroulementTotal(b)
        b.pop()

def miniMax(b):
    # minimax(p) = f(p) si p est une feuille de l'arbre
    # minimax(p) = max(minimax(O_n)) si p est un noeud joueur avec n fils
    # minimax(p) = min(minimax(O_n)) si p est un noeud opposant avec n fils
    if b.is_game_over:
        return getResult(b)
    elif b._nextPlayer==b._Y:
        moves = b.legals_moves()
        temp=[]
        for m in range(len(moves)):
            b.push(m)
            temp[m] = miniMax(b)
            b.pop()
            return max(temp)
    elif b._nextPlayer==b._X:
        moves = b.legals_moves()
        temp=[]
        for m in range(len(moves)):
            b.push(m)
            temp[m] = miniMax(b)
            b.pop()
            return min(temp)




board = Tictactoe.Board()
print(board)

def getResult(b):
    if b.result() == b._X :
        return 1
    if b.result() == b._O :
        return -1
    else :
        return 0


### Deroulement d'une partie aléatoire
# deroulementTotal(board)
print(miniMax(board))

# print("Apres le match, chaque coup est défait (grâce aux pop()): on retrouve le plateau de départ :")
# print(board)
# print("Nombre de noeuds : ", NOEUD)
# print("Nombres de feuilles :", FEUILLES_N + FEUILLES_P + FEUILLES_G)
# print("Nombres de feuilles gagnantes : ", FEUILLES_G)
# print("Nombres de feuilles perdantes : ", FEUILLES_P)
# print("Nombre de feuilles nulles : ", FEUILLES_N)
