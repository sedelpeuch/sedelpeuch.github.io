# First we need to print clauses
def printClause(clause):
    print(" ".join([str(v) for v in clause]) + " 0")


def value(x, y, z):
    return 100 * x + 10 * y + z


def equals1a(arrayOfVars):
    printClause(arrayOfVars)
    for i, x in enumerate(arrayOfVars):
        for y in arrayOfVars[i + 1:]:
            printClause([-x, -y])


# 1 nombre par case
for x in range(1, 10):
    for y in range(1, 10):
        equals1a([value(x, y, z) for z in range(1, 10)])

# 1 exemplaire de chaque chiffre par colonne
for x in range(1, 10):
    for z in range(1, 10):
        equals1a([value(x, y, z) for y in range(1, 10)])

# 1 exemplaire de chaque chiffre par ligne
for y in range(1, 10):
    for z in range(1, 10):
        equals1a([value(x, y, z) for x in range(1, 10)])

# 1 exemplaire de chaque chiffre par carré
for sx in range(3):
    for sy in range(3):
        for z in range(1, 10):
            equals1a([value(x + 3 * sx, y + 3 * sy, z) for x in range(1, 4) for y in range(1, 4)])
