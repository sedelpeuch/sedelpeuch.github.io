# Prédiction des parties de GO

Ce fichier est un résumé des différents commentaires trouvables dans le fichier source du tp

## Membres

+ Decou Nathan
+ Delpeuch Sébastien
+ Ferron Aymeric

## Résumé

Le projet se décompose en 3 parties : le traitement des données brutes, la définition du modèle et sa vérification.

### Traitement des données brutes

Prérequis : la première cellule du notebook a été exécutée.

Cette étape permet de transformer les données brutes en données exploitables par notre réseau.
Elle repose sur la mise en place d'une stratégie d'élargissement des données en utilisant les symétries et rotations

Après cette étape nous avons environ 500 000 tableaux de taille (2, 9, 9) (un channel pour les pions blancs, un pour les pions noirs)

### Définition du modèle

La construction de ce modèle est grandement inspiré des TD précédent il comporte :
- 3 convolutions 2D séparés par des BatchNormalization
- un aplatissement suivi d'un dropout (10%)
- 3 couches denses avec une activation sur 'relu'
- 1 couche dense avec une activation sigmoid

Le modèle est compilé avec l'optimiseur adam et la fonction de loss utilisée est la mae.

Nous partitionnons aussi les données en deux ensemble (67% de train et 33% de test)

Le modèle a été entraîné sur 20 époques avec un batch size de 128

### Vérification des données

Une fois le modèle entraîné nous traçons l'évolution de la mae et de la fonction de loss pour pouvoir l'analyser.

Le graphique correspondant est disponible dans le fichier graph.png

Nous pouvons voir sur ce graphe que les courbes train et test se suivent globalement et ne s'écartent pas brutalement
(sauf sur le dernier point) cela nous indique que nous ne sommes pas en surentrainement. De plus sur l'échantillon de test
nous avons une MAE entre 0.10 et 0.11 ce qui est satisfaisant.