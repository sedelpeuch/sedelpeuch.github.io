# Aquarium

A client-server aquarium software using TCP.
The server is written in C, the server in Java.

This project was developed in the "Network Project" course at ENSEIRB-MATMECA (2020-2021).
The full wording is available at <https://docs.google.com/document/d/1MzZG0qDfVr8U50v8X79yvaPfToj8Yz4DwiGg3swl1kk/edit>.

These instructions will get you a copy of the project up and running on your local machine.


## Server

The server is located under `server`.

### Prerequisites

In order to compile the server, you need to have CMake 3.12 (or later)
and `libpcre2` installed on your machine.

On Debian-based distros, PCRE2 can be installed through APT:

```sh
apt-get install libpcre2-dev
```

### Compiling & Installing

1. Move to `server/build`
2. Run `cmake -H..` to initialize the CMake cache
3. You can now compile the server and copy its configuration files to `server/install` by using
   `cmake --build . --target install`.
4. Move to `server/install`, and run `./server` to start the server.

### Usage

Once the server has started, the default aquarium has not any view for clients to take.
You need to add views manually by using the `add view` command.
You can also type `load a.aqua` to load a topology from a file.

## Client

The client is located under `client`.

To compile the client, we rely on the Gradle build automation.

To compile and execute on Linux you only need to execute the command `./gradlew run --console=plain` from the `client` directory.

To compile and execute on Windows you only need to execute the command `gradlew.bat command` from the `client` directory.

All dependencies and modules will be downloaded by gradle if necessary.

## Authors

- Rémi Dehenne
- Sébastien Delpeuch
- Aymeric Ferron
- Tom Moënne-Loccoz
- Aurélien Moinel
