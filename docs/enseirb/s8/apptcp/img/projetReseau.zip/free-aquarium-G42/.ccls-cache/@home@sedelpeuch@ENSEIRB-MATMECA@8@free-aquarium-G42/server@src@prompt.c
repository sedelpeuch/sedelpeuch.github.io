#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/** 
 * @brief Erase the "\n" a the end of the string
 */
char* clean_input(char* input) {
  int len_result = strlen(input);
  input[(len_result - 1)] = '\0';
  return input;
}

/**
 * @brief Parse correctly the topology vue_x x vue_y + vue_width + vue_height.
 */ 
int* parse_topology(char* char_topology) {
  // Malloc to store and return int topology
  int* topology = malloc(4*sizeof(int));
  const char* separators = "x+"; 
  char* strToken = strtok(char_topology,separators);
  topology[0] = atoi(strToken);
  for(int i = 1; i < 4; i++) {
    strToken = strtok(NULL, separators);
    topology[i] = atoi(strToken);
  }
  return topology;
}

int homemade_shell(char* input) {
  // Defines separator on "space"
  const char * separators = " ";
  // Detects tokens
  char * strToken = strtok ( input, separators);
  if( strcmp(strToken, "quit") == 0) {
    return 1;
  }
  if( strcmp(strToken, "load") == 0)
  {
    printf("load");
    return 0;
  }
  if( strcmp(strToken, "show") == 0) {
    strToken = strtok(NULL, separators);
    return 0;
  }
  if( strcmp(strToken, "add") == 0) {
    // Ignore the second argument which is "view"
    strToken = strtok(NULL, separators);
    char* view_name = strtok(NULL, separators);
    char* char_topology = strtok(NULL, separators);
    int* topology = parse_topology(char_topology);
    for(int i = 0; i < 4; i++) {
      printf("%d\n", topology[i]);
    }
    free(topology);
    return 0;
  }
  if( strcmp(strToken, "del") == 0) {
    printf("del");
    return 0;
  }
  if( strcmp(strToken, "save") == 0) {
    printf("save");
    return 0;
  }
   return -1; 
}


int main(int argc, char** argv) {
  char* input = malloc(2048*sizeof(char));
  while (1) {
    fputs("> ", stdout);
    fgets(input, 2048, stdin); /*Store prompt input in input var*/
    input = clean_input(input);
    int quit = homemade_shell(input);
    if(quit) {
      break;
    }
  }
  free(input);
  return 0;
}