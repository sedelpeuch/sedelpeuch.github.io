package client.modeles;

import client.controller.ControllerAquarium;
import client.utilities.AquariumLogger;
import client.utilities.Configuration;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;


/**
 *
 */
public class Fish {

    /**
     * The name of the fish.
     */
    private final String name;

    /**
     * The image view associated to the fish.
     */
    private ImageView imageView;

    private boolean firstAnimation = true;

    /**
     * The direction where the fish is looking (1 right / -1 left)
     */
    private int imageDirection;

    /**
     * A blocking queue of fish properties (to create new transitions).
     */
    private BlockingQueue<FishProperties> transitionsQueue;

    public static Map<String, Integer> allNumberFishesTransitions = new HashMap<>();

    /**
     * A lock to execute transitions sequentially.
     */
    private final Object lock = new Object();

    /**
     * The current properties of the fish.
     */
    private FishProperties properties;

    /**
     * The image associated to the fish.
     */
    private final Image image;

    /**
     * The default image used in case of none/bad specification.
     */
    private static final String DEFAULT_URL =
            "../" + Configuration.getInstance().getFishesResources() + "/PoissonCombattant.png";

    /**
     * The transition state, need to not be load in the cache, the value needs to remain up to date.
     */
    private volatile StatusTranslation statusTranslation = StatusTranslation.RUNNING;


    public Fish(String name, FishProperties properties) {
        this.name = name;
        this.properties = properties;
        transitionsQueue = new LinkedBlockingQueue<>();
        image = getImage(getImagePath());
        imageDirection = 1;
    }


    /**
     * Create an image with a given path.
     *
     * @param path The path to the file to load
     * @return An image laoded with the right fish
     */
    private Image getImage(String path) {
        URL result = getClass().getResource(path);
        if(result == null) {
            AquariumLogger.logging(Level.WARNING, "Bad fish name : default image instead");
            result = getClass().getResource(Fish.DEFAULT_URL);
        }
        return new Image(String.valueOf(result));
    }


    /**
     *  Determine a path according to the fish name.
     *
     * @return The path of the file
     */
    private String getImagePath() {
        return "../" + Configuration.getInstance().getFishesResources()
                + "/" + this.name.split("_")[0].concat(".png");
    }


    /**
     *  Create an image view according to the properties
     *  of the fish.
     *
     * @return The created image view
     */
    private ImageView associateImageView() {
        ImageView imageView = new ImageView();
        imageView.setImage(image);
        imageView.setPreserveRatio(false);
        imageView.setFitWidth(properties.getXSize());
        imageView.setFitHeight(properties.getYSize());
        imageView.setX(properties.getXPos());
        imageView.setY(properties.getYPos());
        imageView.setId(name);
        return imageView;
    }


    /**
     * Launch the next translation in the queue if the current status of the
     * translation is STOPPED and if the queue is not empty.
     */
    public void moveConsumer() {
        new Thread(() -> {
            while (true) {
                try {
                    FishProperties properties = transitionsQueue.take();
                    synchronized (lock) {
                        while (currentTranslationStatus() == Fish.StatusTranslation.RUNNING) {
                            try {
                                lock.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                                break;
                            }
                        }
                    }
                    if (firstAnimation) {
                        firstAnimation = false;
                        ScaleTransition transition = new ScaleTransition(Duration.seconds(properties.getDuration()), imageView);
                        transition.setFromX(0.01);
                        transition.setToX(1.0);
                        transition.setFromY(0.01);
                        transition.setToY(1.0);
                        transition.setOnFinished(e -> setOnTranslationFinished(properties));
                        synchronized (lock) {
                            statusTranslation = Fish.StatusTranslation.RUNNING;
                            lock.notifyAll();
                        }
                        Platform.runLater(transition::play);
                    } else {
                        createTranslation(properties);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }


    /**
     * Change the X fish orientation according to is movement.
     *
     * @param properties The properties of the fish
     */
    private void imageViewOrientation(FishProperties properties) {
        if(imageDirection == 1 && (properties.getXPos() - this.properties.getXPos()) < 0 ||
                imageDirection == -1 && (properties.getXPos() - this.properties.getXPos()) > 0) {
            imageDirection *= -1;
            imageView.setScaleX(imageDirection);
        }
    }


    /**
     * Create the translation t
     * @param properties The properties of the fish
     */
    private void createTranslation(FishProperties properties) {
        TranslateTransition transition = new TranslateTransition(Duration.seconds(properties.getDuration()), imageView);
        imageViewOrientation(properties);
        transition.setByY(properties.getYPos() - this.properties.getYPos());
        transition.setByX(properties.getXPos() - this.properties.getXPos());
        transition.setOnFinished(e -> setOnTranslationFinished(properties));
        synchronized (lock) {
            statusTranslation = Fish.StatusTranslation.RUNNING;
            lock.notifyAll();
        }
        Platform.runLater(transition::play);
    }


    /**
     * Create the initial display of the fish by adding him in the main Pane
     * and by placing is Translation status to STOPPED.
     */
    public void initialDisplay() {
        this.imageView = associateImageView();
        ControllerAquarium.getMainPane().getChildren().add(this.imageView);
        synchronized (lock) {
            statusTranslation = Fish.StatusTranslation.STOPPED;
            lock.notifyAll();
        }
        /*try {
            this.getTransitions().put(properties);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        moveConsumer();
    }


    public BlockingQueue<FishProperties> getTransitions() {
        return this.transitionsQueue;
    }


    public String getName() {
        return this.name;
    }


    public StatusTranslation currentTranslationStatus() {
        return this.statusTranslation;
    }


    /**
     * Updates the size of the fish with the given values, and
     * allow the next transition to execute.
     *
     * @param properties The properties of the fish
     */
    public void setOnTranslationFinished(FishProperties properties) {
        imageView.setFitWidth(properties.getXSize());
        imageView.setFitHeight(properties.getYSize());
        this.properties = properties;
        Fish.setTransitionsRemainder(this.name, getTransitionsRemainder(this.name)-1);
        synchronized (lock) {
            lock.notifyAll();
            this.statusTranslation = StatusTranslation.STOPPED;
        }
    }

    public static Integer getTransitionsRemainder(String fishName) {
        return Fish.allNumberFishesTransitions.get(fishName);
    }

    public static void setTransitionsRemainder(String fishName, Integer value) {
        Fish.allNumberFishesTransitions.put(fishName, value);
    }


    /**
     * An enumeration to determine the Status of the translation.
     */
    public enum StatusTranslation {
        RUNNING, STOPPED
    }

}
