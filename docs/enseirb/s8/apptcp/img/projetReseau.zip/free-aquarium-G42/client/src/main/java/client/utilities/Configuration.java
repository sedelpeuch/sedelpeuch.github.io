package client.utilities;

import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;


public class Configuration {

    private static Configuration instance = null;

    private final static String path = "affichage.cfg";

    final static Properties file = new Properties();

    private static final Map<String, Level> configLevel = Map.ofEntries(
            Map.entry("ALL", Level.ALL),
            Map.entry("FINEST", Level.FINEST),
            Map.entry("FINER", Level.FINER),
            Map.entry("FINE", Level.FINE),
            Map.entry("INFO", Level.INFO),
            Map.entry("WARNING", Level.WARNING),
            Map.entry("SEVERE", Level.SEVERE),
            Map.entry("OFF", Level.OFF)
    );


    private Configuration() {
        try {
            file.load(getClass().getResourceAsStream(path));
            AquariumLogger.logging(Level.INFO, "Success to get configuration file");
        } catch (Exception e) {
            AquariumLogger.logging(Level.SEVERE, "Cannot load configuration file", e);
        }
    }

    public static Configuration getInstance() {
        if (instance == null) {
            instance = new Configuration();
            return instance;
        }
        return instance;
    }

    long getDisplayTimeout() {
        AquariumLogger.logReceiveConfiguration("Display Timeout");
        return Long.parseLong(file.getProperty(ConfigurationField.DISPLAY_TIMEOUT.getValue()))*1000;
    }

    String getControllerAddress() {
        AquariumLogger.logReceiveConfiguration("Controller Address");
        return file.getProperty(ConfigurationField.CONTROLLER_ADDRESS.getValue());
    }

    String getId() {
        AquariumLogger.logReceiveConfiguration("Id");
        return file.getProperty(ConfigurationField.ID.getValue());
    }

    Integer getControllerPort() {
        AquariumLogger.logReceiveConfiguration("Controller Port");
       return Integer.parseInt(file.getProperty(ConfigurationField.CONTROLLER_PORT.getValue()));
    }

    public String getFishesResources() {
        AquariumLogger.logReceiveConfiguration("Fishes Resources");
        return file.getProperty(ConfigurationField.FISHES_RESOURCES.getValue());
    }

    public Level getLogVerbosity() {
        if (file.getProperty(ConfigurationField.LOG_VERBOSITY.getValue()).isEmpty()) {
            AquariumLogger.logReceiveConfiguration("Default Verbosity");
            return Level.ALL;
        }
        return configLevel.get(file.getProperty(ConfigurationField.LOG_VERBOSITY.getValue()));
    }

    /**
     * Enum of all config values.
     */
    @SuppressWarnings("unused")
     private enum ConfigurationField {
        CONTROLLER_ADDRESS("controller-address"),
        ID("id"),
        CONTROLLER_PORT("controller-port"),
        DISPLAY_TIMEOUT("display-timeout-value"),
        LOG_VERBOSITY("log-verbosity"),
        FISHES_RESOURCES("resources");

        private final String value;

        ConfigurationField(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

    }

}

