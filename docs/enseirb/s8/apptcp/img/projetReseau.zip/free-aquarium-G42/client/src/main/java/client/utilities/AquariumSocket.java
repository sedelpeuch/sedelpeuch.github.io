package client.utilities;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;

public class AquariumSocket {

    /**
     * The configurations uses to settle socket properties
     */
    private final Configuration configuration = Configuration.getInstance();

    /**
     * The used socket
     */
    private static Socket SOCKET;

    /**
     * The used buffer to read messages from server
     */
    private static BufferedReader IN;

    /**
     * The used buffer to send messages to server
     */
    private static PrintWriter OUT;

    /**
     * Handle the user inputs
     */
    private final Scanner userInput = new Scanner(System.in);

    /**
     * Determine if the client is connected to the server
     */
    static boolean connected = false;

    private static AquariumSocket instance = null;

    private AquariumSocket() {
        try {
            SOCKET = new Socket(configuration.getControllerAddress(), configuration.getControllerPort());
            IN = new BufferedReader(new InputStreamReader(SOCKET.getInputStream()));
            OUT = new PrintWriter(
                    new BufferedWriter(
                            new OutputStreamWriter(SOCKET.getOutputStream())), true);
            AquariumLogger.logging(Level.INFO, String.format("Client up and running (port %d)", configuration.getControllerPort()));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static AquariumSocket getInstance() {
        if (instance == null) {
            instance = new AquariumSocket();
            return instance;
        }
        return instance;
    }

    /**
     * Execute the first connection to the server, and init
     * threads to communicate with it.
     */
    public void start() {
        startConnection();
        receive();
        maintainConnection();
        send();
        sendLSCommand();
    }

    /**
     * Give to the PrinterWriter object the command to send.
     * @param command The desired command to send
     */
    private void sendCommand(String command) {
        OUT.print(command+"\n");
        OUT.flush();
    }

    /**
     * Send a ping every period of times get from the configuration file.
     */
    private void maintainConnection() {
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                sendCommand(String.format("ping %s", configuration.getControllerPort()));
                AquariumLogger.logSendCommand("ping");
            }
        }, 0, configuration.getDisplayTimeout());
    }

    /**
     * Started a connection with the server.
     */
    private void startConnection() {
        if (configuration.getId().isEmpty()) {
            sendCommand("hello");
            AquariumLogger.logSendCommand("hello");
            return;
        }
        sendCommand(String.format("hello in as %s", configuration.getId()));
        AquariumLogger.logSendCommand(String.format("hello in as %s", configuration.getId()));
    }

    /**
     * Process the receive messages from the server.
     */
    private void receive() {
        new Thread(() -> {
            try {
                String value;
                while ((value = IN.readLine()) != null) {
                    if (!value.contains("pong") &&
                        !value.contains("list")) {
                        System.out.println(value);
                    }
                    AquariumLogger.logReceiveCommand(value);
                    ServerProcessResponse.process(value);
                }
            } catch (IOException ignored) {}
        }).start();
    }

    /**
     * Process the send messages to the server.
     */
    private void send() {
        new Thread(() -> {
            String command;
            while (true) {
                if (userInput.hasNextLine()) {
                    command = userInput.nextLine();
                    OUT.print(command+"\n");
                    OUT.flush();
                    AquariumLogger.logSendCommand(command);
                }
            }
        }).start();
    }

    /**
     *  Send an ls every 35 seconds.
     */
    private void sendLSCommand() {
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                sendCommand("ls");
                AquariumLogger.logSendCommand("ls");
            }
        }, 0, 35000);
    }

    /**
     * Disconnect the client to the server by closing the socket.
     */
    static void closeSocket() {
        try {
            IN.close();
            OUT.close();
            SOCKET.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Disconnected");
            AquariumLogger.logging(Level.INFO, "Client is disconnected");
            System.exit(0);
        }
    }
}
