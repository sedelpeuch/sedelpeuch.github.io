package client.utilities;

import client.controller.ControllerAquarium;
import client.modeles.Fish;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class ServerFishResponse {

    private static Map<String, Integer> fishesTranslation = new HashMap<>();

    private static final String regexPattern = "\\[(.*?)](\\n)*";

    private static final String regexMatcher = "[ ,]";

    private static Matcher matcher;

    private ServerFishResponse(){}

    /**
     * Match the given command with the regex relative to the list of fishes.
     *
     * @param command The receive command from the server.
     */
    static void matchServerResponse(String command) {
        Pattern pattern = Pattern.compile(ServerFishResponse.regexPattern);
        matcher = pattern.matcher(command);
        splitCommands();
    }


    /**
     * Get each fish and properties.
     */
    private static void splitCommands() {
        while(matcher.find()) {
            executeFishAction(matcher.group(1));
        }
        fishesTranslation.clear();
    }

    /**
     * Create or update a given fish properties in the aquarium.
     *
     * @param list The list of properties relatives to the fish.
     */
    private static void executeFishAction(String list) {
        String[] fishProperties = list.split(ServerFishResponse.regexMatcher);
        String nameFish = fishProperties[0];
        if (!fishesTranslation.containsKey(nameFish)) {
            if (ControllerAquarium.fishes.containsKey(nameFish)) {
                fishesTranslation.put(nameFish, Fish.getTransitionsRemainder(nameFish));
            } else {
                fishesTranslation.put(nameFish, 0);
            }
        } else if (fishesTranslation.containsKey(nameFish) && fishesTranslation.get(nameFish) > 0) {
            fishesTranslation.put(nameFish, fishesTranslation.get(nameFish) - 1);
        }

        if (ControllerAquarium.fishes.containsKey(nameFish)) {
            if(fishesTranslation.get(nameFish) == 0) {
                ControllerAquarium.addTransition(fishProperties);
            }
        } else {
            ControllerAquarium.createFish(fishProperties);
            ControllerAquarium.addTransition(fishProperties);
        }
    }
}