package client.modeles;

import client.controller.ControllerAquarium;
import javafx.geometry.Point2D;


public class FishProperties {

    /**
     * The duration of the Transition of the fish
     */
    final int duration;

    /**
     * Position of the fish related to the screen (in %)
     */
    private final Point2D percentScreenPosition;

    /**
     * Size of the fish related to the screen (in %)
     */
    private final Point2D percentScreenSize;

    /**
     * Position of the fish related to the screen (in px)
     */
    private Point2D pixelScreenPosition;

    /**
     * Size of the fish related to the screen (in px)
     */
    private Point2D pixelScreenSize;

    public FishProperties(String[] literalProperties) {
        this.duration = Integer.parseInt(literalProperties[4]);
        this.percentScreenPosition = parseCoordinates(literalProperties[2]);
        this.percentScreenSize = parseCoordinates(literalProperties[3]);
        this.resizeAll();
    }

    /**
     * @param coordinates The coordinates of the size/position of the fish exprimed as "NxM".
     * @return A new point based on the transformed string
     */
    private Point2D parseCoordinates(String coordinates) {
        String[] splitCoordinates = coordinates.split("[x]");
        return new Point2D(Integer.parseInt(splitCoordinates[0]), Integer.parseInt(splitCoordinates[1]));
    }

    /**
     * Transform all the properties of the fish (in percentage)
     * into a equivalent size in pixels.
     *
     */
    private void resizeAll() {
        this.pixelScreenPosition = this.resize(this.percentScreenPosition);
        this.pixelScreenSize = this.resize(this.percentScreenSize);
    }

    /**
     * Transform a percentage (width/height of the user's screen)
     * into a equivalent size in pixels.
     *
     * @param percentScreen The given points in percentage
     * @return The result of the transformation.
     */
    private Point2D resize(Point2D percentScreen) {
        int pixelX = (int)(ControllerAquarium.ScreenProperties.WIDTH.getValue() * percentScreen.getX()) / 100;
        int pixelY = (int) (ControllerAquarium.ScreenProperties.HEIGHT.getValue() * percentScreen.getY()) / 100;
        return new Point2D(pixelX, pixelY);
    }

    public int getXPos() {
        return (int) pixelScreenPosition.getX();
    }

    public int getYPos() {
        return (int) pixelScreenPosition.getY();
    }

    public int getXSize() {
        return (int) pixelScreenSize.getX();
    }

    public int getYSize() {
        return (int) pixelScreenSize.getY();
    }

    public int getDuration() {
        return duration;
    }

    @Override
    public String toString() {
        return "FishProperties{" +
                "duration=" + duration +
                ", percentScreenPosition=" + percentScreenPosition +
                ", percentScreenSize=" + percentScreenSize +
                ", pixelScreenPosition=" + pixelScreenPosition +
                ", pixelScreenSize=" + pixelScreenSize +
                '}';
    }
}
