package client.utilities;

import java.util.Map;
import java.util.function.Consumer;
import java.util.regex.Pattern;

class ServerProcessResponse {

    private ServerProcessResponse(){}

    /**
     * A map of callbacks, for each regex that match a server response, a
     * reference to a "void method(String)" is associated.
     */
    private static final Map<String, Consumer<String>> callbacks = Map.ofEntries(
            Map.entry("(list.*(\\n)*.*)*", ServerFishResponse::matchServerResponse),
            Map.entry("^greeting.*", ServerResponse::matchGreetedResponse),
            Map.entry("^no greeting.*", ServerResponse::matchNoGreetedResponse),
            Map.entry("^bye", ServerResponse::matchByeResponse)
    );

    /**
     * Process the given command if match with one of the authorized callbacks.
     *
     * @param command The command receive from the server
     */
    static void process(String command) {
        for (Map.Entry<String,Consumer<String>> entry : callbacks.entrySet()) {
            if (Pattern.matches(entry.getKey(), command)) {
                entry.getValue().accept(command);
                return;
            }
        }
    }
}