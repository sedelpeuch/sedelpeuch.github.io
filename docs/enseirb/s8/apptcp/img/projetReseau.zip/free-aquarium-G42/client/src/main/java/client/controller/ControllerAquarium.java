package client.controller;

import client.utilities.AquariumLogger;
import client.utilities.AquariumSocket;
import javafx.application.Platform;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import client.modeles.Fish;
import client.modeles.FishProperties;
import java.util.*;
import java.util.logging.Level;


public class ControllerAquarium {

    /**
     * A map to link the name of a fish with the fish
     * itself.
     */
    public static Map<String, Fish> fishes = new HashMap<>();

    private static AnchorPane anchorPane;

    private static Stage primaryStage;


    public ControllerAquarium(Stage primaryStage) {
        ControllerAquarium.primaryStage = primaryStage;
        ControllerAquarium.anchorPane = (AnchorPane) primaryStage.getScene().lookup("#AnchorPane");
    }

    public static AnchorPane getMainPane() {
        return anchorPane;
    }


    /**
     * Initialize a connection with a server.
     */
    public void initSocketConnection() {
        AquariumSocket aquariumSocket = AquariumSocket.getInstance();
        aquariumSocket.start();
    }

    /**
     * Create a fish according to is given name, size and position
     *
     * @param literalProperties All properties of the fish parsed.
     */

    public static void createFish(String[] literalProperties) {
        FishProperties properties = new FishProperties(literalProperties);
        Fish fish = new Fish(literalProperties[0], properties);
        fishes.put(fish.getName(), fish);
        Fish.setTransitionsRemainder(literalProperties[0], 0);
        AquariumLogger.logging(Level.FINE, String.format("Fish %s created", fish.getName()));
        Platform.runLater(fish::initialDisplay);
    }

    /**
     * Add a transition into the list of transitions of the considered fish,
     * in order to be able to execute sequentially a list of transitions.
     *
     * @param literalProperties All properties of the fish parsed.
     */

    public static void addTransition(String[] literalProperties) {
        Fish fish = fishes.get(literalProperties[0]);
        AquariumLogger.logging(Level.FINE, String.format("Transition created for %s fish", fish.getName()));
        FishProperties properties = new FishProperties(literalProperties);
        try {
            fish.getTransitions().put(properties);
            Fish.setTransitionsRemainder(literalProperties[0], Fish.getTransitionsRemainder(literalProperties[0]) + 1);
        } catch (InterruptedException e) {
            AquariumLogger.logging(Level.SEVERE, String.format("Unable to add transition for %s fish", fish.getName()), e);
        }
    }

    /**
     *  The size of the user's screen.
     *  {@link #WIDTH}
     *  {@link #HEIGHT}
     */
    public enum ScreenProperties {
        WIDTH(Screen.getPrimary().getBounds().getWidth()), HEIGHT(Screen.getPrimary().getBounds().getHeight());
        private final double value;

        ScreenProperties(double value) {
            this.value = value;
        }
        public double getValue() {
            return this.value;
        }
    }

    public static void setTitleStage(String title) {
        ControllerAquarium.primaryStage.setTitle(title);
    }
}

