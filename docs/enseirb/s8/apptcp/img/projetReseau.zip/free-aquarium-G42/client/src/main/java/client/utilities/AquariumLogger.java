package client.utilities;

import java.util.logging.*;

public class AquariumLogger {

   private static final Logger LOGGER = Logger.getGlobal();
   static {
       try {
           FileHandler fileHandler = new FileHandler("log");
           fileHandler.setFormatter(new SimpleFormatter());
           LOGGER.setUseParentHandlers(false);
           LOGGER.addHandler(fileHandler);
           LOGGER.setLevel(Configuration.getInstance().getLogVerbosity());
       } catch (Exception exception) {
           LOGGER.log(Level.SEVERE, "Cannot create log file", exception);
       }
   }

    private AquariumLogger() {}

    /**
     *  Create a log of with a given level.
     * @param level The level of the log
     * @param message The message to log
     */
    public static void logging(Level level, String message) {
        LOGGER.log(level, message);
    }

    /**
     *  Create a log of with a given level.
     * @param level The level of the log
     * @param message The message to log
     * @param exception The catched exception
     */
    public static void logging(Level level, String message, Exception exception) {
        LOGGER.log(level, message, exception);
    }

    /**
     * Create a log with INFO level.
     * @param command The send command
     */
    public static void logSendCommand(String command) {
       LOGGER.log(Level.INFO, String.format("Client sent %s", command));
    }

    /**
     * Create a log with INFO level.
     * @param command The receive command
     */
    public static void logReceiveCommand(String command) {
        LOGGER.log(Level.INFO, String.format("Client receive %s", command));
    }

    /**
     * Create a log with FINEST level.
     * @param configParam The configuration parameter
     */
    public static void logReceiveConfiguration(String configParam) {
        LOGGER.log(Level.FINEST, String.format("Get %s in configuration file", configParam));
    }
}
