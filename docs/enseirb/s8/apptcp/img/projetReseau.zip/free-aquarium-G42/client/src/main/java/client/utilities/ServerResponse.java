package client.utilities;

import client.controller.ControllerAquarium;

import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class ServerResponse {

    private ServerResponse(){}

    static void matchGreetedResponse(String command) {
        AquariumLogger.logging(Level.INFO, "Server is greeting");
        System.out.println("Server is greeting");
        Pattern pattern = Pattern.compile("^greeting .*");
        Matcher matcher = pattern.matcher(command);
        String nameView = Configuration.getInstance().getId();
    }

    static void matchNoGreetedResponse(String command) {
        AquariumLogger.logging(Level.INFO, "Server is not greeting");
        System.out.println("Server is not greeting");
        AquariumSocket.closeSocket();
    }

    static void matchByeResponse(String command) {
        AquariumLogger.logging(Level.INFO, "Log out");
        System.out.println("Log out");
        AquariumSocket.connected = false;
        AquariumSocket.closeSocket();
    }
}
