plugins {
    id("application")
    id("org.openjfx.javafxplugin") version "0.0.9"
}

repositories {
    mavenCentral()
}

dependencies {
}

javafx {
    version = "16"
    modules = listOf( "javafx.controls", "javafx.fxml" )
}

application {
    mainClass.set("client.Main")
}

tasks.getByName<JavaExec>("run") {
    standardInput = System.`in`
}