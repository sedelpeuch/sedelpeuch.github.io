package client;

import client.controller.ControllerAquarium;
import javafx.application.Application;
import client.controller.ControllerAquarium.ScreenProperties;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        //AnchorPane root = new AnchorPane();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("aquarium.fxml")));
        Scene scene = new Scene(root, ScreenProperties.WIDTH.getValue(), ScreenProperties.HEIGHT.getValue());

        primaryStage.setScene(scene);
        ControllerAquarium controllerAquarium = new ControllerAquarium(primaryStage);

        controllerAquarium.initSocketConnection();


        primaryStage.setTitle("Aquarium");

        //Get primary screen bounds
        Rectangle2D screenBounds = Screen.getPrimary().getBounds();
        scene.getStylesheets().add(String.valueOf(getClass().getResource("aquarium.css")));
        primaryStage.show();


        //set Stage boundaries to visible bounds of the main screen
        primaryStage.setX(screenBounds.getMinX());
        primaryStage.setY(screenBounds.getMinY());
        primaryStage.setWidth(ScreenProperties.WIDTH.getValue());
        primaryStage.setHeight(ScreenProperties.HEIGHT.getValue());

    }


    public static void main(String[] args) {
        launch(args);
    }
}
