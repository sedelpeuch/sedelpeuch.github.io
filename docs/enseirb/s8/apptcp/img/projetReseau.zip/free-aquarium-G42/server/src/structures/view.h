#ifndef __VIEW_H
#define __VIEW_H
#include "position.h"
#include "area.h"
#include "ret_stat.h"

enum availability {
    FREE,
    TAKEN,
    ERROR
};

/**
 * @brief view_t represents a view with an area and a position representative of a room inside a future aquarium
 */
typedef struct view view_t;

/**
 * @brief Only initialize a view this way.
 *
 * Please don't malloc you own view, initialize it through this function and terminate
 * its lifecycle with the view__end or any function promising to end the view.
 * @param name The name of the view
 * @param area The size of the view, respective to a future aquarium
 * @param position The position of the view, respective to a future aquarium
 * @return view_t* The initialized pointer to the demanded view.
 */
view_t* view__init(char const* name, area_t area, position_t position);

/**
 * @brief Ends the lifecycle of the view.
 * 
 * @param view The view to end
 * @return OK if successful, ERR_NULL_GIVEN if view is NULL
 */
enum ret_stat view__end(view_t* view);

/**
 * @brief Get a copy of the area of the view.
 * 
 * @param view The view inspected
 * @return area_t The area of the view or { .height = -1, .width = -1} if the view is NULL. 
 */
area_t view__get_area(const view_t* view);

/**
 * @brief Get a copy of the position of the view.
 * 
 * @param view The view inspected
 * @return area_t The position of the view or { .x = -1, .y = -1} if the view is NULL.
 */
position_t view__get_position(const view_t* view);

/**
 * @brief Get the pointer to the name of the view. Be careful not to modify the name afterwards.
 * 
 * @param view The view inspected
 * @return char* A pointer to the name of the view or NULL if the view is NULL.
 */
const char* view__get_name(const view_t* view);

/**
 * @brief Gets the value of availibility of the view
 * 
 * @param view The view inspected
 * @return FREE if the view is available, TAKEN if the view is not available or ERROR if the view is NULL.
 */
enum availability view__get_availability(const view_t* view);

/**
 * @brief Sets the value of availibility of the view
 * 
 * @param view The view to modify
 * @param availability The value of availibility to give to the view
 * @return enum ret_stat OK if everything went fine or ERR_NULL_GIVEN if view is NULL.
 */
enum ret_stat view__set_availability(view_t* view, enum availability availability);

#endif // __VIEW_H