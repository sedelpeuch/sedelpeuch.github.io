#ifndef __POSITION_H
#define __POSITION_H

/**
 * @brief position_t represents the coordinates of an object
 * 
 */
typedef struct position {
    int x; ///< The horizontal coordinate of the object
    int y; ///< The vertical coordiante of the object
} position_t;

#endif // __POSITION_H