#ifndef __HASH_TYPE_H
#define __HASH_TYPE_H

#ifndef PATH
#define PATH 
#endif

#include PATH
#include "../ret_stat.h"


#define CONCAT_HELPER(x, y) x##y
#define CONCAT(x, y) CONCAT_HELPER(x, y)

#define HASH CONCAT(hash_, TYPE)
#define MAP CONCAT(map_, TYPE)
#define TYPE_T CONCAT(TYPE, _t)
#define HASH_T CONCAT(hash_, TYPE_T)




typedef struct HASH HASH_T;

/**
 * @brief Only initialize a MAP (HASH_T**) this way.
 * 
 * Please don't malloc you own MAP, initialize it through this function and terminate
 * its lifecycle with the MAP__end or MAP__end_end.
 * @return HASH_T** The initialized pointer to a MAP
 */
HASH_T** CONCAT(MAP, __init)();

/**
 * @brief Ends the lifecycle of a MAP without ending the TYPEs in it.
 * 
 * Releases properly the structures allocated for the fonctionning of the MAP and the MAP itself.
 * @param MAP The MAP to end.
 * @return enum ret_stat Returns OK if everything went fine and ERR_NULL_GIVEN if MAP is NULL
 */
enum ret_stat CONCAT(MAP,__end)(HASH_T** MAP);

/**
 * @brief Ends the lifecycle of a MAP and ends the TYPEs in it.
 * 
 * Releases properly the structures allocated for the fonctionning of the MAP and the MAP itself.
 * Also ends the TYPE added in the lifetime of the MAP.
 * @param MAP The MAP to end.
 * @return enum ret_stat Returns OK if everything went fine and ERR_NULL_GIVEN if MAP is NULL
 */
enum ret_stat CONCAT(MAP,__end_end)(HASH_T** MAP);

/**
 * @brief Adds a given TYPE to the MAP.
 * 
 * @param MAP The MAP to add to
 * @param TYPE The TYPE to add
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if MAP or TYPE is NULL,
 * ERR_ALREADY_INSIDE if the map contains a TYPE with the same name already.
 */
enum ret_stat CONCAT(MAP,__add)(HASH_T** MAP, TYPE_T* TYPE);

/**
 * @brief Deletes a TYPE from the MAP. The name of the TYPE to delete must be given.
 * 
 * Deletes the HASH from the map but does not end the TYPE in question.
 * @param MAP The MAP to delete from
 * @param name The name of the TYPE to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if MAP or name is NULL,
 * ERR_NOT_INSIDE if MAP does not contain a TYPE whose name is name. 
 */
enum ret_stat CONCAT(MAP,__del)(HASH_T** MAP, char const* name);

/**
 * @brief Deletes a TYPE from the MAP. The name of the TYPE to delete and end must be given.
 * 
 * Deletes the HASH from the map and ends the TYPE in question.
 * @param MAP The MAP to delete from
 * @param name The name of the TYPE to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if MAP or name is NULL,
 * ERR_NOT_INSIDE if MAP does not contain a TYPE whose name is name. 
 */
enum ret_stat CONCAT(MAP,__del_end)(HASH_T** MAP, char const* name);

/**
 * @brief Finds a TYPE, previously added to the MAP, by its name.
 * 
 * @param MAP The MAP to search into
 * @param name The name of the TYPE to find
 * @return TYPE_T* The found TYPE or NULL is the TYPE is not inside, or MAP or name are NULL.
 */
TYPE_T* CONCAT(MAP,__find)(HASH_T** MAP, char const* name);

/**
 * @brief Deletes all the TYPE from the MAP. Does not end them. Does not end the MAP.
 * 
 * @param MAP The MAP from which to delete all the TYPEs added 
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if MAP is NULL
 */
enum ret_stat CONCAT(MAP,__delete_all)(HASH_T** MAP);

/**
 * @brief Deletes and ends all the TYPE from the MAP. Does not end the MAP.
 * 
 * @param MAP The MAP from which to delete and end all the TYPEs added 
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if MAP is NULL
 */
enum ret_stat CONCAT(MAP,__delete_all_end)(HASH_T** MAP);

/**
 * @brief Gets the number of TYPEs currently added to the MAP.
 * 
 * @param MAP The MAP inspected.
 * @return int The number of TYPEs added in the MAP or -1 if MAP is NULL
 */
int CONCAT(MAP,__get_number)(HASH_T** MAP);

/**
 * @brief Gets all the TYPEs added in the MAP in a malloc'd table. Do not forget to free the table.
 * 
 * @param MAP The MAP inspected.
 * @return TYPE_T** A table of pointers to TYPEs. It contains all the TYPEs added to the MAP.
 * The pointer is NULL if MAP is NULL.
 */
TYPE_T** CONCAT(MAP,__get_all)(HASH_T** MAP);


#undef HASH_T
#undef TYPE_T
#undef MAP
#undef HASH
#undef CONCAT
#undef CONCAT_HELPER

#endif // __HASH_TYPE_H