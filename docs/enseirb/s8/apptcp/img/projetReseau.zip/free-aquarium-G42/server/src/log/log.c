#include <stdio.h>

FILE* log_output = NULL;
int log_mode = 2;