#ifndef AQUARIUM_SERVER_SERVER_CALLBACKS_H
#define AQUARIUM_SERVER_SERVER_CALLBACKS_H

#include <stdlib.h>
#include <stdio.h>
#include "../../structures/public_structures.h"
#include "../command.h"

enum command_err_code shutdown_server(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

#endif //AQUARIUM_SERVER_SERVER_CALLBACKS_H
