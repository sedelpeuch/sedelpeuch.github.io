#include "command.h"
#include "callbacks/fish-callbacks.h"
#include "callbacks/authentication-callbacks.h"

/**
 * The set of commands that can be called by a client through the communication interface.
 */
command_set_t client_command_set = {.nb_commands = 0};


void client_command_set__fill() {
    command__initialize(&client_command_set,
                        "^hello(?: in as (\\S+))?$",
                        hello);
    command__initialize(&client_command_set,
                        "^status$",
                        status);
    command__initialize(&client_command_set,
                        "^addFish (\\S+) at (\\d+)x(\\d+), (\\d+)x(\\d+), (\\S+)$",
                        add_fish);
    command__initialize(&client_command_set,
                        "^delFish (\\S+)$",
                        del_fish);
    command__initialize(&client_command_set,
                        "^startFish (\\S+)$",
                        start_fish);
    command__initialize(&client_command_set,
                        "^getFishes$",
                        get_fishes);
    command__initialize(&client_command_set,
                        "^ls$",
                        ls);
    command__initialize(&client_command_set,
                        "^ping (\\d{1,5})$",
                        ping);
    command__initialize(&client_command_set,
                        "^log out$",
                        log_out);
}

enum command_err_code client_command__exec(char const* input, FILE* out, FILE* err, view_t** client_view) {
    return command__exec(&client_command_set, input, out, err, client_view);
}

void client_command_set__destroy() {
    command_set__destroy(&client_command_set);
}