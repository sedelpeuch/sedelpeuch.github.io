#include <stdio.h>

#include "command.h"
#include "server-commands.h"
#include "../globals/globals.h"
#include "../log/log.h"
#include "callbacks/server-callbacks.h"

/**
 * The maximum number of bytes read from the command line.
 */
#define MAX_CMD_SIZE 200


void run_server_cli() {
    char input[MAX_CMD_SIZE + 1];
    input[MAX_CMD_SIZE] = '\0'; // Add trailing '\0'

    INFO("Starting prompt");

    server_command_set__fill();

    while (!exiting) {
        fputs("> ", stdout);
        if (fgets(input, MAX_CMD_SIZE, stdin) != NULL) { /*Store prompt input in input var*/
            enum command_err_code err_code = server_command__exec(input, stdout, stderr);

            if (err_code == CMD_OK) {
                printf("OK\n");
            } else {
                fprintf(stderr,
                        "%s (code %d)\n",
                        command_error_code_to_text(err_code),
                        err_code);
            }
        } else {
            shutdown_server(0, NULL, NULL, NULL, NULL);
        }
    }

    INFO("Exiting prompt");
}
