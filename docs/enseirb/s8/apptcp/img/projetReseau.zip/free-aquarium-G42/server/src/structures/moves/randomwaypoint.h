#ifndef __RANDOMWAYPOINT_H
#define __RANDOMWAYPOINT_H
#include <stdlib.h>
#include "../ret_stat.h"
#include "../transition_private.h"

/**
 * @brief The standard mobility function
 * 
 * @param mobility The structure representing the coordinates of a fish.
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if mobility is NULL.
 */
enum ret_stat randomwaypoint(transition_t* transition);

#endif //__RANDOMWAYPOINT_H