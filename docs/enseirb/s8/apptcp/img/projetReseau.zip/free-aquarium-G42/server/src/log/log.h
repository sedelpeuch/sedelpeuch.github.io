#ifndef AQUARIUM_SERVER_LOG_H
#define AQUARIUM_SERVER_LOG_H

#define BUF_SIZE 1024

#include <stdio.h>

extern FILE* log_output;

extern int log_mode;

/**
 * @file Provide log macros.
 * Different levels of verbosity are available
 */


#define LOGGER(level, type, format, ...) \
    ({                                   \
    if(level <= log_mode){ \
        char buf[BUF_SIZE];              \
        sprintf(buf, format, ##__VA_ARGS__);               \
        fprintf(log_output, "%5s | %25s | l.%3d | %s  \n", type , __func__, __LINE__, buf); \
        fflush(log_output);                                 \
        }})

#define ERR(msg, ...) (LOGGER(1, "ERR", msg, ##__VA_ARGS__))

#define WARN(msg, ...) (LOGGER(2, "WARN", msg, ##__VA_ARGS__))

#define INFO(msg, ...) (LOGGER(3, "INFO", msg, ##__VA_ARGS__))

#define TRACE(msg, ...) (LOGGER(4, "TRACE", msg, ##__VA_ARGS__))


#endif //AQUARIUM_SERVER_LOG_H
