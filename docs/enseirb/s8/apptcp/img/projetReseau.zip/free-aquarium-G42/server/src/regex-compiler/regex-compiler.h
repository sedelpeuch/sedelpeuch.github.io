#ifndef AQUARIUM_SERVER_REGEX_COMPILER_H
#define AQUARIUM_SERVER_REGEX_COMPILER_H

#include <stdio.h>
#include <pcre2.h>

/**
 * Compile string `input_string_regex` to PCRE2 `regex`
 * @param input_string_regex[in] The string which describes the regex
 * @param regex[out] The address where the compiled PCRE2 regex is stored
 */
void compile_regex(char const* input_string_regex, pcre2_code** regex);

#endif //AQUARIUM_SERVER_REGEX_COMPILER_H
