#define TYPE fish
#define PATH "../fish.h"
#include "hash_type.c"
#undef PATH
#undef TYPE