#ifndef AQUARIUM_SERVER_CLIENT_COMMANDS_H
#define AQUARIUM_SERVER_CLIENT_COMMANDS_H

#include "server-commands.h"
#include "callbacks/default.h"

/**
 * Create every command that can be called by the client
 */
void client_command_set__fill();

/**
 * Parse & execute command `input` if `input` corresponds to a valid client command.
 * @param input The command the user wants to execute.
 * @param out A stream in which the parser and the callback can write output data into
 * @param out A stream in which the parser and the callback can write error data into
 * @return CMD_OK, or an error code
 */
enum command_err_code client_command__exec(char const* input, FILE* out, FILE* err, view_t** client_view);

/**
 * Free the commands of a command set
 */
void client_command_set__destroy();

#endif //AQUARIUM_SERVER_CLIENT_COMMANDS_H
