#ifndef TYPE
#define TYPE type
#endif

#include <string.h>
#include "uthash.h"
#include "hash_type.h"

#define CONCAT_HELPER(x, y) x##y
#define CONCAT(x, y) CONCAT_HELPER(x, y)

#define HASH CONCAT(hash_, TYPE)
#define MAP CONCAT(map_, TYPE)
#define TYPE_T CONCAT(TYPE, _t)
#define HASH_T CONCAT(hash_, TYPE_T)


typedef struct HASH {                 
    char* id;                  /* key */
    TYPE_T* TYPE; 
    UT_hash_handle hh;         /* makes this structure hashable */
} HASH_T;

HASH_T** CONCAT(MAP, __init)() {
    HASH_T** MAP = malloc(sizeof(HASH_T*));
    *MAP = NULL;
    return MAP;
}


enum ret_stat CONCAT(MAP, __end)(HASH_T** MAP) {
    if (MAP) {
        CONCAT(MAP, __delete_all(MAP));
        free(MAP);
        return OK;
    }
    return ERR_NULL_GIVEN;
}

enum ret_stat CONCAT(MAP, __end_end)(HASH_T** MAP) {
    if (MAP) {
        CONCAT(MAP, __delete_all_end)(MAP);
        free(MAP);
        return OK;
    }
    return ERR_NULL_GIVEN;
}


HASH_T* CONCAT(HASH, __init(TYPE_T* TYPE)) {
    HASH_T* res = malloc(sizeof(HASH_T));
    const char* name = CONCAT(TYPE,__get_name)(TYPE);
    res->id = malloc(sizeof(char) * (strlen(name)+1));
    strcpy(res->id, name);
    res->TYPE = TYPE;
    return res;
}

enum ret_stat CONCAT(HASH, __end(HASH_T* HASH)) {
    if (HASH) {
        if (HASH->id) {
            free(HASH->id);
            free(HASH);
            return OK;
        }
        free(HASH);
        return ERR_NO_ID;
    }
    return ERR_NULL_GIVEN;
}

enum ret_stat CONCAT(MAP, __add)(HASH_T** MAP, TYPE_T* TYPE) {
    if (!TYPE || !MAP) {
        return ERR_NULL_GIVEN;
    }
    HASH_T* HASH_Tmp = NULL;
    HASH_FIND_STR(*MAP, CONCAT(TYPE,__get_name)(TYPE), HASH_Tmp); //Check that the TYPE (more precisely his name) is not part of the map
    if (HASH_Tmp) {
        return ERR_ALREADY_INSIDE;
    }
    HASH_T* HASH = CONCAT(HASH, __init(TYPE));
    HASH_ADD_KEYPTR(hh, *MAP, HASH->id, strlen(HASH->id), HASH);
    return OK;
}

enum ret_stat CONCAT(MAP, __del_private)(HASH_T** MAP, char const* name, int end) {
    if (!name || !MAP) {
        return ERR_NULL_GIVEN;
    }
    HASH_T* HASH;
    HASH_FIND_STR(*MAP, name, HASH);
    if (HASH) {
        HASH_DEL(*MAP, HASH);
        if (end) {
            CONCAT(TYPE,__end)(HASH->TYPE);
        }
        return CONCAT(HASH, __end(HASH));
    }
    return ERR_NOT_INSIDE;
}

enum ret_stat CONCAT(MAP, __del)(HASH_T** MAP, char const* name) {
    return CONCAT(MAP, __del_private)(MAP, name, 0);
}

enum ret_stat CONCAT(MAP, __del_end)(HASH_T** MAP, char const* name) {
    return CONCAT(MAP, __del_private)(MAP, name, 1);
}

TYPE_T* CONCAT(MAP, __find)(HASH_T** MAP, char const* name) {
    if (name && MAP) {
        HASH_T* HASH;
        HASH_FIND_STR(*MAP, name, HASH);
        return HASH ? HASH->TYPE : NULL;
    }
    return NULL;
}

enum ret_stat CONCAT(MAP, __del_all_private)(HASH_T** MAP, int end) {
    if (!MAP) {
        return ERR_NULL_GIVEN;
    }
    HASH_T* HASH;
    HASH_T* tmp;
    HASH_ITER(hh, *MAP, HASH, tmp) {
        HASH_DEL(*MAP, HASH);
        if (end) {
            CONCAT(TYPE,__end)(HASH->TYPE);
        }
        CONCAT(HASH, __end)(HASH);
    }
    return OK;
}


enum ret_stat CONCAT(MAP, __delete_all)(HASH_T** MAP) {
    return CONCAT(MAP, __del_all_private)(MAP, 0);
}

enum ret_stat CONCAT(MAP, __delete_all_end)(HASH_T** MAP) {
    return CONCAT(MAP, __del_all_private)(MAP, 1);
}

int CONCAT(MAP, __get_number)(HASH_T** MAP) {
    if (!MAP) {
        return -1;
    }
    return HASH_COUNT(*MAP);
}

TYPE_T** CONCAT(MAP, __get_all)(HASH_T** MAP) {
    if (!MAP)
        return NULL;  
    int nb_TYPEs = CONCAT(MAP, __get_number(MAP));
    TYPE_T** res = malloc(nb_TYPEs * sizeof(TYPE_T*));
    int i = 0;
    HASH_T* HASH;
    HASH_T* tmp;
    HASH_ITER(hh, *MAP, HASH, tmp) {
        res[i] = HASH->TYPE;
        i++;
    }
    return res; //à free
}

#undef HASH_T
#undef TYPE_T
#undef MAP
#undef HASH
#undef CONCAT
#undef CONCAT_HELPER

