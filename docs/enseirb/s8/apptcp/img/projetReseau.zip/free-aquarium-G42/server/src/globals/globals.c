#include "globals.h"

int exiting = 0;
int accept_socket_fd = -1;
unsigned int port = 9009;
unsigned int timeout = 45;