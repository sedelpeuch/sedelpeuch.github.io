#ifndef AQUARIUM_SERVER_COMMAND_H
#define AQUARIUM_SERVER_COMMAND_H

#include <stdlib.h>
#include <stdio.h>
#include "../structures/view.h"

/* COMMAND ERROR CODES */

/**
 * The type of functions that are called when a command is executed.
 * @param argc The number of arguments provided by the parser.
 * @param argv The arguments provided by the parser. Each index of the `argv` array points to a string that represents
 * an argument. If an argument is defined as optional in the regular expression, the argv entry may be NULL.
 * @return CMD_OK, or an error code defined in enum `command_err_code`.
 * @note Alongside the error code, a callback can write additional error information into `additional_error_info`.
 * @see command_err_code
 */
typedef enum command_err_code (* command_callback_t)(size_t argc, char const* const* args, FILE* out, FILE* err,
                                                     view_t** client_view);

/**
 * Error codes that can be returned by the command parser or the command callbacks.
 * @see command_err_msg
 */
enum command_err_code {
    CMD_OK = 0,             ///< Success
    CMD_ERR_UNKNOWN_CMD,    ///< [Reserved] Returned by the parser when the user input does not match any command name.
    CMD_ERR_SYNTAX,         ///< [Reserved] Returned by the parser when the user input does match a command name,
    ///<            but does not respect its syntax.
    CMD_ERR_INVALID_ARGUMENTS,  ///< Returned by a callback when at least one of its arguments is invalid.
    CMD_ERR_FILE_ERROR,         ///< Returned by a callback when a file could not be found or open.
    CMD_ERR_FILE_CONTENT_ERROR, ///< Returned by a callback when the file is not formatted properly.
    CMD_ERR_INVALID_STATE,      ///< Returned by a callback when a command is called at an inappropriate time.
    CMD_OK_DISCONNECT,          ///< Returned by a callback when a command should close the connection normally
    // If necessary, you can add other error codes *here* for your callbacks (don't forget to add an error message
    // in command.c)
    NB_ERROR_CODES,
    FIRST_CODE = CMD_OK
};

/**
 * The error message of each error code (in order).
 * @see command_err_code
 * @see command_error_code_to_text
 */
extern char const* command_err_msg[NB_ERROR_CODES];

/**
 * Return the error message associated with `err_code`, or "Unknown error" if `err_code` is not valid.
 */
char const* command_error_code_to_text(enum command_err_code err_code);



/* CALLBACK & COMMAND DATA STRUCTURES */

/**
 * The maximum number of commands in a command set.
 * This number must be greater than the number of commands in a single command set.
 * (e.g. client_command_set, server_command_set)
 */
#define MAX_CMD_NB 30

/**
 * A command that executes the code of `callback` when the user input matches `regex`.
 */
typedef struct command command_t;

/**
 * A set of commands that may contain up to MAX_CMD_NB commands.
 */
typedef struct command_set {
    command_t* commands[MAX_CMD_NB]; ///< An array of commands
    size_t nb_commands; ///< The number of commands that were added to the command set
} command_set_t;


/**
 * Add a new command to a set of commands.
 * @param command_set The set of commands which will contain the new command.
 * @param regex The syntax of the new command.
 * @param callback The function to be called when the user input matches regular expression `regex`.
 */
void command__initialize(command_set_t* command_set,
                         char const* regex, command_callback_t callback);

/**
 * Parse & execute command `input` if `input` corresponds to a valid command of `command_set`.
 * @param command_set The array of commands that may be used.
 * @param input The command the user wants to execute.
 * @return CMD_OK, or an error code
 */
enum command_err_code
command__exec(command_set_t const* command_set, char const* input, FILE* out, FILE* err, view_t** client_view);

/**
 * Free the commands of a command_set
 */
void command_set__destroy(command_set_t* command_set);

#endif //AQUARIUM_SERVER_COMMAND_H
