#include "dic_mob_model.h"
#include "hash/hash_mob_model.h"
#include "moves/public_moves.h"
#include <stdlib.h>

hash_mob_model_t* hash_mob_model = NULL;
hash_mob_model_t** map_mob_model = &hash_mob_model;

/**
 * @brief Adds a given mob_model to the hidden dictionary of mob_models.
 *
 * @param mob_model The mob_model to add
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the dictionnary or mob_model is NULL,
 * ERR_ALREADY_INSIDE if the dictionnary contains a mob_model with the same name already.
 */
enum ret_stat dic_mob_model__add(mob_model_t* mob_model) {
    return map_mob_model__add(map_mob_model, mob_model);
}

/**
 * @brief Deletes a mob_model from the hidden dictionary of mob_models. The name of the mob_model to delete must be given.
 *
 * Deletes the mob_model from the dictionary but does not end the mob_model in question.
 * @param name The name of the mob_model to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the dictionary or name is NULL,
 * ERR_NOT_INSIDE if the dictionary does not contain a mob_model whose name is name.
 */
enum ret_stat dic_mob_model__del(char const* name) {
    return map_mob_model__del(map_mob_model, name);
}

/**
 * @brief Deletes and ends a mob_model from the hidden dictionary of mob_models. The name of the mob_model to delete and end must be given.
 *
 * Deletes the mob_model from the dictionary and ends the mob_model in question.
 * @param name The name of the mob_model to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the dictionary or name is NULL,
 * ERR_NOT_INSIDE if the dictionary does not contain a mob_model whose name is name.
 */
enum ret_stat dic_mob_model__del_end(char const* name) {
    return map_mob_model__del_end(map_mob_model, name);
}

void dic_mob_model__init() {
    mob_model_t* random_mob = mob_model__init("RandomWayPoint", randomwaypoint);
    mob_model_t* horizontal_mob = mob_model__init("HorizontalWayPoint", horizontalwaypoint);
    mob_model_t* vertical_mob = mob_model__init("VerticalWayPoint", verticalwaypoint);
    dic_mob_model__add(random_mob);
    dic_mob_model__add(horizontal_mob);
    dic_mob_model__add(vertical_mob);

}

mob_model_t* dic_mob_model__find(char const* name) {
    return map_mob_model__find(map_mob_model, name);
}

enum ret_stat dic_mob_model__delete_all() {
    return map_mob_model__delete_all(map_mob_model);
}

enum ret_stat dic_mob_model__delete_all_end() {
    return map_mob_model__delete_all_end(map_mob_model);
}

int dic_mob_model__get_number() {
    return map_mob_model__get_number(map_mob_model);
}

mob_model_t** dic_mob_model__get_all() {
    return map_mob_model__get_all(map_mob_model);
}