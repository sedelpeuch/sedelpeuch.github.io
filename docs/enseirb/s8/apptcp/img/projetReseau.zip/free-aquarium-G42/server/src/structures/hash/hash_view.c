#define TYPE view
#define PATH "../view.h"
#include "hash_type.c"
#undef PATH
#undef TYPE


view_t* map_view__get_available_view(hash_view_t** map_view) {
    if (!map_view) {
        return NULL;
    }
    hash_view_t* hash_view;
    for (hash_view = *map_view; hash_view; hash_view = hash_view->hh.next) {
        if (view__get_availability(hash_view->view) == FREE) return hash_view->view;
    }
    return NULL;
}
