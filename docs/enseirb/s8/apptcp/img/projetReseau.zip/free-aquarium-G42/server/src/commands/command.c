#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h> // Requires package libpcre2-dev on Debian-based distros
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "command.h"
#include "../log/log.h"

/**
 * The maximum number of bytes used by error buffers, in order to print error messages.
 */
#define MAX_ERROR_SIZE 1024


/* COMMAND ERROR CODES */

char const* command_err_msg[NB_ERROR_CODES] = {
        "Success",
        "Syntax error: the command does not exist",
        "Syntax error: the command does exist, but your syntax was incorrect",
        "Command error: the command was called with invalid arguments",
        "File error: the file does not exist or cannot be open",
        "File error: the file is not formatted properly",
        "Command error: the command was called at an inappropriate time",
        "Success: Disconnecting client"
};

/**
 * Return the error message associated with `err_code`, or "Unknown error" if `err_code` is not valid.
 */
char const* command_error_code_to_text(enum command_err_code err_code) {
    if (err_code >= FIRST_CODE && err_code < NB_ERROR_CODES) {
        ERR("%s", command_err_msg[err_code]);
        return command_err_msg[err_code];
    }
    ERR("Unknown error");
    return "Unknown error";
}


/* CALLBACK & COMMAND DATA STRUCTURES */

/**
 * A command that executes the code of `callback` when the user input matches `regex`.
 */
struct command {
    pcre2_code* regex; ///< A regular expression that describes the full syntax of a command, and its arguments.
    command_callback_t callback; ///< The function to be called when the syntax is correct.
};

void command__initialize(command_set_t* command_set,
                         char const* regex, command_callback_t callback) {
    assert(command_set);
    assert(regex);
    assert(callback);
    assert(command_set->nb_commands < MAX_CMD_NB);

    // Allocate a new command_t and store its address into the first free command_t* element of command_set->commands
    command_t* new_command = malloc(sizeof(command_t));
    command_set->commands[command_set->nb_commands] = new_command;

    int error_number;
    PCRE2_SIZE error_offset;

    new_command->regex = pcre2_compile((PCRE2_SPTR) regex,
                                       PCRE2_ZERO_TERMINATED,
                                       PCRE2_UTF | PCRE2_UCP, // Use UTF-8 in classes (\d, \w, [[:alpha:]]...)
                                       &error_number,
                                       &error_offset,
                                       NULL); // Use default compile context

    // Handle regex errors
    if (new_command->regex == 0) {
        PCRE2_UCHAR error_buffer[MAX_ERROR_SIZE];
        pcre2_get_error_message(error_number, error_buffer, sizeof(error_buffer));
        ERR("PCRE2 compilation failed at offset %d: %s", (int) error_offset,
                error_buffer);
        fprintf(stderr, "PCRE2 compilation failed at offset %d: %s\n", (int) error_offset,
                error_buffer);
        exit(1);
    }

    new_command->callback = callback;

    command_set->nb_commands++;
}


/**
 * Auxiliary function.
 * Convert regex matches into an array of strings, one string for each argument (argv).
 * @param input_string The command received from user input, which matched a regex.
 * @param reg_matches The PCRE2 structure which contains every match data.
 * @param nb_matches The number of actual capturing parentheses in the regex.
 * @param dest_arg_array The argument array, whose elements will point to arguments (as strings).
 * @see command__exec
 */
void command__matches_to_string_args(char const* input_string, PCRE2_SIZE const* reg_matches,
                                     int nb_matches, char** dest_arg_array) {
    assert(input_string);
    assert(reg_matches);
    assert(dest_arg_array);

    PCRE2_SPTR input_sptr = (PCRE2_SPTR) input_string;

    for (size_t match_id = 1; match_id <= nb_matches; match_id++) // Begin at 1 to ignore match 0 (the whole user input)
    {
        size_t destination_id = match_id - 1; // Match n is stored into the (n-1)-th element of the destination array,
        // since we ignore match_id = 0

        PCRE2_SPTR match_start = input_sptr + reg_matches[2 * match_id];
        PCRE2_SIZE match_length = reg_matches[2 * match_id + 1] - reg_matches[2 * match_id];

        if (match_length <= 0) { // The sub-pattern is empty: it is an option, which is not specified
            dest_arg_array[destination_id] = NULL;
        } else { // Sub-pattern does have content
            dest_arg_array[destination_id] = malloc(sizeof(char) * (match_length + 1));
            dest_arg_array[destination_id][match_length] = '\0'; // Add trailing '\0'

            // Copy the match_id-th match of the original string into the (match_id - 1)-th argument of the arg array
            strncpy(// Match #0 in the arg array corresponds to match #1 in the regex implementation
                    dest_arg_array[destination_id],
                    // Address of the first matching char
                    (char*) match_start,
                    match_length);
        }

    }
}

enum command_err_code
command__exec(command_set_t const* command_set, char const* input, FILE* out, FILE* err, view_t** client_view) {
    assert(command_set);
    assert(input);

    for (int i = 0; i < command_set->nb_commands; i++) {
        assert(&command_set->commands[i] != NULL);

        int match_ret_val;
        pcre2_match_data* reg_matches = pcre2_match_data_create_from_pattern(command_set->commands[i]->regex, NULL);

        // Check if `input` matches `command_set->commands[i]`
        match_ret_val = pcre2_match(command_set->commands[i]->regex,
                                    (PCRE2_SPTR) input,
                                    strlen(input),
                                    0, // Start at offset 0
                                    0, // Default options
                                    reg_matches, // Result
                                    NULL); // Use default context

        if (match_ret_val > 0) { // The regex matches `input`
            assert(match_ret_val != 0);
            int nb_matches = match_ret_val - 1;

            // Create a new array of pointers
            char** string_command_args = malloc(nb_matches * sizeof(char*));

            // Each pointer of the array will point to a newly allocated string,
            // one for each argument
            command__matches_to_string_args(input,
                                            pcre2_get_ovector_pointer(reg_matches),
                                            nb_matches,
                                            string_command_args);

            // Execute the command
            int callback_err_code =
                    command_set->commands[i]->callback(nb_matches,
                                                       (char const* const*) string_command_args,
                                                       out,
                                                       err,
                                                       client_view);

            // Free the arguments, stored as strings, and the array of pointers
            for (size_t j = 0; j < nb_matches; j++) {
                free(string_command_args[j]); // string_command_args[j] may be NULL, but free() does not mind
            }

            free(string_command_args);
            pcre2_match_data_free(reg_matches);

            return callback_err_code;
        }

        pcre2_match_data_free(reg_matches);
    }

    return CMD_ERR_UNKNOWN_CMD; // No command matched
}

void command_set__destroy(command_set_t* command_set) {
    for (int i = 0; i < command_set->nb_commands; i++) {
        free(command_set->commands[i]->regex);
        free(command_set->commands[i]);
    }

    command_set->nb_commands = 0;
}
