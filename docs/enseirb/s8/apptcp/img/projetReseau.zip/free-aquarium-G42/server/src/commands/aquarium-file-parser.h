#ifndef AQUARIUM_SERVER_AQUARIUM_FILE_PARSER_H
#define AQUARIUM_SERVER_AQUARIUM_FILE_PARSER_H

#include <stdio.h>
#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>

#include "../regex-compiler/regex-compiler.h"

#define MAX_MULTIMATCH_NB 30

typedef struct multimatch {
    char** all_matches[MAX_MULTIMATCH_NB];
    size_t all_matches_nb;
} multimatch_t;

/**
 * Compile regular expressions used to parse aquarium files
 */
void file_parser__initialize();

/**
 * Parse an aquarium file
 * @param file The file to be parsed
 * @param aquarium_config_all_matches[out] A pointer that will point to the parsed aquarium declarations
 * @param views_config_all_matches[out] A pointer that will point to the parsed view declarations
 * @return CMD_OK if success, an error otherwise
 */
enum command_err_code file_parser__parse_aquarium(
        FILE* file,
        multimatch_t** aquarium_config_all_matches,
        multimatch_t** views_config_all_matches);

/**
 * Free malloc'd regexes
 */
void file_parser__destroy();

#endif //AQUARIUM_SERVER_AQUARIUM_FILE_PARSER_H
