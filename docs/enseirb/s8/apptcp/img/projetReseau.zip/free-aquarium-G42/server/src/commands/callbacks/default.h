#ifndef AQUARIUM_SERVER_DEFAULT_H
#define AQUARIUM_SERVER_DEFAULT_H

#include <stddef.h>
#include <stdio.h>
#include "../command.h"
#include "../../structures/view.h"

/**
 * A temporary callback that can be used when the callback function associated with a command
 * has not been implemented yet.
 * @todo: Remove this default callback once every command is implemented.
 * @return CMD_OK, always
 */
enum command_err_code default_callback(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

#endif //AQUARIUM_SERVER_DEFAULT_H
