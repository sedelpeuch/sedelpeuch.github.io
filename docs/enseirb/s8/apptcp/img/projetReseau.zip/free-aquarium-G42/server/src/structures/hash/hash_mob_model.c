#define TYPE mob_model
#define PATH "../mob_model.h"
#include "hash_type.c"
#undef PATH
#undef TYPE