#include "internal-error.h"

int is_internal_error(enum ret_stat internal_err_code, FILE* err) {
    if (internal_err_code != OK) {
        fprintf(err, "Internal function call returned an error\n");
        return 1;
    } else {
        return 0;
    }
}
