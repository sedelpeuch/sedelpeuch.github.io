#ifndef AQUARIUM_SERVER_FISH_CALLBACKS_H
#define AQUARIUM_SERVER_FISH_CALLBACKS_H

#include <stdio.h>
#include "../command.h"
#include "../../structures/view.h"

/**
 * Print the list of fishes on `out` stream
 * @param argc Must be 0, always
 * @param argv Unused
 * @return CMD_OK, always
 */
enum command_err_code status(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Add a new fish to the aquarium
 * @param argc Must be 6, always
 * @param argv The fish data
 * - argv[0]: name
 * - argv[1]: x
 * - argv[2]: y
 * - argv[3]: width
 * - argv[4]: height
 * - argv[5]: mobility model name
 * @return CMD_OK if success, an error otherwise (if the fish exists already, etc)
 */
enum command_err_code add_fish(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Remove a fish from the aquarium
 * @param argc Must be 1, always
 * @param argv Data used to delete the fish
 * - argv[0]: fish name
 * @return CMD_OK if success, an error otherwise (if the fish does not exist)
 */
enum command_err_code del_fish(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Set the state of a fish to STARTED
 * @param argc Must be 1, always
 * @param argv Data used to find the fish
 * - argv[0]: fish name
 * @return CMD_OK if success, an error otherwise (if the fish does not exist or started already)
 */
enum command_err_code start_fish(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Print the list of fishes relatives to the calling view on `out` stream
 * @param argc Must be 0, always
 * @param argv Unused
 * @return CMD_OK, always
 */
enum command_err_code get_fishes(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);


/**
 * Print the list of fishes relatives and their future transitions to the calling view on `out` stream
 * @param argc Must be 0, always
 * @param argv Unused
 * @return CMD_OK, always
 */
enum command_err_code ls(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);


#endif //AQUARIUM_SERVER_FISH_CALLBACKS_H
