#ifndef AQUARIUM_SERVER_CONFIG_FILE_PARSER_H
#define AQUARIUM_SERVER_CONFIG_FILE_PARSER_H

#include <stddef.h>
#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>

typedef struct config_entry config_entry_t;
typedef void (*parser_to_var_callback_t)(int argc, char** argv, void** dest);

/**
 * Fill the set of config entries with regular expressions & actions.
 * Must be called before any call to config_file_parser__parse_config_file.
 */
void config_entry_set__fill();

/**
 * Parse the config file to load settings.
 */
int config_file_parser__parse_config_file();

/**
 * Free the config entries of the config entry set.
 */
void config_entry_set__destroy();

#endif //AQUARIUM_SERVER_CONFIG_FILE_PARSER_H
