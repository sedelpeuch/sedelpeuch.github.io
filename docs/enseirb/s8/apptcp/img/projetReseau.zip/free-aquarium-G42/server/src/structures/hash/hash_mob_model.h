#ifndef __HASH_MOB_MODEL_H
#define __HASH_MOB_MODEL_H
#define TYPE mob_model
#define PATH "../mob_model.h"
#include "hash_type.h"
#undef PATH
#undef TYPE
#undef __HASH_TYPE_H
#endif