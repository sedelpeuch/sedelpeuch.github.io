#include <assert.h>
#include <unistd.h>
#include <sys/socket.h>
#include "server-callbacks.h"
#include "../../globals/globals.h"
#include "../../log/log.h"

enum command_err_code shutdown_server(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 0);
    
    INFO("Shutting down server");

    if (out != NULL) {
        fprintf(out, "Shutting down server, please wait...\n");
        fprintf(out, "Connected clients will be disconnected after their next command (or timeout)\n");
    }

    exiting = 1;
    int errc = shutdown(accept_socket_fd, SHUT_RDWR); // close() does not stop a concurrent accept() call
    assert(!errc);

    return CMD_OK;
}
