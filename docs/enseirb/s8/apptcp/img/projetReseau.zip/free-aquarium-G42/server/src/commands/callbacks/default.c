#include "default.h"

/**
 * A temporary callback that can be used when the callback function associated with a command
 * has not been implemented yet.
 * @todo: Remove this default callback once every command is implemented.
 * @param argc The number of arguments provided by the parser.
 * @param argv The arguments provided by the parser. Each index of the `argv` array points to a string that represents
 * an argument. If an argument is defined as optional in the regular expression, the argv entry may be NULL.
 * @return CMD_OK, always (∕!\ please don't do that in your own implementation!)
 * @see command_err_code_t
 */
enum command_err_code
default_callback(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    fprintf(out,
            "This is %s(). We are delighted to inform you that your command was called successfully.\n"
           "If you wish to call an actual callback instead, please consider modifying the `callback` argument\n"
           "associated with your command in <server|client>_command_set__fill().\n"
           "(These functions are defined in commands/<server|client>-commands.c)\n"
           "Your arguments are: %s\n", __func__, argc == 0 ? "[no argument]" : "");

    for (unsigned long i = 0; i < argc; i++) {
        fprintf(out,"  %zu: %s\n", i, argv[i]);
    }

    return CMD_OK; // or CMD_ERR_INVALID_ARGUMENTS, for instance
}