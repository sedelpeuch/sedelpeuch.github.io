#ifndef _MOB_MODEL_H
#define _MOB_MODEL_H
#include "ret_stat.h"
#include "transition_private.h"

/**
 * @brief A model of mobility, in other words a standard way to decide destination with its name.
 * 
 * A fish contains a mobility model as a way to access its move function.
 */
typedef struct mob_model mob_model_t;

/**
 * @brief A typedef called move_t to a function pointer type
 * 
 * *move_t takes a pointer to a mobility_t as argument and gives back a ret_stat
 */
typedef enum ret_stat (*move_t)(transition_t*);

/**
 * @brief Only initialize a mob_model this way.
 * 
 * Please don't malloc you own mob_model, initialize it through this function and terminate
 * its lifecycle with the mob_model__end or any function promising to end the mob_model.
 * @param name The name of the mob_model
 * @param move The function pointer that defines the movement
 * @return mob_model_t* The initialized pointer to the demanded mob_model
 */
mob_model_t* mob_model__init(char* name, move_t move);

/**
 * @brief Ends the lifecycle of a mob_model.
 * 
 * @param mob_model The mob_model to end
 * @return enum ret_stat OK if successful, ERR_NULL_GIVEN if mob_model is NULL
 */
enum ret_stat mob_model__end(mob_model_t* mob_model);

/**
 * @brief Get the pointer to the name of the mob_model. Be careful not to modify the name afterwards.
 * 
 * @param mob_model The mob_model inspected
 * @return char* A pointer to the name of the mob_model or NULL if mob_model is NULL.
 */
const char* mob_model__get_name(mob_model_t* mob_model);

enum ret_stat mob_model__apply(mob_model_t* mob_model, transition_t* transition);

#endif //_MOB_MODEL_H