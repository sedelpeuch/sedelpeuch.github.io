#include <assert.h>
#include <string.h>

#include "aquarium-file-parser.h"
#include "command.h"
#include "../log/log.h"

#define FILE_BUFFER_SIZE 1024

static pcre2_code* aquarium_config_regex = NULL;
static pcre2_code* view_config_regex = NULL;

void file_parser__initialize() {
    // The aquarium declaration (<Aquarium_width>x<Aquarium_height>, e.g. 1000x230)
    compile_regex("^(\\d+)x(\\d+)$",
                  &aquarium_config_regex);
    // A view declaration (<ID> <view_x>x<view_y>+<view_width>+<view_height>, e.g. N2 500x0+500+500)
    compile_regex("^(?:(\\S+) (\\d+)x(\\d+)\\+(\\d+)\\+(\\d+)\\s?)$",
                  &view_config_regex);
}

/**
 * Parse the `FILE_BUFFER_SIZE` first bytes of file and looks for multiple `regex` matches.
 * If matches are found, they are stored into `multimatch`.
 * @param file[in] The file to be parsed
 * @param regex[in] The regex that describes the patterns to be matched
 * @param multimatch[out] An array of at most `MAX_MULTIMATCH_NB` items, in which matches are stored.
 * Every entry is a pointer to the result of a regex match: the pointer references the list of captured groups
 * returned by a match.
 * @return CMD_OK if success, an error otherwise
 */
enum command_err_code file_parser__parse_regex(
        FILE* file,
        pcre2_code* regex,
        multimatch_t** multimatch) {
    assert(file);
    assert(regex);
    assert(multimatch);

    *multimatch = malloc(sizeof(multimatch_t));

    // Go back to the beginning of the file
    rewind(file);
    char file_content[FILE_BUFFER_SIZE + 1];

    size_t read_bytes = fread(file_content, sizeof(char), FILE_BUFFER_SIZE, file);
    if (read_bytes <= 0) return CMD_ERR_FILE_CONTENT_ERROR;

    // Add trailing '\0'
    file_content[read_bytes] = '\0';

    int match_ret_val;
    size_t offset = 0; // The offset to `file_content` at which the match begins (modified in the loop)
    size_t len = strlen(file_content);
    (*multimatch)->all_matches_nb = 0;

    // Initialize the structure
    pcre2_match_data* reg_matches = pcre2_match_data_create_from_pattern(regex, NULL);

    // While there is a match between file_content+offset and EOF
    while (offset < len
            &&  (match_ret_val = pcre2_match(regex,
                                            (PCRE2_SPTR) file_content,
                                            strlen(file_content),
                                            offset, // Start at offset
                                            0, // Default options
                                            reg_matches, // Result
                                            NULL) // Use default context
            ) >= 0) {

        // Initialize the match vector
        size_t* ovector = pcre2_get_ovector_pointer(reg_matches);

        // Store the list of captured groups into the multimatch
        pcre2_substring_list_get(reg_matches,
                                 (PCRE2_UCHAR8***) &(*multimatch)->all_matches[(*multimatch)->all_matches_nb],
                                 NULL);

        (*multimatch)->all_matches_nb++;
        // Get the offset at which the last capturing group ended
        // The next match will start at this offset
        offset = ovector[2*match_ret_val-1];
    }

    pcre2_match_data_free(reg_matches);

    return CMD_OK;
}

enum command_err_code file_parser__parse_aquarium(FILE* file, multimatch_t** aquarium_config_all_matches,
                                                  multimatch_t** views_config_all_matches) {
    assert(file);

    enum command_err_code err_code;
    // Look for the aquarium declaration: <Aquarium_width>x<Aquarium_height>
    err_code = file_parser__parse_regex(file, aquarium_config_regex, aquarium_config_all_matches);
    if (err_code != CMD_OK) { return err_code; }
    // Look for the view declarations: <ID> <view_x>x<view_y>+<view_width>+<view_height>
    err_code = file_parser__parse_regex(file, view_config_regex, views_config_all_matches);

    return err_code;
}

void file_parser__destroy() {
    pcre2_code_free(aquarium_config_regex);
    pcre2_code_free(view_config_regex);
}