#ifndef __AREA_H
#define __AREA_H

/**
 * @brief area_t represents the size of an object
 * 
 */
typedef struct area {
    int width; ///< The horizontal size of the object
    int height; ///< The vertical size of the object
} area_t;

#endif