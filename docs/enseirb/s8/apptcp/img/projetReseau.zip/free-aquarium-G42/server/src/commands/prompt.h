#ifndef __PROMPT_H_
#define __PROMPT_H_

/**
 * Run an interactive CLI that interprets commands of the server command set.
 */
void run_server_cli();

#endif // __PROMPT_H_
