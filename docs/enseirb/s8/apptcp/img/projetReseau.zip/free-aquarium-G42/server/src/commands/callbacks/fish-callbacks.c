#include <assert.h>
#include <string.h>
#include "fish-callbacks.h"
#include "../../structures/public_structures.h"
#include "../internal-error.h"
#include "../../log/log.h"

#define FISH_BUFFER_SIZE 70

position_t position__server_to_client(position_t position, position_t view_position, area_t view_area) {
    TRACE("Converting position from server to client");
    int x, y;
    x = ((position.x - view_position.x) * 100) / view_area.width;
    y = ((position.y - view_position.y) * 100) / view_area.height;
    return (position_t) { .x = x, .y = y };
}

position_t position__client_to_server(position_t position, position_t view_position, area_t view_area) {
    TRACE("Converting position from client to server");
    int x, y;
    x = view_position.x + (position.x * view_area.width) / 100;
    y = view_position.y + (position.y * view_area.height) / 100;
    return (position_t) { .x = x, .y = y };
}

area_t area__server_to_client(area_t area, area_t view_area) {
    TRACE("Converting area from server to client");
    int height, width;
    height = (area.height * 100) / view_area.height;
    width = (area.width * 100) / view_area.width;
    return (area_t) { .height = height, .width = width };
}
area_t area__client_to_server(area_t area, area_t view_area) {
    TRACE("Converting area from client to server");
    int height, width;
    height = (area.height * view_area.height) / 100;
    width = (area.width * view_area.width) / 100;
    return (area_t) { .height = height, .width = width };
}

enum command_err_code status(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 0);

    INFO("Getting fish status");

    view_t* view = *client_view;
    if (!view) {
        fprintf(err," -> NOK: Client should have asked for a view first\n");
        ERR("Client did not ask for a view first.");
        return CMD_ERR_INVALID_STATE;
    }
    
    aquarium__refresh_all_fishes();

    int nb_fishes = aquarium__nb_fishes();

    fprintf(out," -> OK: Connected to controller, %d fish%s found\n", nb_fishes, nb_fishes > 1 ? "es" : "");
    INFO("Connected to controller, %d fish%s found. Displaying status.", nb_fishes, nb_fishes > 1 ? "es" : "");

    area_t view_area = view__get_area(view);
    position_t view_position = view__get_position(view);

    fish_t** fish_table = aquarium__get_all_fishes();

    for (int i = 0; i < nb_fishes; i++) {
        //if (fish__cross_view(fish_table[i], view)) {
        area_t a = fish__get_size(fish_table[i]);
        position_t p = fish__get_position(fish_table[i]);
        a = area__server_to_client(a, view_area);
        p = position__server_to_client(p, view_position, view_area);
        enum status s = fish__get_status(fish_table[i]);
        fprintf(out, "   Fish %s at %dx%d,%d+%d %s\n",
                fish__get_name(fish_table[i]),
                p.x, p.y, a.width, a.height,
                s == STARTED ? "started" : s == NOT_STARTED ? "notStarted" : "statusError");
        TRACE("Displaying status of fish %s", fish__get_name(fish_table[i]));
        //}
    }

    aquarium__free_gotten_fishes(fish_table);

    return CMD_OK;
}

enum command_err_code add_fish(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 6);
    assert(argv != NULL);
    INFO("Trying to add fish");

    view_t* view = *client_view;
    if (!view) {
        fprintf(err," -> NOK: Client should have asked for a view first\n");
        ERR("Client did not ask for a view first.");
        return CMD_ERR_INVALID_STATE;
    }
    area_t view_area = view__get_area(view);
    position_t view_position = view__get_position(view);

    char* fish_name = malloc(strlen(argv[0]) + 1);
    strcpy(fish_name, argv[0]);

    position_t pos = { .x = atoi(argv[1]), .y = atoi(argv[2]) };
    area_t area = { .width = atoi(argv[3]), .height = atoi(argv[4]) };
    pos = position__client_to_server(pos, view_position, view_area);
    area = area__client_to_server(area, view_area);

    char const* mob_model_name = argv[5];

    fish_t* f = fish__init(fish_name, area, pos, mob_model_name);

    enum ret_stat internal_ret_code = aquarium__add_fish(f);

    if (is_internal_error(internal_ret_code, err)) {
        ERR("Internal error");
        return CMD_ERR_INVALID_ARGUMENTS;
    }

    fprintf(out, " -> Fish added\n");
    INFO("Fish %s added successfully", fish_name);

    return CMD_OK;
}

enum command_err_code del_fish(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 1);
    assert(argv != NULL);
    INFO("Trying to delete fish");

    view_t* view = *client_view;
    if (!view) {
        fprintf(err," -> NOK: Client should have asked for a view first\n");
        ERR("Client did not ask for a view first.");
        return CMD_ERR_INVALID_STATE;
    }

    char const* fish_name = argv[0];

    enum ret_stat ret_val = aquarium__del_fish_end(fish_name);

    if (is_internal_error(ret_val, err)) {
        ERR("Internal error");
        return CMD_ERR_INVALID_ARGUMENTS;
    }

    INFO("Fish %s deleted successfully", fish_name);

    return CMD_OK;
}

enum command_err_code start_fish(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 1);
    assert(argv != NULL);
    INFO("Trying to start fish");

    view_t* view = *client_view;
    if (!view) {
        fprintf(err," -> NOK: Client should have asked for a view first\n");
        ERR("Client did not ask for a view first.");
        return CMD_ERR_INVALID_STATE;
    }

    char const* fish_name = argv[0];

    fish_t* fish = aquarium__find_fish(fish_name);

    if (fish == NULL) {
        fprintf(err, "Could not start fish %s: fish does not exist\n", fish_name);
        ERR("Could not start fish %s: fish does not exist\n", fish_name);
        return CMD_ERR_INVALID_ARGUMENTS;
    }

    enum status s = fish__get_status(fish);

    if (s != NOT_STARTED) {
        fprintf(err, "Could not start fish %s: fish %s\n",
                fish_name,
                (s == STARTED) ? "started already" : "has an invalid state");
        ERR("Could not start fish %s: fish %s\n",
                fish_name,
                (s == STARTED) ? "started already" : "has an invalid state");
        return CMD_ERR_INVALID_STATE;
    }

    fish__start(fish);
    INFO("Fish %s successfully started", fish_name);
    fprintf(out, "\n"); // Flushes on the client's side, allows for multiline commands of startFish
    return CMD_OK;
}

enum command_err_code get_fishes(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view){
    assert(argc == 0);
    INFO("Trying to get fishes list");

    view_t* view = *client_view;
    if (!view) {
        fprintf(err," -> NOK: Client should have asked for a view first\n");
        ERR("Client did not ask for a view first.");
        return CMD_ERR_INVALID_STATE;
    }
    area_t view_area = view__get_area(view);
    position_t view_position = view__get_position(view);

    aquarium__refresh_all_fishes();

    int nb_fishes = aquarium__nb_fishes();
    if (nb_fishes == 0) {
        WARN("%s", "No fish");
        fprintf(out, "list\n");
        return CMD_OK;
    }

    fish_t** fish_table = aquarium__get_all_fishes();

    INFO("%d fish%s found. Beggining display process.\n", nb_fishes, nb_fishes > 1 ? "es" : "");

    char* buffer = malloc(sizeof(char) * 50 * nb_fishes);
    char tmp[50];
    strcpy(buffer, "list");

    for (int i = 0; i < nb_fishes; i++) {
        if (fish__cross_view(fish_table[i], view) && fish__get_status(fish_table[i]) == STARTED) {
            int t = fish__get_time_to_dest(fish_table[i]);
            area_t a = fish__get_size(fish_table[i]);
            position_t p = fish__get_destination(fish_table[i]);
            a = area__server_to_client(a, view_area);
            p = position__server_to_client(p, view_position, view_area);
            enum status s = fish__get_status(fish_table[i]);
            sprintf(tmp, " [%s at %dx%d,%dx%d,%d]",
                    fish__get_name(fish_table[i]),
                    p.x, p.y, a.width, a.height, t);
            strcat(buffer, tmp);
            TRACE("Information display about fish %s", fish__get_name(fish_table[i]));
        }
    }
    fprintf(out, "%s\n", buffer);

    free(buffer);
    aquarium__free_gotten_fishes(fish_table);

    return CMD_OK;
}


enum command_err_code ls(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view){
    assert(argc == 0);
    INFO("Trying to list future positions of fishes");

    view_t* view = *client_view;
    if (!view) {
        fprintf(err," -> NOK: Client should have asked for a view first\n");
        ERR("Client did not ask for a view first.");
        return CMD_ERR_INVALID_STATE;
    }
    area_t view_area = view__get_area(view);
    position_t view_position = view__get_position(view);

    aquarium__refresh_all_fishes();

    int nb_fishes = aquarium__nb_fishes();

    if (nb_fishes == 0) {
        WARN("%s", "No fish");
        fprintf(out, "list\n");
        return CMD_OK;
    }

    fish_t** fish_table = aquarium__get_all_fishes();
    int nb_transitions = fish__get_nb_destinations(fish_table[0]);

    int nb_crossing_fishes = 0;

    for (int i = 0; i < nb_fishes; i++) {
        if (fish__will_cross_view(fish_table[i], view) && fish__get_status(fish_table[i]) == STARTED) {
            nb_crossing_fishes++;
        } else {
            fish_table[i] = NULL;
        }
    }

    if (nb_crossing_fishes == 0) {
        WARN("%s", "No fish");
        fprintf(out, "list\n");
        aquarium__free_gotten_fishes(fish_table);
        return CMD_OK;
    }

    position_t* position_table = malloc(sizeof(position_t) * nb_transitions * nb_crossing_fishes);
    int* time_table = malloc(sizeof(int) * nb_transitions * nb_crossing_fishes);
    area_t* area_table = malloc(sizeof(area_t) * nb_crossing_fishes);
    const char** name_table = malloc(sizeof(char*) * nb_crossing_fishes);

    int index = 0;

    INFO("Got %d fish%s. Displaying information\n", nb_crossing_fishes, nb_crossing_fishes > 1 ? "es" : "");

    for (int i = 0; i < nb_crossing_fishes; i++) {
        while (!fish_table[index]) index++;
        area_table[i] = fish__get_size(fish_table[index]);
        name_table[i] = fish__get_name(fish_table[index]);
        position_t* pos_tmp = fish__get_all_destinations(fish_table[index]);
        int* pos_time = fish__get_all_times_to_dest(fish_table[index]);
        for (int j = 0; j < nb_transitions; j++) {
            position_table[i * nb_transitions + j] = pos_tmp[j];
            time_table[i * nb_transitions + j] = pos_time[j];
        }
        free(pos_time);
        free(pos_tmp);
        index++;
    }

    int buffer_size = sizeof(char) * FISH_BUFFER_SIZE * (nb_crossing_fishes * nb_transitions + 1);
    char* buffer = malloc(buffer_size);
    char tmp[FISH_BUFFER_SIZE];
    strcpy(buffer, "");

    for (int j = 0; j < nb_transitions; j++) {
        strcat(buffer, "list");
        for (int i = 0; i < nb_crossing_fishes; i++) {
            area_t a = area__server_to_client(area_table[i], view_area);
            position_t p = position__server_to_client(position_table[i * nb_transitions + j], view_position, view_area);
            sprintf(tmp, " [%s at %dx%d,%dx%d,%d]",
                    name_table[i],
                    p.x, p.y, a.width, a.height, time_table[i * nb_transitions + j]);
            strcat(buffer, tmp);
        }
        strcat(buffer, "; ");
    }
    fprintf(out, "%s\n", buffer);
    free(area_table);
    free(name_table);
    free(position_table);
    free(time_table);
    free(buffer);
    aquarium__free_gotten_fishes(fish_table);

    return CMD_OK;
}