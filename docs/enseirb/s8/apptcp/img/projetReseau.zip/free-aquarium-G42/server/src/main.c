#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include "commands/prompt.h"
#include "commands/client-commands.h"
#include "structures/aquarium.h"
#include "structures/public_structures.h"
#include "globals/globals.h"
#include "threadpool/thpool.h"
#include "log/log.h"
#include "config/config-file-parser.h"
#include "commands/aquarium-file-parser.h"

/**
 * The maximum number of concurrent connections
 */
#define MAX_NB_CONNECTIONS 10

#define THREAD_POOL_SIZE (MAX_NB_CONNECTIONS + 1) // Every client + server CLI

#define BUFFER_SIZE 1023

#define handle_error(msg) \
           do { perror(msg); exit(EXIT_FAILURE); } while (0)

/**
 * A pool of pthreads, to limit the number of pthread_create operations.
 */
threadpool thread_pool;

/**
 * Execute a command and send its output to the socket
 * @param command_text A command received from the client
 * @param socket_file The socket where the output is written
 * @return CMD_OK if success, CMD_OK_DISCONNECT if the client connection must be closed,
 * an error otherwise
 */
enum command_err_code handle_command(char const* command_text, FILE* socket_file, view_t** client_view) {
    enum command_err_code err_code = client_command__exec(command_text,
                                                          socket_file,
                                                          socket_file,
                                                          client_view);

    if (err_code == CMD_OK || err_code == CMD_OK_DISCONNECT) {
        INFO("-> OK\n");
    } else {
        INFO("-> NOK\n");
        fprintf(socket_file,
                "%s (code %d)\n",
                command_error_code_to_text(err_code),
                err_code);
    }

    fflush(socket_file); // Send immediately data to the client

    return err_code;
}

/**
 * Handle connection with the client connected to socket `mallocd_sock_fd`.
 * Wait for commands to be typed
 * @param mallocd_sock_fd A socket file descriptor, allocated on the heap
 */
void handle_connection(void* mallocd_sock_fd) {
    char command_buffer[BUFFER_SIZE + 1];

    // Reallocate socket_fd automatically and free malloc'd socket
    int socket_fd = *(int*) mallocd_sock_fd;

    // Configure timeout on recv() calls
    struct timeval timeout_timeval = { .tv_sec = timeout };
    setsockopt(socket_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout_timeval, sizeof(timeout_timeval));

    FILE* socket_file = fdopen(socket_fd, "r+");

    free(mallocd_sock_fd);

    // Empty the buffer
    bzero(command_buffer, BUFFER_SIZE + 1);

    // The ID of the view associated with this client (set when receiving "hello")
    view_t* client_view = NULL;

    // Wait for messages from the client
    ssize_t read_bytes;
    enum command_err_code cmd_err_code = CMD_OK;

    do {
        TRACE("[%d] Waiting for remote data\n", socket_fd);
        // If nothing is received, timeout
        read_bytes = recv(socket_fd, command_buffer, BUFFER_SIZE, 0);

        if (read_bytes > 0) {
            command_buffer[read_bytes] = '\0'; // Terminate the string, in case the received command has no '\0'
            INFO("[%d] Command received: %s    (size: %zd)\n", socket_fd, command_buffer, read_bytes);
            cmd_err_code = handle_command(command_buffer, socket_file, &client_view);
            // Command is not handled in another thread, since we want to run *at most* one command from the same client
            // at a time (to limit an excessive number of commands from the same client)
        }
    } while (read_bytes > 0 && cmd_err_code != CMD_OK_DISCONNECT && !exiting);

    // Timeout
    if (read_bytes == -1 && errno == EAGAIN) {
        WARN("[%d] Client timeout\n", socket_fd);
    } else if (read_bytes == 0) { // The remote connection was closed
        WARN("[%d] Connection closed by remote\n", socket_fd);
    } else if (cmd_err_code == CMD_OK_DISCONNECT) { // The client asked for a disconnection
        INFO("[%d] Connection closed by server (disconnection request from client)\n", socket_fd);
    } else if (exiting) {
        WARN("[%d] Connection closed by server (shutdown)\n", socket_fd);
    } else { // Any other connection error
        char const* error_buffer = strerror(errno);
        ERR("[%d] Connection error: %s\n", socket_fd, error_buffer);
    }

    unsigned long return_value = close(socket_fd);

    if (client_view) {
        view__set_availability(client_view, FREE);
    }

    assert(!return_value);
}

/**
 * Configure the initial socket and start listening
 * @return The socket file descriptor
 */
int open_socket() {
    struct sockaddr_in serv_addr;
    int socket_fd = socket(AF_INET, SOCK_STREAM, 0); // TCP/IP connection

    if (socket_fd < 0) {
        handle_error("open");
    }

    // Empty the structure
    bzero(&serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);

    if (bind(socket_fd, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) < 0)
        handle_error("bind");
    listen(socket_fd, MAX_NB_CONNECTIONS);

    return socket_fd;
}

/**
 * Wait for client connections, and handle them in new threads.
 * This function does not return
 */
void accept_clients() {
    while (!exiting) {
        struct sockaddr_in client_addr;
        unsigned int client_addr_len = sizeof(client_addr);
        int* accepted_socket = malloc(sizeof(*accepted_socket));

        *accepted_socket = accept(accept_socket_fd, (struct sockaddr*) &client_addr, &client_addr_len);

        // The main socket was shut down by the `shutdown` command
        if (*accepted_socket < 0 && errno == EINVAL) {
            WARN("[%d] Stopped listening new connections (accept)\n", accept_socket_fd);
            free(accepted_socket);
            return;
        }

        if (*accepted_socket < 0) {
            handle_error("accept");
        }

        INFO("[%d] Connected with a new client\n", *accepted_socket);
        int err = thpool_add_work(thread_pool, (void (*)(void*)) handle_connection, accepted_socket);

        if (err) {
            handle_error("pthread_create");
        }
    }
}

/**
 * Create structures used by the server
 */
void initialize() {
    log_output = stdout;

    // Parse the configuration file
    config_entry_set__fill();
    int err = config_file_parser__parse_config_file();

    if (err) {
        exit(err);
    }

    // Load the aquarium
    area_t default_aquarium_area = { .height = 200, .width = 400 };
    aquarium__reset(default_aquarium_area);
    // Initialize mobility models
    dic_mob_model__init();

    thread_pool = thpool_init(THREAD_POOL_SIZE);

    file_parser__initialize();
}

/**
 * Free all malloc'd structures
 */
void destroy() {
    aquarium__destroy();
    dic_mob_model__delete_all_end();
    thpool_destroy(thread_pool);
    client_command_set__destroy();
    server_command_set__destroy();
    config_entry_set__destroy();
    file_parser__destroy();
}


int main() {
    initialize();
    printf("\n _________         .    .\n"
         "(..       \\_    ,  |\\  /|\n"
         " \\       O  \\  /|  \\ \\/ /\n"
         "  \\______    \\/ |   \\  / \n"
         "     vvvv\\    \\ |   /  |\n"
         "     \\^^^^  ==   \\_/   |\n"
         "      `\\_   ===    \\.  |\n"
         "      / /\\_   \\ /      |\n"
         "      |/   \\_  \\|      /\n"
         "             \\________/\n");
    // Run the server CLI
    thpool_add_work(thread_pool, (void (*)(void*)) run_server_cli, NULL);

    // Initialize client commands
    client_command_set__fill();

    accept_socket_fd = open_socket();
    INFO("Server up and running (port %d)\n", port);

    accept_clients(); // Does not return until the `shutdown` command is used

    // Graceful shutdown
    thpool_wait(thread_pool);

    destroy();

    WARN("[%d] Main thread exited\n", accept_socket_fd);
}