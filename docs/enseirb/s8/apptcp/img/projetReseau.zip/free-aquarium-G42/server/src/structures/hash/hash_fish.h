#ifndef __HASH_FISH_H
#define __HASH_FISH_H
#define TYPE fish
#define PATH "../fish.h"
#include "hash_type.h"
#undef PATH
#undef TYPE
#undef __HASH_TYPE_H
#endif