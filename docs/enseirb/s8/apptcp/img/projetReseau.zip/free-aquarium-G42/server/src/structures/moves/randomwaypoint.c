#include "randomwaypoint.h"

enum ret_stat randomwaypoint(transition_t* transition) {
    if (transition) {
        position_t position = { rand() % 1000, rand() % 1000};
        transition->destination = position;
        transition->time_to_dest = rand() % 50 + 10;
        return OK;
    }
    return ERR_NULL_GIVEN;
}