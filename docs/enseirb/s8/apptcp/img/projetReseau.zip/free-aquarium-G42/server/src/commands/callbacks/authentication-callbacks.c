#include <assert.h>
#include <string.h>
#include "../../structures/public_structures.h"
#include "authentication-callbacks.h"
#include "../../log/log.h"

enum command_err_code hello(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 0 || argc == 1);
    assert(client_view != NULL);
    INFO("Beginning authentification");

    if (*client_view != NULL) { // The client has already taken a view
        ERR("The client has already taken a view");
        fprintf(err, "The client has already taken a view\n");
        return CMD_ERR_INVALID_STATE;
    }

    view_t* view = NULL;

    if (argc == 1) { // A view ID is specified
        char const* view_name = argv[0];
        view_t* desired_view = aquarium__find_view(view_name);

        TRACE("Trying to access to view %s", view_name);

        // Desired view exists and is available: use it
        if (desired_view != NULL && view__get_availability(desired_view) == FREE) {
            view = desired_view;
            view__set_availability(view, TAKEN);
            *client_view = view;
            fprintf(out, "greeting %s\n", view_name);

            INFO("View %s is granted", view_name);
            return CMD_OK;
        }
    }

    // If no view is specified, the desired view is taken or does not exist, try to find an available view
    view = aquarium__get_available_view();

    if (view == NULL) { // No available view
        ERR("No view available");
        fprintf(out, "no greeting\n");
        return CMD_OK;
    }

    view__set_availability(view, TAKEN);
    *client_view = view;
    fprintf(out, "greeting %s\n", view__get_name(view));

    INFO("Random available view is granted");

    return CMD_OK;
}


enum command_err_code ping(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 1);
    const char* port = argv[0];
    fprintf(out, "pong %s\n", port);
    return CMD_OK;
}

enum command_err_code log_out(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 0);
    fprintf(out, "bye\n");
    return CMD_OK_DISCONNECT;
}
