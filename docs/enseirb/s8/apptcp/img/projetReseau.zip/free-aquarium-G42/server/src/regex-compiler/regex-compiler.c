#include "../log/log.h"
#include <string.h>
#define MAX_ERROR_SIZE 100
#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>
#include "regex-compiler.h"

void compile_regex(char const* input_string_regex, pcre2_code** regex) {
    int error_number;
    PCRE2_SIZE error_offset;

    *regex = pcre2_compile((PCRE2_SPTR) input_string_regex,
                           PCRE2_ZERO_TERMINATED,
                           PCRE2_MULTILINE | PCRE2_UTF | PCRE2_UCP, // Handle multiline strings +
                           // Use UTF-8 in classes (\d, \w, [[:alpha:]]...)
                           &error_number,
                           &error_offset,
                           NULL); // Use default compile context

    if (*regex == NULL) {
        PCRE2_UCHAR error_buffer[MAX_ERROR_SIZE];
        pcre2_get_error_message(error_number, error_buffer, sizeof(error_buffer));
        ERR("PCRE2 compilation failed at offset %d: %s\n", (int) error_offset,
                error_buffer);
        fprintf(stderr, "PCRE2 compilation failed at offset %d: %s\n", (int) error_offset,
                error_buffer);
        exit(1);
    }
}