#ifndef __MOBILITY_PROTECTED_H
#define __MOBILITY_PROTECTED_H
#include "mobility.h"

/**
 * @brief Gets a position_t equivalent to the destination of the mobility.
 * 
 * @param mobility The mobility to inspect
 * @return position_t A copy of the destination of the mobility or { .x = -1, .y = -1} if the mobility is NULL.
 */
position_t mobility__get_destination(const mobility_t* mobility);

/**
 * @brief Gets an int equivalent to the time_to_dest of the mobility.
 * 
 * @param mobility The mobility to inspect
 * @return int A copy of the time_to_dest of the mobility or -1 if the mobility is NULL.
 */
int mobility__get_time_to_dest(const mobility_t* mobility);

#endif // __MOBILITY_PROTECTED_H