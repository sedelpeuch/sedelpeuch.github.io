#ifndef AQUARIUM_SERVER_INTERNAL_ERROR_H
#define AQUARIUM_SERVER_INTERNAL_ERROR_H

#include <stdio.h>
#include "../structures/ret_stat.h"

/**
 * Check if `internal_err_code` is an error.
 * If it is an error, this function prints an error message to stream `err`.
 * @param internal_err_code An error code returned by a function defined under structures/
 * @param err A stream where the error message should be printed
 * @return 0 if internal_err_code is OK, 1 otherwise
 */
int is_internal_error(enum ret_stat internal_err_code, FILE* err);

#endif //AQUARIUM_SERVER_INTERNAL_ERROR_H
