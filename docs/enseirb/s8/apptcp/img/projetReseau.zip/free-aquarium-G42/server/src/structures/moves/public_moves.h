#ifndef __PUBLIC_MOVES_H
#define __PUBLIC_MOVES_H

#include "randomwaypoint.h"
#include "horizontalwaypoint.h"
#include "verticalwaypoint.h"

#endif //__PUBLIC_MOVES_H