#ifndef __PUBLIC_STRUCTURES_H
#define __PUBLIC_STRUCTURES_H

#include "area.h"
#include "position.h"

#include "fish.h"
#include "view.h"
#include "mob_model.h"

#include "aquarium.h"
#include "dic_mob_model.h"

#include "moves/public_moves.h"

#endif //__PUBLIC_STRUCTURES_H