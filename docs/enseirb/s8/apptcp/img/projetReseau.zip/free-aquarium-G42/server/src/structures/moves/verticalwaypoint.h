#ifndef __VERTICALWAYPOINT_H
#define __VERTICALWAYPOINT_H
#include <stdlib.h>
#include "../ret_stat.h"
#include "../transition_private.h"

/**
 * @brief Another mobility function
 * 
 * @param transition The structure representing the past coordinates of a fish.
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if mobility is NULL.
 */
enum ret_stat verticalwaypoint(transition_t* transition);

#endif //__VERTICALWAYPOINT_H