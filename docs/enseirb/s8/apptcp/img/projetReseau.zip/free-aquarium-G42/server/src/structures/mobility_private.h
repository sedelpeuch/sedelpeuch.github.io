#ifndef __MOBILITY_PRIVATE_H
#define __MOBILITY_PRIVATE_H
#include "mobility_protected.h"

/**
 * @brief Sets the destination of a given mobility.
 * 
 * @param mobility The mobility to modify
 * @param destination The destination to give to the mobilty
 * @return enum ret_stat Returns OK if everything went fine. 
 * Will return ERR_NULL_GIVEN if mobility is NULL.
 */
enum ret_stat mobility__set_destination(mobility_t* mobility, position_t destination);

/**
 * @brief Sets the time_to_dest of a given mobility.
 * 
 * @param mobility The mobility to modify
 * @param time The time_to_dest to give to the mobilty
 * @return enum ret_stat Returns OK if everything went fine. 
 * Will return ERR_NULL_GIVEN if mobility is NULL.
 */
enum ret_stat mobility__set_time_to_dest(mobility_t* mobility, int time);

#endif // __MOBILITY_PRIVATE_H