#include "aquarium.h"
#include "hash/hash_fish.h"
#include "hash/hash_view.h"
#include "../log/log.h"
#include <time.h>
#include <stdlib.h>
#include <pthread.h>

#define REFRESH_BOUND 1

struct aquarium {
    area_t area;
    int locks_init;
    pthread_rwlock_t views_lock;
    hash_view_t** map_view;
    pthread_rwlock_t fishes_lock;
    hash_fish_t** map_fish;
    time_t last_refresh;
};

/**
 * Return a pointer to the aquarium (singleton)
 * @return The aquarium instance
 */
static aquarium_t* aquarium__get() {
    static aquarium_t main_aquarium = {
            .locks_init = 0,
            .map_fish = NULL,
            .map_view = NULL,
            .area = {
                    .width = -1,
                    .height = -1,
            }};

    if (main_aquarium.locks_init == 0) {
        main_aquarium.locks_init = 1;
        pthread_rwlock_init(&main_aquarium.fishes_lock, NULL);
        pthread_rwlock_init(&main_aquarium.views_lock, NULL);
    }

    return &main_aquarium;
}

aquarium_t* aquarium__reset(area_t area) {
    INFO("%s", "Resetting aquarium");
    aquarium_t* aquarium = aquarium__get();

    pthread_rwlock_wrlock(&aquarium->fishes_lock);
    pthread_rwlock_wrlock(&aquarium->views_lock);

    // Frees resources allocated by the aquarium fields, when the aquarium was initialized already
    if (aquarium->map_view != NULL && aquarium->map_fish != NULL) {
        aquarium__end_end();
    }

    aquarium->area = area;
    aquarium->map_view= map_view__init();
    aquarium->map_fish = map_fish__init();

    pthread_rwlock_unlock(&aquarium->views_lock);
    pthread_rwlock_unlock(&aquarium->fishes_lock);
    return aquarium;
}

enum ret_stat aquarium__end_end() {
    aquarium_t* aquarium = aquarium__get();

    enum ret_stat ret;
    if (aquarium) {
        ret = map_view__end_end(aquarium->map_view);
        if (ret != OK) return ret;
        ret = map_fish__end_end(aquarium->map_fish);
        if (ret != OK) return ret;
    }
    return OK;
}

enum ret_stat aquarium__add_view(view_t* view) {
    INFO("Adding view in aquarium of size %d, %d", view__get_area(view).height, view__get_area(view).width);
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        pthread_rwlock_wrlock(&aquarium->views_lock);
        enum ret_stat res = map_view__add(aquarium->map_view, view);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return res;
    }
    ERR("Could not get aquarium");
    return ERR_NULL_GIVEN;
}

enum ret_stat aquarium__del_view(char const* name) {
    aquarium_t* aquarium = aquarium__get();

    if (aquarium && name) {
        pthread_rwlock_wrlock(&aquarium->views_lock);
        enum ret_stat res = map_view__del(aquarium->map_view, name);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return res;
    }
    ERR("Could not get aquarium or name is NULL");
    return ERR_NULL_GIVEN;
}

enum ret_stat aquarium__del_view_end(char const* name) {
    INFO("Deleting view %s", name);
    aquarium_t* aquarium = aquarium__get();

    if (aquarium && name) {
        pthread_rwlock_wrlock(&aquarium->views_lock);
        enum ret_stat res = map_view__del_end(aquarium->map_view, name);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return res;
    }
    ERR("Could not get aquarium or name is NULL");
    return ERR_NULL_GIVEN;
}


view_t* aquarium__find_view(char const* name) {
    INFO("Finding view with name %s", name);
    aquarium_t* aquarium = aquarium__get();

    if (aquarium && name) {
        pthread_rwlock_rdlock(&aquarium->views_lock);
        view_t* res = map_view__find(aquarium->map_view, name);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return res;
    }
    ERR("Could not get aquarium or name is NULL");
    return NULL;
}

view_t* aquarium__get_available_view() {
    INFO("Getting available view");
    aquarium_t* aquarium = aquarium__get();
    if (aquarium) {
        pthread_rwlock_rdlock(&aquarium->views_lock);
        view_t* res = map_view__get_available_view(aquarium->map_view);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return res;
    }
    ERR("Could not get aquarium");
    return NULL;
}


int aquarium__nb_views() {
    INFO("Getting number of views");
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        pthread_rwlock_rdlock(&aquarium->views_lock);
        int res =  map_view__get_number(aquarium->map_view);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return res;
    }
    ERR("Could not get aquarium");
    return -1;
}


view_t** aquarium__get_all_views() {
    INFO("Getting all views");
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        pthread_rwlock_rdlock(&aquarium->views_lock);
        return map_view__get_all(aquarium->map_view);
    }
    ERR("Could not get aquarium");
    return NULL;
}

enum ret_stat aquarium__free_gotten_views(view_t** all_views) {
    INFO("Freeing gotten views");
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        free(all_views);
        pthread_rwlock_unlock(&aquarium->views_lock);
        return OK;
    }
    ERR("Could not get aquarium");
    return ERR_NULL_GIVEN;
}


enum ret_stat aquarium__add_fish(fish_t* fish) {
    INFO("Adding fish %s in aquarium", fish__get_name(fish));
    aquarium_t* aquarium = aquarium__get();


    if (aquarium) {
        pthread_rwlock_wrlock(&aquarium->fishes_lock);
        enum ret_stat res = map_fish__add(aquarium->map_fish, fish);
        pthread_rwlock_unlock(&aquarium->fishes_lock);
        return res;
    }
    ERR("Could not get aquarium");
    return ERR_NULL_GIVEN;
}

enum ret_stat aquarium__del_fish(char const* name) {
    aquarium_t* aquarium = aquarium__get();

    if (aquarium && name) {
        pthread_rwlock_wrlock(&aquarium->fishes_lock);
        enum ret_stat res = map_fish__del(aquarium->map_fish, name);;
        pthread_rwlock_unlock(&aquarium->fishes_lock);
        return res;
    }
    ERR("Could not get aquarium or name is NULL");
    return ERR_NULL_GIVEN;
}

enum ret_stat aquarium__del_fish_end(char const* name) {
    aquarium_t* aquarium = aquarium__get();

    if (aquarium && name) {
        pthread_rwlock_wrlock(&aquarium->fishes_lock);
        enum ret_stat res = map_fish__del_end(aquarium->map_fish, name);
        pthread_rwlock_unlock(&aquarium->fishes_lock);
        return res;
    }
    ERR("Could not get aquarium or name is NULL");
    return ERR_NULL_GIVEN;
}

fish_t* aquarium__find_fish(char const* name) {
    INFO("Finding fish with name %s",name);
    aquarium_t* aquarium = aquarium__get();

    if (aquarium && name) {
        pthread_rwlock_rdlock(&aquarium->fishes_lock);
        fish_t* res = map_fish__find(aquarium->map_fish, name);
        pthread_rwlock_unlock(&aquarium->fishes_lock);
        return res;
    }
    ERR("Could not get aquarium or name is NULL");
    return NULL;
}

int aquarium__nb_fishes()  {
    INFO("Geting number of fishes");
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        pthread_rwlock_rdlock(&aquarium->fishes_lock);
        int res = map_fish__get_number(aquarium->map_fish);
        pthread_rwlock_unlock(&aquarium->fishes_lock);
        return res;
    }
    ERR("Could not get aquarium");
    return -1;
}

fish_t** aquarium__get_all_fishes() {
    INFO("Getting all fishes");
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        pthread_rwlock_rdlock(&aquarium->fishes_lock);
        return map_fish__get_all(aquarium->map_fish);
    }
    ERR("Could not get aquarium");
    return NULL;
}

enum ret_stat aquarium__free_gotten_fishes(fish_t** all_fishes) {
    INFO("Freeing gotten fishes");
    aquarium_t* aquarium = aquarium__get();

    if (aquarium) {
        free(all_fishes);
        pthread_rwlock_unlock(&aquarium->fishes_lock);
        return OK;
    }
    ERR("Could not get aquarium");
    return ERR_NULL_GIVEN;
}

area_t aquarium__get_area() {
    INFO("Getting area of aquarium");
    aquarium_t* aquarium = aquarium__get();
    if(aquarium) {
        return aquarium->area;
    }
    area_t ret = {.height = -1, .width = -1};
    ERR("Could not get aquarium");
    return ret;
}

enum ret_stat aquarium__refresh_all_fishes() {
    aquarium_t* aquarium = aquarium__get();
    time_t new_time = time(NULL);
    if (!aquarium) {
        ERR("Could not get aquarium");
        return ERR_NULL_GIVEN;
    }
    if (new_time - REFRESH_BOUND >= aquarium->last_refresh) {
        pthread_rwlock_wrlock(&aquarium->fishes_lock);
        int nb_fishes =  map_fish__get_number(aquarium->map_fish);
        fish_t** fishes = map_fish__get_all(aquarium->map_fish);

        for (int i=0; i < nb_fishes; i++) {
            fish__move_itself(fishes[i], new_time);
        }
        aquarium->last_refresh = new_time;
        return aquarium__free_gotten_fishes(fishes);
    }
}

enum ret_stat aquarium__destroy() {
    aquarium_t* aquarium = aquarium__get();
    if (aquarium) {
        pthread_rwlock_wrlock(&aquarium->fishes_lock);
        pthread_rwlock_wrlock(&aquarium->views_lock);
        aquarium__end_end();
        pthread_rwlock_destroy(&aquarium->views_lock);
        pthread_rwlock_destroy(&aquarium->fishes_lock);
        return OK;
    }
    return ERR_NULL_GIVEN;
}
