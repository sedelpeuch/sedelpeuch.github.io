#include "mob_model.h"
#include <stdlib.h>

typedef struct mob_model {
    char* name;
    move_t move;
} mob_model_t;

mob_model_t* mob_model__init(char* name, move_t move) {
    mob_model_t* res = malloc(sizeof(mob_model_t));
    res->name = name;
    res->move = move;
    return res;
}

enum ret_stat mob_model__end(mob_model_t* mob_model) {
    if (mob_model) {
        free(mob_model);
        return OK;
    }
    return ERR_NULL_GIVEN;
}

const char* mob_model__get_name(mob_model_t* mob_model) {
    if (mob_model) return mob_model->name;
    return NULL;
}

enum ret_stat mob_model__apply(mob_model_t* mob_model, transition_t* transition) {
    if (mob_model && transition) {
        return mob_model->move(transition);
    }
    return ERR_NULL_GIVEN;
}