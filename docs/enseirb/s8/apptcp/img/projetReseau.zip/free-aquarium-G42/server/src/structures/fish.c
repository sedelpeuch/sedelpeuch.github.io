#include "fish.h"
#include "mobility_protected.h"
#include "dic_mob_model.h"
#include "../log/log.h"
#include <stdlib.h>
#include <string.h>

#define NB_TRANSITIONS 3

typedef struct fish {
    char* name;
    area_t size;
    enum status status;
    mobility_t* mobility;
    mob_model_t* mob_model;
} fish_t;

fish_t* fish__init(char* name, area_t size, position_t position, char const* mob_model_name) {
    INFO("Creating a new fish with name %s", name);
    mob_model_t* tmp = dic_mob_model__find(mob_model_name);
    if (!tmp) {
        return NULL;
    }
    fish_t* res = malloc(sizeof(fish_t));
    res->name = malloc(sizeof(char) * (strlen(name) + 1));
    strcpy(res->name, name);
    res->size = size;
    res->status = NOT_STARTED;
    res->mobility = mobility__init(position, tmp, NB_TRANSITIONS);
    res->mob_model = tmp;
    return res;
}

enum ret_stat fish__end(fish_t* fish) {
    if (fish) {
        if (fish->mobility) {
            mobility__end(fish->mobility);
            free(fish->name);
            free(fish);
            return OK;
        }
        return ERR_NO_MOBILITY;
    }
    return ERR_NULL_GIVEN;
}

const char* fish__get_name(const fish_t* fish) {
    INFO("Getting fish name");
    if (fish) {
        TRACE("The name of the fish is %s", fish->name);
        return fish->name;
    }
    WARN("Fish doesn't exists");
    return NULL;
}

area_t fish__get_size(const fish_t* fish) {
    INFO("Getting fish size");
    if (fish) {
        TRACE("The name of the fish %s is %dx%d", fish->name, fish->size.width, fish->size.height);
        return fish->size;
    }
    area_t ret = {.height = -1, .width = -1};
    WARN("Fish doesn't exists");
    return ret;
}

enum status fish__get_status(const fish_t* fish) {
    INFO("Getting fish status");
    if (fish) {
        TRACE("The name of the fish %s is %u", fish->name, fish->status);
        return fish->status;
    }
    WARN("Fish doesn't exists");
    return ERR_STATUS;
}

position_t fish__get_position(const fish_t* fish) {
    INFO("Getting fish position");
    if (fish) {
        TRACE("The position of the fish %s is %dx%d", fish->name, mobility__get_position(fish->mobility).x,
              mobility__get_position(fish->mobility).y);
        return mobility__get_position(fish->mobility);
    }
    position_t ret = {.x = -1, .y = -1};
    WARN("Fish doesn't exists");
    return ret;
}

position_t fish__get_destination(const fish_t* fish) {
    INFO("Getting fish destination");
    if (fish) {
        TRACE("The destination of the fish %s is %dx%d", fish->name, mobility__get_destination(fish->mobility).x,
              mobility__get_destination(fish->mobility).y);
        return mobility__get_destination(fish->mobility);
    }
    position_t ret = {.x = -1, .y = -1};
    WARN("Fish doesn't exists");
    return ret;
}

position_t* fish__get_all_destinations(const fish_t* fish) {
    INFO("Getting all fish destinations");
    if (fish) return mobility__get_all_destinations(fish->mobility);
    WARN("Fish doesn't exists");
    return NULL;
}

int fish__get_nb_destinations(const fish_t* fish) {
    INFO("Getting number fish destinations");
    if (fish) {
        TRACE("The number of destinations of the fish %s is %d", fish->name, mobility__get_nb_transitions(fish->mobility));
        return mobility__get_nb_transitions(fish->mobility);
    }
    WARN("Fish doesn't exists");
    return -1;
}

int fish__get_time_to_dest(const fish_t* fish) {
    INFO("Getting time to destination");
    if (fish) {
        TRACE("The time to destination of the fish %s is %d", fish->name, mobility__get_time_to_dest(fish->mobility));
        return mobility__get_time_to_dest(fish->mobility);
    }
    WARN("Fish doesn't exists");
    return -1;
}

int* fish__get_all_times_to_dest(const fish_t* fish) {
    INFO("Getting all times to destinations");
    if (fish) return mobility__get_all_times(fish->mobility);
    WARN("Fish doesn't exists");
    return NULL;
}

enum ret_stat fish__set_status(fish_t* fish, enum status status) {
    INFO("Setting fish status");
    if (fish) {
        fish->status = status;
        return OK;
    }
    WARN("Fish doesn't exists");
    return ERR_NULL_GIVEN;
}

enum ret_stat fish__start(fish_t* fish) {
    INFO("Starting fish %s", fish__get_name(fish));
    mobility__start(fish->mobility, time(NULL));
    return fish__set_status(fish, STARTED);
}

enum ret_stat fish__move_itself(fish_t* fish, time_t time) {
    INFO("Moving fish in %ld seconds", time);
    if (fish) {
        if (fish->mob_model) {
            if (fish->mobility) {
                if (fish__get_status(fish) == STARTED)
                    mobility__refresh(fish->mobility, fish->mob_model, time);
                return OK;
            }
            WARN("Fish mobility doesn't exists");
            return ERR_NO_MOBILITY;
        }
        WARN("Fish model doesn't exists");
        return ERR_NO_MOB_MODEL;
    }
    WARN("Fish doesn't exists");
    return ERR_NULL_GIVEN;
}

bool fish__will_cross_view(fish_t* fish, view_t* view) {
    return mobility__will_cross_view(fish->mobility, fish__get_size(fish), view);
}

bool fish__cross_view(fish_t* fish, view_t* view) {
    return mobility__cross_view(fish->mobility, fish__get_size(fish), view);
}
