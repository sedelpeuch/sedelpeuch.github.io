#ifndef __TRANSITION_PRIVATE_H
#define __TRANSITION_PRIVATE_H

#include <sys/queue.h>
#include "position.h"
#include "area.h"

typedef struct transition {
    position_t destination;
    int time_to_dest;
    STAILQ_ENTRY(transition) next;  
} transition_t;

STAILQ_HEAD(transition_queue, transition);

#endif // __TRANSITION_PRIVATE_H
