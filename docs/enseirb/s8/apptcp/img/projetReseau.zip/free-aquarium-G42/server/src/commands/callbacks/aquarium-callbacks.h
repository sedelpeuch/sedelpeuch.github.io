#ifndef AQUARIUM_SERVER_AQUARIUM_CALLBACKS_H
#define AQUARIUM_SERVER_AQUARIUM_CALLBACKS_H

#include <stddef.h>
#include <stdio.h>
#include "../command.h"

/**
 * Initialize an aquarium from a file
 * @param argc Must be 1, always
 * @param argv argv[0]: the aquarium file name
 * @return CMD_OK if success, an error otherwise
 * (file does not exist, is not formatted properly, etc)
 */
enum command_err_code load_aquarium(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Show the aquarium topology
 * @param argc Must be 0, always
 * @param argv Nothing
 * @return CMD_OK, always
 */
enum command_err_code show_aquarium(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Add a view to the aquarium
 * @param argc Must be 5, always
 * @param argv Data used to create the view
 * - argv[0]: name
 * - argv[1]: x
 * - argv[2]: y
 * - argv[3]: width
 * - argv[4]: height
 * @return CMD_OK if success, an error otherwise (if the view exists already, etc)
 */
enum command_err_code add_view(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Remove a view from the aquarium
 * @param argc Must be 1, always
 * @param argv Data used to delete the view
 * - argv[0]: view name
 * @return CMD_OK if success, an error otherwise (if the view does not exist)
 */
enum command_err_code del_view(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);


enum command_err_code save_aquarium(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);
enum command_err_code set_log_file(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Set log file for the server
* @param argc Must be 1, always
 * @param argv the name of a log file
 * @return CMD_OK if success, an error otherwise
 */
enum command_err_code set_log_file(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

#endif //AQUARIUM_SERVER_AQUARIUM_CALLBACKS_H
