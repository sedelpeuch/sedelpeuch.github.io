#include "config-file-parser.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../log/log.h"
#include "../regex-compiler/regex-compiler.h"
#include "../globals/globals.h"

#define FILE_BUFFER_SIZE 4096
#define MAX_ERROR_SIZE 200
#define MAX_SETTING_NB 10

/**
 * The path to the config file.
 */
static char config_file_path[] = "controller.cfg";

/**
 * The set of config entries that can be parsed from the config file.
 */
typedef struct config_entry_set {
    config_entry_t* settings[MAX_SETTING_NB]; ///< An array of config entries
    size_t nb_settings; ///< The number of config entries that were added to the config-entry set
} config_entry_set_t;

static config_entry_set_t config_entry_set = {.nb_settings = 0};

/**
 * A config entry that can be parsed from the config file.
 * The parser searches regex matches, then write the value to setting_address
 * using callback.
 */
struct config_entry {
    pcre2_code* regex; ///< The regex that describes the syntax of the setting in the config file
    void** setting_address;    ///< The address of the variable that should receive the parsed value
    parser_to_var_callback_t callback; ///< A callback to write into dest the value(s) received in argv
};

/**
 * A simple callback, to read an int & write it to dest
 */
void int_to_param(int argc, char** argv, void** dest) {
    assert(argc == 1);
    int* dest_int = (int*) dest;
    *dest_int = atoi(argv[0]);
}


void config_entry__initialize(char const* regex,
                              void** setting_address,
                              parser_to_var_callback_t callback) {
    assert(regex);
    assert(callback);
    assert(config_entry_set.nb_settings < MAX_SETTING_NB);

    TRACE("Initializing config-file parser");

    // Allocate a new config_entry_t and store its address into the first free config_entry_t* element of command_set->commands
    config_entry_t* new_config_entry = malloc(sizeof(config_entry_t));
    config_entry_set.settings[config_entry_set.nb_settings] = new_config_entry;

    int error_number;
    PCRE2_SIZE error_offset;

    new_config_entry->regex = pcre2_compile((PCRE2_SPTR) regex,
            PCRE2_ZERO_TERMINATED,
            PCRE2_UTF | PCRE2_UCP, // Use UTF-8 in classes (\d, \w, [[:alpha:]]...)
            &error_number,
            &error_offset,
            NULL); // Use default compile context

    // Handle regex errors
    if (new_config_entry->regex == 0) {
        PCRE2_UCHAR error_buffer[MAX_ERROR_SIZE];
        pcre2_get_error_message(error_number, error_buffer, sizeof(error_buffer));
        ERR("PCRE2 compilation failed at offset %d: %s", (int) error_offset,
            error_buffer);
        fprintf(stderr, "PCRE2 compilation failed at offset %d: %s\n", (int) error_offset,
                error_buffer);
        exit(1);
    }

    new_config_entry->callback = callback;
    new_config_entry->setting_address = setting_address;

    config_entry_set.nb_settings++;
}

void config_entry_set__fill() {
    config_entry__initialize("controller-port = (\\d+)",
                             (void**) &port,
                             int_to_param);
    config_entry__initialize("display-timeout-value = (\\d+)",
                             (void**) &timeout,
                             int_to_param);
    config_entry__initialize("log-mode = (\\d+)",
                             (void**) &log_mode,
                             int_to_param);

}


int config_file_parser__parse_entry(FILE* file, config_entry_t* config_entry,
                                                      PCRE2_UCHAR8*** matches) {
    assert(file);
    assert(config_entry);
    assert(config_entry->regex);
    assert(config_entry->callback);
    assert(config_entry->setting_address);

    // Initialize the structure
    pcre2_match_data* reg_matches = pcre2_match_data_create_from_pattern(config_entry->regex, NULL);

    // Go back to the beginning of the file (just in case)
    rewind(file);
    char file_content[FILE_BUFFER_SIZE + 1];

    size_t read_bytes = fread(file_content, sizeof(char), FILE_BUFFER_SIZE, file);
    if (read_bytes <= 0) return -1;

    // Add trailing '\0'
    file_content[read_bytes] = '\0';

    int nb_matches;


    // While there is a match between file_content and EOF
    if ((nb_matches = pcre2_match(config_entry->regex,
                                        (PCRE2_SPTR) file_content,
                                        strlen(file_content),
                                        0, // Start at offset 0
                                        0, // Default options
                                        reg_matches, // Result
                                        NULL) // Use default context
               ) >= 0) {



        // Store the list of captured groups into the match
        pcre2_substring_list_get(reg_matches,
                                 (PCRE2_UCHAR8***) matches,
                                 NULL);
    }

    pcre2_match_data_free(reg_matches);

    return nb_matches;
}

int config_file_parser__parse_config_file() {
    INFO("Parsing config file");

    FILE* file = fopen(config_file_path, "r");

    if (!file) {
        ERR("Could not open config file");
        perror("fopen");
        return -1;
    }

    for (size_t i = 0; i < config_entry_set.nb_settings; i++) {
        PCRE2_UCHAR8** matches;

        int nb_matches = config_file_parser__parse_entry(file, config_entry_set.settings[i], &matches);

        if (nb_matches <= 0) {
            fclose(file);
            ERR("Error parsing config file");
            return -1;
        }

        config_entry_set.settings[i]->callback(nb_matches - 1,
                                               (char**) &matches[1],
                                               config_entry_set.settings[i]->setting_address);

        pcre2_substring_list_free((PCRE2_SPTR8*) matches);
    }

    int ret = fclose(file);

    if (ret) {
        ERR("Error closing config file");
        perror("fclose");
    }

    return ret;
}

void config_entry_set__destroy() {
    for (int i = 0; i < config_entry_set.nb_settings; i++) {
        free(config_entry_set.settings[i]->regex);
        free(config_entry_set.settings[i]);
    }

    config_entry_set.nb_settings = 0;
}
