#ifndef AQUARIUM_SERVER_GLOBALS_H
#define AQUARIUM_SERVER_GLOBALS_H

/**
 * 1 when the server is going to stop (after the `shutdown` command),
 * 0 otherwise.
 */
extern int exiting;

/**
 * The socket used to accept client connections
 */
extern int accept_socket_fd;

/**
 * The port on which the server is running
 */
extern unsigned int port;

/**
 * Time after which the client is disconnected, when the server
 * has not received any message.
 */
extern unsigned int timeout;

#endif //AQUARIUM_SERVER_GLOBALS_H
