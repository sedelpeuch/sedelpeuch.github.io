#ifndef __AQUARIUM_H
#define __AQUARIUM_H
#include "position.h"
#include "area.h"
#include "view.h"
#include "fish.h"

/**
 * @brief represents the aquarium of our simulation. 
 * It contains the fishes and the views and has an area that gives meaning to other area and position values.
 * 
 */
typedef struct aquarium aquarium_t;

/**
 * @brief Initializes or resets the aquarium.
 * If the aquarium was initialized already, its resources are freed.
 *
 * @return aquarium_t* The address of the aquarium.
 * @see aquarium__get() To get the address of the aquarium.
 * @see aquarium__end_end() To free the resources allocated, at the end of the program.
 */
aquarium_t* aquarium__reset(area_t area);

/**
 * @brief Ends the lifecycle of the views and the fishes in an aquarium, without freeing the aquarium itself.
 * 
 * Releases properly the views and the fishes added in the lifetime of the aquarium.
 * @param aquarium The aquarium to end.
 * @return enum ret_stat Returns OK if everything went fine and ERR_NULL_GIVEN if its structures are NULL.
 */
enum ret_stat aquarium__end_end();


enum ret_stat aquarium__destroy();


/**
 * @brief Adds a given view to the aquarium.
 *
 * @param view The view to add
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the view container (Internal error) or the view is NULL,
 * ERR_ALREADY_INSIDE if the view container contains a view with the same name already.
 */
enum ret_stat aquarium__add_view(view_t* view);

/**
 * @brief Deletes a view from the aquarium. The name of the view to delete must be given.
 * 
 * Deletes the view from the view container inside the aquarium.
 * But does not end the view in question.
 * @param name The name of the view to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the view container (Internal error) or name is NULL,
 * ERR_NOT_INSIDE if the aquarium does not contain a view whose name is name. 
 */
enum ret_stat aquarium__del_view(char const* name);

/**
 * @brief Deletes a view from the aquarium. The name of the view to delete must be given.
 * 
 * Deletes the view from the view container inside the aquarium.
 * The view deleted from the aquarium is ended in the process.
 * @param name The name of the view to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the view container (Internal error) or name is NULL,
 * ERR_NOT_INSIDE if the aquarium does not contain a view whose name is name. 
 */
enum ret_stat aquarium__del_view_end(char const* name);

/**
 * @brief Finds a view, previously added to the aquarium, by its name.
 * 
 * @param aquarium The aquarium to search into
 * @param name The name of the view to find
 * @return view_t* The found view or NULL is the view is not inside.
 */
view_t* aquarium__find_view(char const* name);

/**
 * @brief Finds an available view, if possible
 * @return The found view or NULL if there is no available view.
 */
view_t* aquarium__get_available_view();

/**
 * @brief Gets the number of view currently added to the aquarium.
 * 
 * @param aquarium The aquarium inspected.
 * @return int The number of views added in the aquarium or -1 if aquarium or the view container (Internal error) is NULL
 */
int aquarium__nb_views();

/**
 * @brief Gets all the views added in the aquarium in a malloc'd table. Do not forget to free the table.
 * 
 * @param aquarium The aquarium inspected.
 * @return view_t** A table of pointers to views. It contains all the views added to the aquarium.
 * The pointer is NULL if the view container (Internal error) is NULL.
 */
view_t** aquarium__get_all_views();

enum ret_stat aquarium__free_gotten_views(view_t** all_views) ;

/**
 * @brief Adds a given fish to the aquarium.
 * 
 * @param aquarium The aquarium to add to
 * @param fish The fish to add
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the fish container (Internal error) or the fish is NULL,
 * ERR_ALREADY_INSIDE if the fish container contains a fish with the same name already.
 */
enum ret_stat aquarium__add_fish(fish_t* fish);

/**
 * @brief Deletes a fish from the aquarium. The name of the fish to delete must be given.
 * 
 * Deletes the fish from the fish container inside the aquarium.
 * But does not end the fish in question.
 * @param name The name of the fish to delete
 * @return enum ret_stat Returns OK if everything went fine,
 * ERR_NULL_GIVEN if the fish container (Internal error) or name is NULL,
 * ERR_NOT_INSIDE if the aquarium does not contain a fish whose name is name. 
 */
enum ret_stat aquarium__del_fish(char const* name);

/**
 * @brief Finds a fish, previously added to the aquarium, by its name.
 *
 * @param name The name of the fish to find
 * @return fish_t* The found fish or NULL is the fish is not inside is NULL.
 */
enum ret_stat aquarium__del_fish_end(char const* name);

/**
 * @brief Finds a fish, previously added to the aquarium, by its name.
 *
 * @param name The name of the fish to find
 * @return fish_t* The found fish or NULL is the fish is not inside is NULL.
 */
fish_t* aquarium__find_fish(char const* name);

/**
 * @brief Gets the number of fish currently added to the aquarium.
 *
 * @return int The number of fishes added in the aquarium or -1 if the fish container (Internal error) is NULL
 */
int aquarium__nb_fishes();

/**
 * @brief Gets all the fishes added in the aquarium in a malloc'd table. Do not forget to free the table.
 * 
 * @param aquarium The aquarium inspected.
 * @return fish_t** A table of pointers to fishes. It contains all the fishes added to the aquarium.
 * The pointer is NULL if the fish container (Internal error) is NULL.
 */
fish_t** aquarium__get_all_fishes();


enum ret_stat aquarium__free_gotten_fishes(fish_t** all_fishes);

/**
 * @brief Returns a pointer ont the area of the aquarium
 * 
 * @param aquarium The aquarium to search into
 * @return area_t The area of the aquarium.
 */
 area_t aquarium__get_area();

/**
 * @brief Refreshes (the mobility) of all the fishes in the aquarium. 
 */
enum ret_stat aquarium__refresh_all_fishes();

#endif // __AQUARIUM_H