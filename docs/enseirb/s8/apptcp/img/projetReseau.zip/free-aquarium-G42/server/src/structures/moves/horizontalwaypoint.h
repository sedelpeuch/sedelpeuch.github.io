#ifndef __HORIZONTALWAYPOINT_H
#define __HORIZONTALWAYPOINT_H
#include <stdlib.h>
#include "../ret_stat.h"
#include "../transition_private.h"

/**
 * @brief Another mobility function
 * 
 * @param transition The structure representing the past coordinates of a fish.
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if mobility is NULL.
 */
enum ret_stat horizontalwaypoint(transition_t* transition);

#endif //__HORIZONTALWAYPOINT_H