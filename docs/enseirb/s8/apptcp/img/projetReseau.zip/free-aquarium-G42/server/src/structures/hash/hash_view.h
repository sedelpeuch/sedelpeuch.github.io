#ifndef __HASH_VIEW_H
#define __HASH_VIEW_H
#define TYPE view
#define PATH "../view.h"
#include "hash_type.h"
#undef PATH
#undef TYPE
#undef __HASH_TYPE_H

/**
 * @brief Gets a view previously added to map_view that is available at the time of the call. If no such view exist, return NULL.
 * 
 * @param map_view The map_view to inspect
 * @return view_t* An available view if there is one in the map_view, NULL if there is no such view or if map_view is NULL.
 */
view_t* map_view__get_available_view(hash_view_t** map_view);

#endif