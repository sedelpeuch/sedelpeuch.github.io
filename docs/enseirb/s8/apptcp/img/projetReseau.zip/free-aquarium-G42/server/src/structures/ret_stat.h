#ifndef __RET_STAT_H
#define __RET_STAT_H

enum ret_stat {
    OK, 
    ERR_NULL_GIVEN,
    ERR_NO_MOB_MODEL,
    ERR_NO_MOBILITY,
    ERR_NO_ID,
    ERR_ALREADY_INSIDE,
    ERR_NOT_INSIDE,
};

#endif //__RET_STAT_H