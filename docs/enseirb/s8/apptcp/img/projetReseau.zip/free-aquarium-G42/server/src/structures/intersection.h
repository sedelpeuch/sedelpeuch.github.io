#include <stdbool.h>
#include "position.h"
#include "area.h"

bool moving__cross_fix(area_t moving_size, position_t starting_position, position_t ending_position, area_t fix_area, position_t fix_position);