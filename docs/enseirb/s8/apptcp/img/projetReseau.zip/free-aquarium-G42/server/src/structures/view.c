#include "view.h"
#include "../log/log.h"
#include <stdlib.h>
#include <string.h>

typedef struct view {
    char* name;
    area_t area;
    position_t position;
    enum availability availability;
} view_t;

view_t* view__init(char const* name, area_t area, position_t position) {
    INFO("Initializing of the %s view", name);
    view_t* res = malloc(sizeof(view_t));
    res->area = area;
    res->position = position;
    res->name = malloc(sizeof(char) * (strlen(name) + 1));
    strcpy(res->name, name);
    res->availability = FREE;
    return res;
}

enum ret_stat view__end(view_t* view) {
    INFO("Ending view");
    if (view) {
        TRACE("The %s view is destroyed", view->name);
        free(view->name);
        free(view);
        return OK;
    }
    WARN("View doesn't exists");
    return ERR_NULL_GIVEN;
}

area_t view__get_area(const view_t* view) {
    INFO("Getting area of view");
    if (view) {
        TRACE("The area of %s view is %dx%d", view->name, view->area.width, view->area.height);
        return view->area;
    }
    area_t ret = {.height = -1, .width = -1};
    WARN("View doesn't exist");
    return ret;
}

position_t view__get_position(const view_t* view) {
    INFO("Getting position of view");
    if (view) {
        TRACE("The position of %s view is %dx%d", view->name, view->position.x, view->position.y);
        return view->position;
    }
    position_t ret = {.x = -1, .y = -1};
    WARN("View doesn't exists");
    return ret;
}

const char* view__get_name(const view_t* view) {
    INFO("Getting name of view");
    if (view) {
        TRACE("View name is %s", view->name);
        return view->name;
    }
    WARN("View doesn't exists");
    return NULL;
}

enum availability view__get_availability(const view_t* view) {
    INFO("Getting availability of view");
    if (view) {
        TRACE("The availability of %s view is %u", view->name, view->availability);
        return view->availability;
    }
    WARN("View doesn't exists");
    return ERROR;
}

enum ret_stat view__set_availability(view_t* view, enum availability availability) {
    INFO("Setting availability of view");
    if (view) {
        TRACE("The availability of %s view has been set to %d", view->name, view->availability);
        view->availability = availability;
        return OK;
    }
    WARN("View doesn't exists");
    return ERR_NULL_GIVEN;
}
