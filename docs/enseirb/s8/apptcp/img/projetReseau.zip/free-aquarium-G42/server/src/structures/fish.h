#ifndef __FISH_H
#define __FISH_H
#include "area.h"
#include "position.h"
#include <stdbool.h>
#include <time.h>
#include "view.h"


/**
 * @brief represents the fish with its size, name, status, future destination, time before he arrives,
 * And a way for it to move. 
 * 
 */
typedef struct fish fish_t;

/**
 * @brief represents the different status a fish can have in its lifecycle. 
 * 
 * ERR_STATUS is a debugging tool not a real status.
 */
enum status {
    STARTED,
    NOT_STARTED,
    ERR_STATUS,
};

/**
 * @brief Only initialize a fish this way.
 * 
 * Please don't malloc you own fish, initialize it through this function and terminate
 * its lifecycle with the fish__end or any function promising to end the fish.
 * @param name The name of the fish
 * @param size The size of the fish, relative to a future aquarium (%)
 * @param position The position of the fish at initialization
 * @param mob_model_name The name of the mob_model to be attributed to the fish
 * @return fish_t* The initialized pointer to the demanded fish
 * Or NULL if the mob_model_name does not concur with one of the map_mob_model global.
 */
fish_t* fish__init(char* name, area_t size, position_t position, char const* mob_model_name);

/**
 * @brief Ends the lifecycle of the fish.
 * 
 * @param fish The fish to end
 * @return enum ret_stat OK if successful.
 * ERR_NULL_GIVEN if fish is NULL,
 * else ERR_NO_MOBILITY if fish's mobility is NULL (Internal error).
 */
enum ret_stat fish__end(fish_t* fish);

/**
 * @brief Gets the pointer to the name of the fish. Be careful not to modify the name afterwards.
 * 
 * @param fish The fish inspected
 * @return const char* A pointer to the name of the fish or NULL if the fish is NULL.
 */
const char* fish__get_name(const fish_t* fish);

/**
 * @brief Gets a copy of the size of the fish.
 * 
 * @param view The fish inspected
 * @return area_t The size of the fish or {.height = -1, .width = -1} if the fish is NULL.
 */
area_t fish__get_size(const fish_t* fish);

/**
 * @brief Gets a copy of the status of the fish
 * 
 * @param fish The fish inspected
 * @return enum status The status of the fish or ERR_STATUS if the fish is NULL.
 */
enum status fish__get_status(const fish_t* fish);

/**
 * @brief Gets a copy of the destination of the fish
 * 
 * @param fish The fish inspected
 * @return position_t The destination of the fish or {.x = -1, .y = -1} if fish is NULL.
 */
position_t fish__get_destination(const fish_t* fish);

/**
 * @brief Gets a copy of the time_to_dest of the fish
 * 
 * @param fish The fish inspected
 * @return int The time_to_dest of the fish or -1 if the fish is NULL. 
 */
int fish__get_time_to_dest(const fish_t* fish);

/**
 * @brief Sets the status of a given fish to STARTED
 * 
 * @param fish The fish to start
 * @return enum ret_stat Returns OK if everything went fine. 
 * Will return ERR_NULL_GIVEN if fish is NULL.
 */
enum ret_stat fish__start(fish_t* fish);

/**
 * @brief Applies to the mobility of the fish the move function it contains.
 * 
 * @param fish The fish to move
 * @return enum ret_stat May return a wide array of possible ret_stat depending on the mobility model of the fish.
 * Should return OK if everything went fine. 
 * Will return ERR_NULL_GIVEN if the fish is NULL 
 * Or ERR_NO_MOB_MODEL if its mobility model is NULL (Internal error)
 * Or ERR_NO_MOBILITY if its mobility is NULL (Internal error). 
 */
enum ret_stat fish__move_itself(fish_t* fish, time_t time);

/**
 * @brief Gets an estimation of the current position of a fish
 * 
 * @param fish The fish inspected
 * @return position_t The current position of the fish
 */
position_t fish__get_position(const fish_t* fish);

/**
 * @brief Gets all the known destinations of the fish in a malloc'd table. (Must be freed)
 * 
 * @param fish The fish inspected
 * @return position_t* A pointer to all future destinations of a fish (Must be freed) 
 */
position_t* fish__get_all_destinations(const fish_t* fish);

/**
 * @brief Gets the number of known destinations of a fish
 * 
 * @param fish The fish inspected
 * @return int The number of known destiantions of a fish
 */
int fish__get_nb_destinations(const fish_t* fish);

/**
 * @brief Gets all the known time to destination of all the future destination of a fish, in a malloc'd table. (Must be freed)
 * 
 * @param fish The fish inspected
 * @return int* A pointer to all the known time to destination of the a fish. (Must be freed)
 */
int* fish__get_all_times_to_dest(const fish_t* fish);

/**
 * @brief Checks if a fish path will cross (or belong to) a view in its known future transitions.
 * 
 * @param fish The fish inspected
 * @param view The view inspected
 * @return true if the fish will cross (or belong to) the view in its known future transitions.
 * @return false if otherwise.
 */
bool fish__will_cross_view(fish_t* fish, view_t* view);

/**
 * @brief Checks if a fish path will cross (or belong to) a view in its current transition.
 * 
 * @param fish The fish inspected
 * @param view The view inspected
 * @return true if the fish will cross (or belong to) the view in its current transition.
 * @return false if otherwise.
 */
bool fish__cross_view(fish_t* fish, view_t* view);

#endif // __FISH_H