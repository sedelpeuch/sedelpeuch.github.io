#ifndef AQUARIUM_SERVER_AUTHENTICATION_CALLBACKS_H
#define AQUARIUM_SERVER_AUTHENTICATION_CALLBACKS_H

#include <stddef.h>
#include <stdio.h>
#include "../command.h"

/**
 * Allow client to take a view, if possible.
 */
enum command_err_code hello(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

/**
 * Return a pong.
 */
enum command_err_code ping(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);


/**
 * Close the connection with the client who sent the command.
 */
enum command_err_code log_out(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view);

#endif
