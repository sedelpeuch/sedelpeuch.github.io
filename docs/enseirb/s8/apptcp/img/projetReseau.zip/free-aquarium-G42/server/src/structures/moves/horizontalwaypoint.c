#include "horizontalwaypoint.h"

enum ret_stat horizontalwaypoint(transition_t* transition) {
    if (transition) {
        transition->destination.x = rand() % 1000;
        transition->time_to_dest = rand() % 50 + 10;
        return OK;
    }
    return ERR_NULL_GIVEN;
}