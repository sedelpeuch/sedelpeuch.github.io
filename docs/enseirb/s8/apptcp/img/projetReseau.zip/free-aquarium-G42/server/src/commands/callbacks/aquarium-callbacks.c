#include <assert.h>
#include <errno.h>
#include <string.h>
#include "../../structures/public_structures.h"
#include "aquarium-callbacks.h"
#include "../aquarium-file-parser.h"
#include "../internal-error.h"
#include "../../log/log.h"

enum command_err_code load_aquarium(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    INFO("Aquarium is loading");
    assert(argc == 1);

    char const* aquarium_file_name = argv[0];

    FILE* aquarium_file = fopen(aquarium_file_name, "r");
    TRACE("Opening aquarium file");

    if (aquarium_file == NULL) { // Error opening file
        ERR("File %s did not open",aquarium_file_name);
        fprintf(err, "%s\n", strerror(errno));
        return CMD_ERR_FILE_ERROR;
    }

    // Store matches returned by the file parser
    multimatch_t* aquarium_config_all_matches = NULL;
    multimatch_t* views_config_all_matches = NULL;

    // Looks for aquarium & view settings
    enum command_err_code err_code = file_parser__parse_aquarium(aquarium_file,
                                                                 &aquarium_config_all_matches,
                                                                 &views_config_all_matches);

    // aquarium__add_view() return code
    enum ret_stat internal_ret_code;

    size_t nb_views_loaded = 0;

    // No error & the number of matches is correct
    if (err_code == CMD_OK
        && aquarium_config_all_matches->all_matches_nb == 1
        && views_config_all_matches->all_matches_nb >= 1) {

        INFO("Configuring aquarium");
        area_t aquarium_area;
        // Get width & height from the first (and only) match of aquarium_config_all_matches (index 0)
        // In this match, [1] contains the first captured group (width) and [2] the second one (height)
        aquarium_area.width = atoi(aquarium_config_all_matches->all_matches[0][1]);
        TRACE("Setting aquarium width to %d", aquarium_area.width);
        aquarium_area.height = atoi(aquarium_config_all_matches->all_matches[0][2]);
        TRACE("Setting aquarium height to %d", aquarium_area.height);

        // Initialize or reset the aquarium with `aquarium_area`
        aquarium__reset(aquarium_area);


        // Create & add views
        nb_views_loaded = views_config_all_matches->all_matches_nb;
        TRACE("Setting number of views to %zu", nb_views_loaded);
        view_t** views_loaded = malloc(nb_views_loaded * sizeof(view_t*));

        for (size_t i = 0; i < views_config_all_matches->all_matches_nb; i++) {
            // Copy the view name from views_config_all_matches into a new malloc'd variable
            char* view_name = malloc(strlen((char*) views_config_all_matches->all_matches[i][1]) + 1);
            strcpy(view_name, (char*) views_config_all_matches->all_matches[i][1]);

            TRACE("Adding view %s", view_name);


            position_t pos;
            pos.x = atoi(views_config_all_matches->all_matches[i][2]);
            pos.y = atoi(views_config_all_matches->all_matches[i][3]);

            area_t a;
            a.width = atoi(views_config_all_matches->all_matches[i][4]);
            a.height = atoi(views_config_all_matches->all_matches[i][5]);

            

            views_loaded[i] = view__init(view_name, a, pos);

            internal_ret_code = aquarium__add_view(views_loaded[i]);

            free(view_name);

            if (internal_ret_code != OK) {
                ERR("Could not create view %s", view_name);
                fprintf(err, "Error creating view %zu (internal code %d)\n", i, internal_ret_code);
                break;
            }
        }

        free(views_loaded);

        // Free PCRE2 string structures
        TRACE("Freeing PCRE2 string structures");
        for (size_t i = 0; i < aquarium_config_all_matches->all_matches_nb; i++) {
            pcre2_substring_list_free((PCRE2_SPTR8*) aquarium_config_all_matches->all_matches[i]);
        }

        for (size_t i = 0; i < views_config_all_matches->all_matches_nb; i++) {
            pcre2_substring_list_free((PCRE2_SPTR8*) views_config_all_matches->all_matches[i]);
        }
    }

    // Parser error
    if (err_code != CMD_OK) {
        fprintf(err, "Error parsing file\n");
        free(aquarium_config_all_matches);
        free(views_config_all_matches);
        return err_code;
    }

    // aquarium__add_view() returned an error
    if (internal_ret_code != OK) {
        ERR("aquarium__add_view returned an error");
        fprintf(err, "Internal function aquarium__add_view() returned an error\n");
        free(aquarium_config_all_matches);
        free(views_config_all_matches);
        return CMD_ERR_FILE_CONTENT_ERROR;
    }

    // Try to close file
    if (fclose(aquarium_file)) {
        ERR("Aquarium file did not close");
        fprintf(err, "Could not close file %s\n", aquarium_file_name);
        free(aquarium_config_all_matches);
        free(views_config_all_matches);
        return CMD_ERR_FILE_ERROR;
    }

    // Found less or more than 1 aquarium declaration: error
    if (aquarium_config_all_matches->all_matches_nb < 1) {
        ERR("Could not find aquarium declaration in file %s", aquarium_file_name);
        fprintf(err, "Could not find aquarium declaration in file %s\n", aquarium_file_name);
        free(aquarium_config_all_matches);
        free(views_config_all_matches);
        return CMD_ERR_FILE_CONTENT_ERROR;
    } else if (aquarium_config_all_matches->all_matches_nb > 1) {
        ERR("Found multiple aquarium declarations in file %s\n(only one declaration is allowed)",
                aquarium_file_name);
        fprintf(err, "Found multiple aquarium declarations in file %s\n(only one declaration is allowed)\n",
                aquarium_file_name);
        free(aquarium_config_all_matches);
        free(views_config_all_matches);
        return CMD_ERR_FILE_CONTENT_ERROR;
    }

    // Found no view in file: error
    if (views_config_all_matches->all_matches_nb < 1) {
        ERR("Could not find any view declaration in file %s\n(at least one view must be declared)",
                aquarium_file_name);
        fprintf(err, "Could not find any view declaration in file %s\n(at least one view must be declared)\n",
                aquarium_file_name);
        free(aquarium_config_all_matches);
        free(views_config_all_matches);
        return CMD_ERR_FILE_CONTENT_ERROR;
    }

    fprintf(out, " -> Aquarium loaded (%zu display view%s)\n", nb_views_loaded, nb_views_loaded > 1 ? "s" : "");

    INFO("Aquarium loaded");

    free(aquarium_config_all_matches);
    free(views_config_all_matches);
    return CMD_OK;
}

enum command_err_code show_aquarium(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 0);
    INFO("Showing aquarium");

    area_t area = aquarium__get_area();

    fprintf(out, "%dx%d\n", area.width, area.height);

    view_t** view_table = aquarium__get_all_views();
    int nb_views = aquarium__nb_views();

    for (size_t i = 0; i < nb_views; i++) {
        area_t a = view__get_area(view_table[i]);
        position_t p = view__get_position(view_table[i]);
        fprintf(out, "%s %dx%d+%d+%d\n", view__get_name(view_table[i]), p.x, p.y, a.width, a.height);
    }

    aquarium__free_gotten_views(view_table);

    return CMD_OK;
}

enum command_err_code add_view(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 5);
    assert(argv != NULL);
    INFO("Trying to add view");

    char* view_name = malloc(strlen(argv[0]) + 1);
    strcpy(view_name, argv[0]);

    position_t pos = {.x = atoi(argv[1]), .y = atoi(argv[2])};
    area_t area = {.width = atoi(argv[3]), .height = atoi(argv[4])};

    view_t* v = view__init(view_name, area, pos);

    enum ret_stat internal_ret_code = aquarium__add_view(v);

    if (is_internal_error(internal_ret_code, err)) {
        ERR("Could not add view %s", view_name);
        return CMD_ERR_INVALID_ARGUMENTS;
    }

    INFO("View %s added", view_name);
    fprintf(out, " -> View added\n");

    return CMD_OK;
}

enum command_err_code del_view(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 1);
    assert(argv != NULL);
    INFO("Trying to delete view");

    char const* view_name = argv[0];

    enum ret_stat ret_val = aquarium__del_view_end(view_name);

    if (is_internal_error(ret_val, err)) {
        ERR("Could not delete view %s", view_name);
        return CMD_ERR_INVALID_ARGUMENTS;
    }

    INFO("View %s deleted", view_name);
    fprintf(out, " -> View %s deleted\n", view_name);

    return CMD_OK;
}

/**
 * This function is the callback on "log <filename>"
 */
enum command_err_code set_log_file(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 1);
    assert(argv != NULL);
    INFO("Setting file logs");

    char const* log_file_name = argv[0];
    FILE* file = fopen(log_file_name, "a");

    if (file == NULL) {
        perror("fopen");
        ERR("Could not open file %s", log_file_name);
        return CMD_ERR_INVALID_ARGUMENTS;
    }

    if (log_output != stdout && log_output != stderr) {
        fclose(log_output);
        TRACE("Closing former log output");
    }
    log_output = file;
    printf("%p \n", log_output);

    INFO("New log file is %s", log_file_name);
    fprintf(out, " -> Log file is %s\n", log_file_name);
    fprintf(log_output, "--------------------------------------------------\n");
    fflush(log_output);
    return CMD_OK;
}

enum command_err_code save_aquarium(size_t argc, char const* const* argv, FILE* out, FILE* err, view_t** client_view) {
    assert(argc == 1);

    char const* aquarium_file_name = argv[0];

    FILE* aquarium_file = fopen(aquarium_file_name, "w");

    if (aquarium_file == NULL) { // Error opening file
        fprintf(err, "%s\n", strerror(errno));
        return CMD_ERR_FILE_ERROR;
    }

    // Redirects the output of the show_aquarium callback to aquarium_file
    enum command_err_code res = show_aquarium(0, NULL, aquarium_file, err, client_view);
    
    // Try to close file
    if (fclose(aquarium_file)) {
        fprintf(err, "Could not close file %s\n", aquarium_file_name);
        return CMD_ERR_FILE_ERROR;
    }

    return res;
}