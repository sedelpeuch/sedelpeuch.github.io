#ifndef __MOBILITY_H
#define __MOBILITY_H
#include "area.h"
#include "position.h"
#include "ret_stat.h"
#include "mob_model.h"
#include "view.h"
#include <time.h>
#include <stdbool.h>


/**
 * @brief represents future space-time coordinates. Present location can be represented with a time_to_dest of 0 
 * 
 */
typedef struct mobility mobility_t;


/**
 * @brief Only initialize a mobility this way.
 *
 * Please don't malloc you own mobility, initialize it through this function and terminate
 * its lifecycle with the mobility__end or any function promising to end the mobiltiy. 
 * @param position The initial position
 * @return mobility_t* The initialized pointer to the demanded mobility.
 */
mobility_t* mobility__init(position_t position, mob_model_t* mob_model, int nb_transitions);

/**
 * @brief Ends the lifecycle of the mobility.
 * 
 * @param mobility The mobility to end
 * @return OK if successful, ERR_NULL_GIVEN if mobility is NULL
 */
enum ret_stat mobility__end(mobility_t* mobility);

enum ret_stat mobility__start(mobility_t* mobility, time_t time);

position_t mobility__get_destination(const mobility_t* mobility);

int mobility__get_nb_transitions(const mobility_t* mobility);

position_t* mobility__get_all_destinations(const mobility_t* mobility);

int* mobility__get_all_times(const mobility_t* mobility);

int mobility__get_time_to_dest(const mobility_t* mobility);

position_t mobility__get_position(const mobility_t* mobility);

enum ret_stat mobility__refresh(mobility_t* mobility, mob_model_t* mob_model, time_t t);

bool mobility__cross_view(mobility_t* mobility, area_t mobility_size, view_t* view);

bool mobility__will_cross_view(mobility_t* mobility, area_t mobility_size, view_t* view);

#endif // __MOBILITY_H