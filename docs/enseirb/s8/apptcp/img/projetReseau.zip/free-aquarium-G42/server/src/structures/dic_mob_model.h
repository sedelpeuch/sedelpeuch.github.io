#ifndef __DIC_MOB_MODEL_H
#define __DIC_MOB_MODEL_H
#include "mob_model.h"
#include "ret_stat.h"

/**
 * @brief Initializes dic_mob_model with all mobility models
 */
void dic_mob_model__init();

/**
 * @brief Finds a mob_model, previously added to the hidden dictionary, by its name.
 * 
 * @param name The name of the mob_model to find
 * @return mob_model_t* The found mob_model or NULL is the mob_model is not inside, or if the dictionary or name are NULL.
 */
mob_model_t* dic_mob_model__find(char const* name);

/**
 * @brief Deletes all the mob_model from the hidden dictionary. Does not end them.
 * 
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if the dictionary is NULL
 */
enum ret_stat dic_mob_model__delete_all();

/**
 * @brief Deletes and ends all the mob_model from the hidden dictionary.
 * 
 * @return enum ret_stat OK if everything went fine and ERR_NULL_GIVEN if the dictionary is NULL
 */
enum ret_stat dic_mob_model__delete_all_end();

/**
 * @brief Gets the number of mob_models currently added to the hidden dictionary.
 * 
 * @return int The number of mob_models added in the dictionary or -1 if dictionary is NULL
 */
int dic_mob_model__get_number();

/**
 * @brief Gets all the mob_models added in the hidden dictionary in a malloc'd table. Do not forget to free the table.
 * 
 * @return mob_model_t** A table of pointers to mob_models. It contains all the mob_models added to the dictionary.
 * The pointer is NULL if the dictionary is NULL.
 */
mob_model_t** dic_mob_model__get_all();

#endif // __DIC_MOB_MODEL_H