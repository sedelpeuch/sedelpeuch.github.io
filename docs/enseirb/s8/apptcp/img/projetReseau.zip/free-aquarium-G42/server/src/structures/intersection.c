#include "intersection.h"
#include <stdio.h>

bool vector__is_null(position_t vector) {
    return !(vector.x || vector.y);
}

position_t vector__difference(position_t v1, position_t v2) {
    return (position_t) {.x = (v1.x - v2.x), .y = (v1.y - v2.y)} ;
}

position_t vector__sum(position_t v1, position_t v2) {
    return (position_t) {.x = (v1.x + v2.x), .y = (v1.y + v2.y)} ;
}

int vector__product_plane(position_t v1, position_t v2) {
    return (v1.x * v2.y) - (v2.x * v1.y);
}

int vector__dot_product(position_t v1, position_t v2) {
    return (v1.x * v2.x) + (v1.y * v2.y);
}

bool coord__in_interval(float x, float i1, float i2) {
    if (i1 > i2) return coord__in_interval(x, i2, i1);
    return (x >= i1 && x <= i2);
}

bool interval__intersect(float i1, float i2, float j1, float j2) {
    return (coord__in_interval(i1, j1, j2)\
    || coord__in_interval(i2, j1, j2)\
    || coord__in_interval(j1, i1, i2));
}

bool segment__intersect(position_t p1, position_t p2, position_t p3, position_t p4) {
    position_t vecr = vector__difference(p2, p1);
    position_t vecs = vector__difference(p4, p3);
    position_t diffqp = vector__difference(p3, p1); 
    int prodrs = vector__product_plane(vecr, vecs);
    if (vector__is_null(vecr)) {
        if (vector__is_null(vecs)) {
            return vector__is_null(diffqp);
        } else {
            return segment__intersect(p3, p4, p1, p2);
        }
    } else {
        if (prodrs) {
            float t = (float) vector__product_plane(diffqp, vecr) / prodrs;
            float u = (float) vector__product_plane(diffqp, vecs) / prodrs;
            return (coord__in_interval(t, 0, 1) && coord__in_interval(u, 0, 1));
        } else {           
            if (vector__product_plane(diffqp, vecr)) {
                return false;
            } else {
                float dotrr = vector__dot_product(vecr, vecr);
                float dotqpr = vector__dot_product(diffqp, vecr);
                float dotqspr = vector__dot_product(vector__sum(diffqp, vecs), vecr);
                float t0 = dotqpr / dotrr;
                float t1 = dotqspr / dotrr;
                return interval__intersect(t0, t1, 0, 1);
            }
        }
    }
}

bool moving__cross_fix(area_t moving_size, position_t starting_position, position_t ending_position, area_t fix_area, position_t fix_position) {
    starting_position = (position_t) { .x = starting_position.x + moving_size.width / 2, .y = starting_position.y + moving_size.height / 2 };
    ending_position = (position_t) { .x = ending_position.x + moving_size.width / 2, .y = ending_position.y + moving_size.height / 2 };
    
    position_t p1 = fix_position;
    position_t p2 = (position_t) { .x = p1.x + fix_area.width, .y = p1.y };
    position_t p3 = (position_t) { .x = p1.x, .y = p1.y + fix_area.height};
    position_t p4 = (position_t) { .x = p2.x, .y = p3.y };

    bool inside = starting_position.x >= p1.x && starting_position.x <= p4.x \
    && starting_position.y >= p1.y && starting_position.y <= p4.y;

    bool b1 = segment__intersect(starting_position, ending_position, p1, p2);
    bool b2 = segment__intersect(starting_position, ending_position, p2, p3);
    bool b3 = segment__intersect(starting_position, ending_position, p3, p4);
    bool b4 = segment__intersect(starting_position, ending_position, p4, p1);
    return inside || b1 || b2 || b3 || b4;
}

