#include "server-commands.h"
#include "callbacks/aquarium-callbacks.h"
#include "callbacks/server-callbacks.h"
#include "callbacks/default.h"

/**
 * The set of commands that can be called through the command-line interface (server-side).
 */
command_set_t server_command_set = {.nb_commands = 0};


void server_command_set__fill() {
    command__initialize(&server_command_set,
                        "^load (\\S+)$",
                        load_aquarium);
    command__initialize(&server_command_set,
                        "^show aquarium$",
                        show_aquarium);
    command__initialize(&server_command_set,
                        "^add view (\\S+) (\\d+)x(\\d+)\\+(\\d+)\\+(\\d+)$",
                        add_view);
    command__initialize(&server_command_set,
                        "^del view (\\S+)$",
                        del_view);
    command__initialize(&server_command_set,
                        "^save (\\S+)$",
                        save_aquarium);
    command__initialize(&server_command_set,
                        "^log (\\S+)$",
                        set_log_file);
    command__initialize(&server_command_set,
                        "^save (\\S+)$",
                        default_callback);
    command__initialize(&server_command_set,
                        "^shutdown$",
                        shutdown_server);
}

enum command_err_code server_command__exec(char const* input, FILE* out, FILE* err) {
    return command__exec(&server_command_set, input, out, err, NULL);
}

void server_command_set__destroy() {
    command_set__destroy(&server_command_set);
}