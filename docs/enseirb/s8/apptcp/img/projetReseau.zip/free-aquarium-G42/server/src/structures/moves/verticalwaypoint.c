#include "verticalwaypoint.h"

enum ret_stat verticalwaypoint(transition_t* transition) {
    if (transition) {
        transition->destination.y = rand() % 1000;
        transition->time_to_dest = rand() % 50 + 10;
        return OK;
    }
    return ERR_NULL_GIVEN;
}