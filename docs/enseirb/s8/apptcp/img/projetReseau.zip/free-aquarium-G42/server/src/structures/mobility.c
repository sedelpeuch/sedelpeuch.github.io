#include "mobility.h"
#include "transition_private.h"
#include "intersection.h"
#include <stdlib.h>

typedef struct mobility {
    position_t last_destination;
    time_t last_time;
    int time_since;
    int nb_transitions;
    struct transition_queue transitions;
} mobility_t;

mobility_t* mobility__init(position_t position, mob_model_t* mob_model, int nb_transitions) {
    if (!mob_model) return NULL;
    mobility_t* res = malloc(sizeof(mobility_t));
    STAILQ_INIT(&res->transitions);
    res->last_destination = position;
    res->last_time = 0;
    res->time_since = 0;
    res->nb_transitions = nb_transitions;
    int i = 0;
    while (i < nb_transitions) {
        transition_t* tmp = malloc(sizeof(transition_t));
        tmp->destination = position; 
        mob_model__apply(mob_model, tmp);
        STAILQ_INSERT_TAIL(&res->transitions, tmp, next);
        i++;
    }
    return res;   
}

enum ret_stat mobility__end(mobility_t* mobility) {
    if (mobility) {
        transition_t* tmp1 = STAILQ_FIRST(&mobility->transitions);
        while (tmp1) {
            transition_t* tmp2 = tmp1;
            tmp1 = STAILQ_NEXT(tmp2, next);
            free(tmp2);
        }
        free(mobility);
        return OK;
    }
    return ERR_NULL_GIVEN;
}

enum ret_stat mobility__start(mobility_t* mobility, time_t time) {
    if (mobility) {
        mobility->last_time = time;
        return OK;
    }
    return ERR_NULL_GIVEN;
}

position_t mobility__get_destination(const mobility_t* mobility) {
    if (mobility && !STAILQ_EMPTY(&mobility->transitions)) {
        return STAILQ_FIRST(&mobility->transitions)->destination;
    } 
    position_t ret = { .x = -1, .y = -1};
    return ret;
}

int mobility__get_nb_transitions(const mobility_t* mobility) {
    if (!mobility) return -1;
    return mobility->nb_transitions;
}

position_t* mobility__get_all_destinations(const mobility_t* mobility) {
    if (mobility) {
        position_t* res = malloc(sizeof(position_t) * mobility->nb_transitions);
        transition_t* tmp;
        int i = 0;
        tmp = STAILQ_FIRST(&mobility->transitions);
        while (tmp) {
            res[i] = (position_t) { .x = tmp->destination.x, .y = tmp->destination.y }; 
            tmp = STAILQ_NEXT(tmp, next);
            i++;
        }
        return res;
    } 
    return NULL;
} 

int* mobility__get_all_times(const mobility_t* mobility) {
    if (!mobility) return NULL;
    int* res = malloc(sizeof(int) * mobility->nb_transitions);
    transition_t* tmp;
    int i = 0;
    tmp = STAILQ_FIRST(&mobility->transitions);
    while (tmp) {
        if (i == 0) {
            res[i] = tmp->time_to_dest - mobility->time_since;
        } else {
            res[i] = tmp->time_to_dest; 
        }
        tmp = STAILQ_NEXT(tmp, next);
        i++;
    }
    return res;
}
    

int mobility__get_time_to_dest(const mobility_t* mobility) {
    if (mobility && !STAILQ_EMPTY(&mobility->transitions)) {
        return STAILQ_FIRST(&mobility->transitions)->time_to_dest - mobility->time_since;
    } 
    return -1;
}

position_t mobility__get_position(const mobility_t* mobility) {
    if (mobility && !STAILQ_EMPTY(&mobility->transitions)) {
        transition_t* transition = STAILQ_FIRST(&mobility->transitions);
        int x = (transition->destination.x * mobility->time_since + \
        (transition->time_to_dest - mobility->time_since) * mobility->last_destination.x) /  transition->time_to_dest;
        int y = (transition->destination.y * mobility->time_since + \
        (transition->time_to_dest - mobility->time_since) * mobility->last_destination.y) /  transition->time_to_dest;
        return (position_t) { .x = x, .y = y };
    } 
    position_t ret = { .x = -1, .y = -1};
    return ret;
}


enum ret_stat mobility__refresh(mobility_t* mobility, mob_model_t* mob_model, time_t t) {
    if (!mobility) {
        return ERR_NULL_GIVEN;
    }
    transition_t* tmp = STAILQ_FIRST(&mobility->transitions);
    while (t > mobility->last_time + tmp->time_to_dest) {
        mobility->last_destination = tmp->destination;
        mobility->last_time = mobility->last_time + tmp->time_to_dest;
        STAILQ_REMOVE_HEAD(&mobility->transitions, next);
        mob_model__apply(mob_model, tmp);
        STAILQ_INSERT_TAIL(&mobility->transitions, tmp, next);
        tmp = STAILQ_FIRST(&mobility->transitions);
    }
    mobility->time_since = t - mobility->last_time;
    return OK;
}

bool mobility__cross_view(mobility_t* mobility, area_t mobility_size, view_t* view) {
    position_t starting_position, ending_position, fix_position;
    starting_position = mobility->last_destination;
    ending_position = mobility__get_destination(mobility);
    fix_position = view__get_position(view);
    area_t fix_area = view__get_area(view);
    return moving__cross_fix(mobility_size, starting_position, ending_position, fix_area, fix_position);
}


bool mobility__will_cross_view(mobility_t* mobility, area_t mobility_size, view_t* view) {
    position_t starting_position, ending_position, fix_position;
    starting_position = mobility->last_destination;
    fix_position = view__get_position(view);
    area_t fix_area = view__get_area(view);
    transition_t* tmp = STAILQ_FIRST(&mobility->transitions);
        while (tmp) {
            ending_position = (position_t) { .x = tmp->destination.x, .y = tmp->destination.y };
            if (moving__cross_fix(mobility_size, starting_position, ending_position, fix_area, fix_position)) {
                return true;
            }
            tmp = STAILQ_NEXT(tmp, next);
            starting_position = ending_position;
        }
    return false;
}
