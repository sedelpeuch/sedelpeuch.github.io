#ifndef AQUARIUM_SERVER_SERVER_COMMANDS_H
#define AQUARIUM_SERVER_SERVER_COMMANDS_H

#include "command.h"

/**
 * Create every command that can be called through the command-line interface (server-side).
 */
void server_command_set__fill();

/**
 * Parse & execute command `input` if `input` corresponds to a valid server command.
 * @param input The command the user wants to execute.
 * @return CMD_OK, or an error code
 */
enum command_err_code server_command__exec(char const* input, FILE* out, FILE* err);

/**
 * Free the commands of the server command set
 */
void server_command_set__destroy();

#endif //AQUARIUM_SERVER_SERVER_COMMANDS_H
