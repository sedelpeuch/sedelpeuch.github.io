import Goban
import importlib
import time
from io import StringIO
import sys
import datetime
import os

"""
make all player figths N times against each other and wirte results in file FILE
"""

N = 1
FILE = "games_resume.txt"
players = ["alpha_beta", "miniMaxPlayer", "monte_carlo", "randomPlayer"]

def fileorpackage(name):
    if name.endswith(".py"):
        return name[:-3]
    return name

def game(p1, p2):
    b = Goban.Board()

    players = []
    player1class = importlib.import_module(p1)
    player1 = player1class.myPlayer()
    player1.newGame(Goban.Board._BLACK)
    players.append(player1)

    player2class = importlib.import_module(p2)
    player2 = player2class.myPlayer()
    player2.newGame(Goban.Board._WHITE)
    players.append(player2)

    totalTime = [0, 0]  # total real time for each player
    nextplayer = 0
    nextplayercolor = Goban.Board._BLACK
    nbmoves = 1

    outputs = ["", ""]
    sysstdout = sys.stdout
    stringio = StringIO()
    wrongmovefrom = 0

    while not b.is_game_over():
        legals = b.legal_moves()  # legal moves are given as internal (flat) coordinates, not A1, A2, ...
        nbmoves += 1
        otherplayer = (nextplayer + 1) % 2
        othercolor = Goban.Board.flip(nextplayercolor)

        currentTime = time.time()
        sys.stdout = stringio
        move = players[
            nextplayer].getPlayerMove()  # The move must be given by "A1", ... "J8" string coordinates (not as an internal move)
        sys.stdout = sysstdout
        playeroutput = stringio.getvalue()
        stringio.truncate(0)
        stringio.seek(0)
        outputs[nextplayer] += playeroutput
        totalTime[nextplayer] += time.time() - currentTime

        if not Goban.Board.name_to_flat(move) in legals:
            wrongmovefrom = nextplayercolor
            break
        b.push(Goban.Board.name_to_flat(move))  # Here I have to internally flatten the move to be able to check it.
        players[otherplayer].playOpponentMove(move)

        nextplayer = otherplayer
        nextplayercolor = othercolor

    result = b.result()
    if wrongmovefrom > 0:
        if wrongmovefrom == b._WHITE:
            winner = p1
        elif wrongmovefrom == b._BLACK:
            winner = p2
        else:
            winner = "error"
    elif result == "1-0":
        winner = p2 #black won
    elif result == "0-1":
        winner = p1 #white won
    else:
        winner = "draw"
    return (winner, totalTime, b.final_go_score())


def launch_games(players, N, FILE):
    with open(FILE, "a") as f:
        f.write("Lauching figths on {0}\n".format(datetime.date.today().ctime()))
        print("LAUNCHING FIGHTS")
        for p1 in players:
            for p2 in players:
                if p1 != p2:
                    print("[{0} VS {1}]\n".format(p1, p2))
                    f.write("[{0} VS {1}]\n".format(p1, p2))
                    for i in range(N):
                        winner, time, score = game(p1, p2)
                        print("match finished")
                        f.write("match {0} : winner = {1} score = {2} time = {3}\n".format(i+1, winner, score, time))
                        f.flush()
                        os.fsync(f.fileno())

if __name__ == "__main__":
    launch_games(players, N, FILE)