package tec;

final class ArretPoli implements ComportementNouvelArret{
    private static ArretPoli arretPoli = null;

    private ArretPoli(){}

    static ComportementNouvelArret getInstance() {
        if (arretPoli == null) {
            arretPoli = new ArretPoli();
        }
        return arretPoli;
    }

    @Override
    public void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (p.estAssis()
                && !v.aPlaceAssise()
                && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        }
    }
}
