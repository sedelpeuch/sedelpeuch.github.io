package tec;

final class ArretAgoraphobe implements ComportementNouvelArret{
    private static ArretAgoraphobe arretAgoraphobe = null;

    private ArretAgoraphobe(){}

    static ComportementNouvelArret getInstance() {
        if (arretAgoraphobe == null) {
            arretAgoraphobe = new ArretAgoraphobe();
        }
        return arretAgoraphobe;
    }

    @Override
    public void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (!v.aPlaceAssise() && !v.aPlaceDebout()) {
            v.arretDemanderSortie(p);
        }
    }
}