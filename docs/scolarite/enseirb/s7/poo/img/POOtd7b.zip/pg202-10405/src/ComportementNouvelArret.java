package tec;

public interface ComportementNouvelArret {

    /**
     * Modifie la position du Passager selon le comportement à l'arrêt
     * auquel il est associé.
     */
    public void choixPlaceArret(Passager p, Vehicule v, int distanceDestination);
}
