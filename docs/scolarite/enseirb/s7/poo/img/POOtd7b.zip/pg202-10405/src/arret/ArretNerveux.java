package tec;

final class ArretNerveux implements ComportementNouvelArret{
    private static ArretNerveux arretNerveux = null;

    private ArretNerveux(){}

    static ComportementNouvelArret getInstance() {
        if (arretNerveux == null) {
            arretNerveux = new ArretNerveux();
        }
        return arretNerveux;
    }

    @Override
    public void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (p.estDebout() && v.aPlaceAssise()) {
            v.arretDemanderAssis(p);
        } else if (p.estAssis() && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        }
    }
}
