package tec;

final class ArretCalme implements ComportementNouvelArret{
    private static ArretCalme arretCalme = null;

    private ArretCalme(){}

    static ComportementNouvelArret getInstance() {
        if (arretCalme == null) {
            arretCalme = new ArretCalme();
        }
        return arretCalme;
    }

    @Override
    public void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {}
}