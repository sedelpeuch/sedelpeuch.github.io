package tec;

public final class FabriqueTec{

    /*
     * Surcharge le constructeur pour ne pas l'exposer
     */
    private FabriqueTec(){
    }

    /**
     * Fonction créant un Autobus
     */
    public static Transport faireAutobus(int placesAssises, int placesDebout){
        return new Autobus(placesAssises, placesDebout);
    }


    /**
     * Retourne une instance de Passager selon la chaîne de caractères passée en paramètre.
     * @deprecated Depuis la version 6.0a/b, la méthode fairePassager(String type, String nom, int destination)
     * est remplacée par fairePassager(String montee, String arret, String nom, int destination).
     */
    @Deprecated
    public static Usager fairePassager(String type, String nom, int destination)
            throws IllegalArgumentException, CombinaisonInterditeException {
        switch(type) {
            case "PassagerStandard":
                return fairePassager("MonteeRepos", "ArretCalme" , nom, destination);
            case "PassagerStresse":
                return fairePassager("MonteeFatigue", "ArretPrudent", nom, destination);
            case "PassagerIndecis":
                return fairePassager("MonteeSportif", "ArretNerveux", nom, destination);
            default:
                throw new IllegalArgumentException(String.format("Type de passager incorrect. " +
                        "Reçu : \"%s\", Valeurs acceptées : \"PassagerStandard\", \"PassagerIndecis\"," +
                        " \"PassagerStresse\"\n", type));
        }
    }


    /*
     * Retourne une instance de Passager selon la chaîne de caractères passée en
     * paramètre relative à la montée, et celle relative à l'arrêt.
     */
    public static Usager fairePassager(String montee, String arret, String nom, int destination) throws IllegalArgumentException, CombinaisonInterditeException {
        ComportementNouvelArret cna = null;
        String msgFmt = "Comportement non reconnu : {%s}";

        switch(arret) {
            case "ArretCalme":
                cna = ArretCalme.getInstance();
                break;
            case "ArretAgoraphobe":
                cna = ArretAgoraphobe.getInstance();
                break;
            case "ArretNerveux":
                cna = ArretNerveux.getInstance();
                break;
            case "ArretPoli":
                cna = ArretPoli.getInstance();
                break;
            case "ArretPrudent":
                cna = ArretPrudent.getInstance();
                break;
            default:
                throw new IllegalArgumentException(String.format(msgFmt, "ArretCalme, ArretAgoraphobe, ArretNerveux, ArretPoli, ArretPrudent"));
        }

        switch(montee) {
            case "MonteeFatigue":
                return new MonteeFatigue(nom, destination, cna);
            case "MonteeTetu":
                return new MonteeTetu(nom, destination, cna);
            case "MonteeRepos":
                return new MonteeRepos(nom, destination, cna);
            case "MonteeSportif":
                return new MonteeSportif(nom, destination, cna);
            default:
                throw new  IllegalArgumentException(String.format(msgFmt, "MonteeFatigue, MonteeTetu, MonteeRepos, MonteeSportif"));
        }
    }
}
