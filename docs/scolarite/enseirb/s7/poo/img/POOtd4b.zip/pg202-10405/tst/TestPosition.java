package tec;
class TestPosition {

    public static void main (String[] args) {
        boolean estMisAssertion = false;
        assert estMisAssertion = true;

        if (!estMisAssertion) {
            System.out.println("Execution impossible sans l'option -ea");
            return;
        }

        // Lancement des tests

        new TestPosition().testEstAssis();

        new TestPosition().testEstDebout();

        new TestPosition().testEstDehors();

        /* Après la réalisation de ces tests, nous pouvons en conclure que les méthode estDebout() et dehors() sont problématiques.
           La méthode toString() associée à la classe Position révèle que les changements d'états sont pris en compte sauf lorsque le retour
           à l'état dehors est opéré. La méthode dehors() renvoie le même état que debout().
           Les tests réalisés prouvent également que la méthode estDebout() se comporte de la même manière que estAssis(). Par conséquent, elle
           ne vérifie pas le bon état du passager. */

        System.out.println("OK");
    }

    // Constructeur
    TestPosition(){
        System.out.print(".");
    }

    /*private void testEstDehorsInstanciation() {
        Position pos = new Position();
        assert pos.estDehors() : "Devrait être dehors à l'instanciation";
        assert !pos.estAssis() : "Ne devrait pas être assis à l'instanciation !";
        assert !pos.estDebout() : "Ne devrait pas être debout à l'instanciation !";
        assert !pos.estInterieur() : "Ne devrait pas être à l'intérieur à l'instanciation !";
    }*/

    private void testEstAssis() {
        Position pos = Position.ASSIS;
        assert !(pos.estDehors()): "Ne devrait pas être dehors après avoir été mis assis.";
        assert pos.estAssis() : "Devrait être assis après avoir été mis assis";

        // Ce test lève une exception car le passager est considéré comme debout après avoir été mis assis.
        // System.out.println(pos.toString());
        assert !pos.estDebout() : "Ne devrait pas être debout après avoir été mis assis";

        assert pos.estInterieur() : "Devrait être à l'intérieur apès avoir été mis assis";
    }

    private void testEstDebout() {
        Position pos = Position.DEBOUT;
        assert !pos.estDehors() : "Ne devrait pas être dehors après avoir été mis debout.";
        assert !pos.estAssis() : "Ne devrait pas être assis après avoir été mis debout";

        // Ce test lève une exception car le passager n'est pas considéré comme debout après avoir été mis debout
        // System.out.println(pos.toString());
        assert pos.estDebout() : "Devrait être debout après avoir été mis debout";

        assert pos.estInterieur() : "Devrait être à l'intérieur après avoir été mis debout";
    }

    private void testEstDehors() {
        Position pos = Position.DEHORS;

        // On passe en position debout pour tester le retour en position dehors
        pos = pos.debout();
        pos = pos.dehors();

        // Une exception est levée car le passager est considéré dans l'état debout, donc
        // à l'intérieur de l'autobus.
        // System.out.println(pos.toString());
        assert pos.estDehors() : "Devrait être dehors après avoir été mis dehors";
        assert !pos.estInterieur() : "Ne devrait pas être à l'intérieur après avoir été mis dehors !";

        assert !pos.estAssis() : "Ne devrait pas être assis après avoir été mis dehors !";

        // On notera que malgré l'état "debout" renvoyé lorsque le passager se retrouve dehors le test n'échoue pas.
        // Cela est dû à l'erreur de vérification opérée dans la méthode estDebout().
        assert !pos.estDebout() : "Ne devrait pas être debout après avoir été mis dehors !";
    }
}
