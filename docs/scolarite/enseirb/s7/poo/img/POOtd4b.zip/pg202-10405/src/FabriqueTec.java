package tec;

public class FabriqueTec{

  /*
  * Surcharger le constructeur pour ne pas l'exposer
  */
  private FabriqueTec(){
  }

  /*
  * Fonction créant un Autobus
  */
  public static Autobus faireAutobus(int placesAssises, int placesDebout){
    return new Autobus(placesAssises, placesDebout);
  }

  /*
  * Fonction créant un PassagerStandard
  */
  public static PassagerStandard fairePassagerStandard(String nom, int destination){
    return new PassagerStandard(nom, destination);
  }
}
