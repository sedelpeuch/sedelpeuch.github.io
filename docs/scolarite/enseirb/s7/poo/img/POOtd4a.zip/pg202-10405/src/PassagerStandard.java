package tec;

public class PassagerStandard extends Passager implements Usager{
    private String nom;
    private int destination;
    private Position position;
    
    public PassagerStandard(String nom, int destination){
        this.nom = nom;
        this.destination = destination;
        this.position = Position.DEHORS;
    }

    @Override
     String nom(){
        return this.nom();
    }

    @Override
     boolean estDehors(){
        return position.estDehors();
    }

    @Override
     boolean estAssis(){
        return position.estAssis();
    }

    @Override
     boolean estDebout(){
        return position.estDebout();
    }

    @Override
     void changerEnDehors(){
        position = position.dehors();
    }

    @Override
     void changerEnAssis(){
        position = position.assis();
    }

    @Override
     void changerEnDebout(){
        position = position.debout();
    }

    @Override
     public void monterDans(Transport v){
        Vehicule b = (Vehicule) v;
        if(b.aPlaceAssise()) {
            b.monteeDemanderAssis(this);
        } else if(b.aPlaceDebout()) {
            b.monteeDemanderDebout(this);
        }
    }

    @Override
     void nouvelArret(Vehicule v, int numeroArret){
        if(destination <= numeroArret) {
            v.arretDemanderSortie(this);
        }
    }

    @Override
    public String toString(){
        return this.nom + " " + position.toString();
    }

}

