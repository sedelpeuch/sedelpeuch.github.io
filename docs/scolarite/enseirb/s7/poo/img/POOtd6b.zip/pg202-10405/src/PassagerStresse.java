package tec;

class PassagerStresse extends PassagerAbstrait{

    public PassagerStresse(String nom, int destination) {
        super(nom, destination);
    }

    @Override
    public void choixPlaceMontee(Vehicule v) {
        if(v.aPlaceAssise()) {
            v.monteeDemanderAssis(this);
        } else if(v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }

    @Override
    public void choixPlaceArret(Vehicule v, int arret) {
        if(getDestination(arret) <= 3
                && estAssis()
                && v.aPlaceDebout()) {
            v.arretDemanderDebout(this);
        }
    }

    @Override
    public String toString(){
        return "[p. stressé] " + super.toString();
    }
}
