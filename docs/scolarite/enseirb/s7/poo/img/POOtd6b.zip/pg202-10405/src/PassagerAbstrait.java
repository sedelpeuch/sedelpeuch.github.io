package tec;

abstract class PassagerAbstrait implements Passager, Usager{
    private String nom;
    private final int destination;
    private Position position;

    public PassagerAbstrait(String nom, int destination){
        this.nom = nom;
        this.destination = destination;
        this.position = Position.creer();
    }

    final protected int getDestination(int arretCourant) {
        return destination - arretCourant;
    }

    @Override
    final public String nom(){
        return this.nom();
    }

    @Override
    final public boolean estDehors(){
        return position.estDehors();
    }

    @Override
    final public boolean estAssis(){
        return position.estAssis();
    }

    @Override
    final public boolean estDebout(){
        return position.estDebout();
    }

    @Override
    final public void changerEnDehors(){
        position = position.dehors();
    }

    @Override
    final public void changerEnAssis(){
        position = position.assis();
    }

    @Override
    final public void changerEnDebout(){
        position = position.debout();
    }

    @Override
    final public void monterDans(Transport v){
        Vehicule b = (Vehicule) v;
        choixPlaceMontee(b);
    }

    @Override
    final public void nouvelArret(Vehicule v, int numeroArret){
        if(destination <= numeroArret) {
            v.arretDemanderSortie(this);
        } else {
            choixPlaceArret(v, numeroArret);
        }
    }

    @Override
    public String toString(){
        return this.nom + " " + position.toString();
    }

    protected abstract void choixPlaceMontee(Vehicule v);

    protected abstract void choixPlaceArret(Vehicule v, int arret);

}
