package tec;

class PassagerStandard extends PassagerAbstrait {

    public PassagerStandard(String nom, int destination) {
        super(nom, destination);
    }

    @Override
    protected void choixPlaceMontee(Vehicule v) {
        if(v.aPlaceAssise()) {
            v.monteeDemanderAssis(this);
        } else if(v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }

    @Override
    protected void choixPlaceArret(Vehicule v, int arret) {}

    @Override
    public String toString(){
        return "[p. standard] " + super.toString();
    }
}
