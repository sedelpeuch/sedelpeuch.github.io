# @package corona
#  Documentation for this module.

import numpy as np
import networkx
import matplotlib.pyplot as plt
import random
import sys
import time


sain = "green"
malade = "red"
remis = "blue"
decede = "black"

## La class qui represente un individu de la population
class individu:

    ## Constructeur d'un individu
    #@param num : le numéro de l'individu dans la population
    #@param etat : l'état de l'individu. 0 = sain, 1 = malade, 2 = gueris, 3 = decedé
    #@param duree_infection : depuis quand l'individu est infécté. 0 si individu sain
    #@param nb_freq : nombre de frequentation de l'individu
    #@param tab_voisins : tableau avec les numeros de ses voisins
    def __init__(self, num, etat, duree_infection, nb_freq, r, duree_confinement):
        self.etat = etat
        self.num = num
        self.duree_infection = duree_infection
        self.nb_freq = nb_freq
        self.tab_voisins = []
        self.tab_voisins_confine = []
        self.confine = 0
        self.tab_voisin_j = r*[[]]
        self.duree_confinement = duree_confinement

## Fonction qui crée un graphe circulaire
#@param n : nombre d'individus dans la population
#@return la matrice d'adjacence du graph crée
def create_circular(n, population):
    matrice_adja = np.zeros((n, n))
    for i in range (n):
        matrice_adja[i][(i-1)%n] = 1
        matrice_adja[i][(i+1)%n] = 1
        population[i].tab_voisins+=[(i-1)%n, (i+1)%n]
    return(matrice_adja, population)

## Fonction qui crée un graph aléatoire
#@param n : nombre d'individus dans la population
#@param k : nombre minimal de fréquentation de chaque individu. (En moyenne chaque individu aura 2k frequentations)
#@return la matrice d'adjacence du graph crée
def create_random(n, k, population):
    matrice_adja = np.zeros((n, n))
    for i in range(n):
        print('creation du graphe... {0}%'.format((i*100)/n), end="\r")
        liste_voisin = list(range(n)) #liste possible des voisins
        for j in range(k):
            choice = random.choice(liste_voisin) #choisis aleatoirement un voisin dans la liste
            while choice == i:
                choice = random.choice(liste_voisin)
            liste_voisin.pop(liste_voisin.index(choice)) #retire de la liste le voisin choisis (evite qu'il ne le retire)
            matrice_adja[i][choice] = 1
            matrice_adja[choice][i] = 1
            population[i].tab_voisins+=[choice]
            population[choice].tab_voisins+=[i]
    print('\nGRAPHE CREE !')
    return matrice_adja, population

## Permet de créer un graphe mixte
#@param n: le nombre de sommets du graphe à créer
#@param k: le nombre maximal de contact d'un individu
#@return la matrice d'adjacence du graphe
def create_random_circular(n, k, popu):
    matrice_adja = np.zeros((n, n))
    new_popu = n*[0]
    matrix_adj_circular, popu_circ = create_circular(n, popu)
    matrix_adj_random, popu_random = create_random(n, k, popu)
    for i in range(n):
        for j in range(n):
            if (matrix_adj_circular[i][j] == 1 or matrix_adj_random[i][j] == 1):
                matrice_adja[i][j] = 1
    for i in range(len(popu_circ)):
        popu_circ[i].tab_voisins = Union(popu_circ[i].tab_voisins, popu_random[i].tab_voisins)

    return matrice_adja, popu_circ

##Retourne le nombre moyen de voisins dans le graphe. A fin de debug.
#@param adja : une ligne d'une matrice d'adjacence
#@param n : taille de la ligne
#@return la moyenne
def moyenne_voisin(adja, n):
    total = 0
    for i in range(n):
        total += list(adja[i]).count(1) #compte les 1 dans la ligne.
    return total/n

def Union(lst1, lst2):
    final_list = list(set(lst1) | set(lst2))
    return final_list

##Retourne l'indice du ie voisins du sommet i
#@param liste_adja : une ligne d'une matrice d'adja
#@param i : numéro de voisin
#@param n : taille de la liste
#@return indice du ie voisin
def indice_ie_freq(liste_adja, i, n):
    cpt = 0
    for indice in range(n):
        if liste_adja[indice] == 1:
            cpt += 1
        if cpt == i:
            return indice
    return -1

##Copie le tableau de voisignage d'un individu
#@param personne: l'individu à copier
#@return l'individu copié
def copy_tab_voisin(personne):
    copy = []
    for voisin in personne.tab_voisins:
        copy += [voisin]
    return copy


## Confine la population passée en paramètre, en autorisant chaque personne à ne voir que k_prim personnes parmis ces anciens contacts
#@param n: nombre de sommet
#@param k_prim: le nombre de voisins que l'individu à le droit de voir parmis ses k connaissances
#@param k: nombre de connaissance maximale d'un individu
#@param matrice_adja: matrice d'adjacence du graphe
#param popu: liste des n individus
#@return la nouvelle matrice d'adjacence
#@return la population actualisée
def confinement(n, k_prim, k, matrice_adja, popu):
    # new_popu = copy_popu_sans_voisin(popu, n)
    # new_popu = population(n)
    new_adja = np.zeros((n,n))
    for i in range(n):
        liste_frequentation = copy_tab_voisin(popu[i])
        for j in range(k_prim):
            choice = random.choice(liste_frequentation) #choisis dans la liste
            while choice == i:
                choice = random.choice(liste_frequentation)
            liste_frequentation.pop(liste_frequentation.index(choice)) #retire le contact precedemment choisi
            # sommet_associe = indice_ie_freq(matrice_adja[i], choice, n) #retourne le num d'individu associé à ce contact
            new_adja[i][choice] = 1
            new_adja[choice][i] = 1
            popu[i].tab_voisins_confine+=[choice]
            popu[i].nb_freq += 1
            popu[choice].tab_voisins_confine+=[i]
            popu[choice].nb_freq += 1
    return new_adja, popu

## Crée une population de taille n
#@param n: nombre d'individus à créer
#@param r: nombre de jour qu'un individu est malade
#@return une population
def population(n, r):
    popu = []
    for i in range(n):
        popu += [individu(i, 0, 0, 0, r, 0)]
    return popu

def copy_popu_sans_voisin(popu, n):
    copy = popu
    for i in range(n):
        copy[i].tab_voisins = []
    return copy

## Infecte aléatoirement un individu de la population
#@param population: la population du graphe
#@param n: le nombre d'individus
#@return la population avec le premier infecté
def patient_0(population, n):
    choice = random.randint(0,n-1)
    population[choice].etat = 1
    return population

## Booléen avec probabilité d'etre True de proba
#@param proba: la probabilité du choix
#@return un booléen nous indiquant si le tirage est vrai ou faux
def tirage(proba):
    res = random.random()
    return res <= proba

## Permet de décaler le tableau qui contient l'historique des connexions
#@param tab_voisin_jour: le tableau à décaler
#@param r: le nombre de jour que dure la maladie
#@return le tableau actualisé
def decalage_tab_voisin_jour(tab_voisin_jour, r):
    for i in range(r-1):
        tab_voisin_jour[i+1] = tab_voisin_jour[i]
    return tab_voisin_jour

## Permet d'ajouter de nouveaux voisins dans le tableau contenant les voisins
#@param tab_voisin_jour: le tableau où il faut ajouter les voisins
#@param tab_voisin: le tableau contenant les voisins à ajouter
#@return le tableau actualisé
def ajout_nouveaux_voisin(tab_voisin_jour, tab_voisin):
    tab_voisin_jour[0] = tab_voisin
    return tab_voisin_jour


## Retourne la population au jour n+1
#@param matrice_adja: la matrice d'adjacence du graphe
#@param population: l'ensemble des individus
#@param n: le nombre de sommets du graphe
#@param p,q,r: les paramètres du sujet
#@param nb_malade: le nombre de malades dans le graphe
#@return la matrice d'ajacence du nouveau graphe et sa population
def propagation_jour(matrice_adja, population, n, p, q, r, nb_malade):
    kp = 25
    for i in range(n):
        population[i].tab_voisin_j = decalage_tab_voisin_jour(population[i].tab_voisin_j, r)
        population[i].tab_voisin_j = ajout_nouveaux_voisin(population[i].tab_voisin_j, population[i].tab_voisins_confine)
        if population[i].etat == 1:
            if population[i].duree_infection > r:
                if tirage(p):
                    population[i].etat = 3

                    """
                    for liste_voisin in population[i].tab_voisin_j:
                        population_sample_d = random.sample(range(0,25), 15)
                        #for voisin in liste_voisin:
                        for j in range(15):
                            
                            if(test_est_malade(population[population_sample_d[j]])):
                               population[population_sample_d[j]].confine = 1
                               matrice_adja[i] = 0
                               matrice_adja[j] = 0
                    """
                    
                else:
                    population[i].etat = 2
            elif population[i].confine == 0:
                for voisin in population[i].tab_voisins_confine:
                    if tirage(q) and population[voisin].etat == 0 and population[voisin].confine == 0:
                        population[voisin].etat = 1

    #Vérifie que le confinement est terminé
    for i in range(n):
        if(population[i].confine == 1):
            population[i].duree_confinement += 1
            if(population[i].duree_confinement >= r):
                population[i].confine = 0
                population[i].duree_confinement = 0
                for liste_voisin in population[i].tab_voisin_j:
                    for voisin in liste_voisin:
                        matrice_adja[i][voisin] = 1
                        matrice_adja[voisin][i] = 1
                

    #if(2*nb_malade < n):
     #   nb_malade = 2 * nb_malade
    #else:
     #   nb_malade = n-1
     
    nb_malade = len(population)
    population_sample = random.sample(range(0,n-1), int(nb_malade/4))

    for i in range(int(nb_malade/4)):
        if(test_est_malade(population[population_sample[i]]) and population[population_sample[i]].etat != 2):
            population[population_sample[i]].confine = 1
            for liste_voisin in population[i].tab_voisin_j:
                population_sample_d = random.sample(range(0,25), 15)
                for j in range(15):
                    if(test_est_malade(population[population_sample_d[j]])):
                        matrice_adja[i] = 0
                        matrice_adja[j] = 0
        
        
    for i in range(n):
        if population[i].etat == 1:
            population[i].duree_infection += 1
    return matrice_adja, population

## Simule la propagation du virus jusqu'à ce qu'il n'y ait plus de malades, pendant 6 mois max
#@param matrice_adja: la matrice d'adjacence du graphe
#@param population: l'ensemble des individus
#@param n: le nombre de sommets du graphe
#@param p,q,r: les paramètres du sujet
#@param type_confi: le type du confinement appliqué
#@return la matrice d'ajacence du nouveau graphe et sa population
def propagation(matrice_adja, population, n, p, q, r, type_confi):
    jour = 0
    tab_malades = [1]
    tab_sains = [n-1]
    tab_gueris = [0]
    tab_decede = [0]
    while(jour < 180):
        if type_confi == 'dynamique':
            # st = time.time()
            matrice_adja, population = confinement(n, k_prim, k, matrice_adja, population)
            # print("confi = ", -st + time.time())

        print("simualation du jour {0}/180".format(jour), end="\r")
        jour += 1
        # st = time.time()
        matrice_adja, population = propagation_jour(matrice_adja, population, n, p, q, r, tab_malades[jour-1])
        # print("propa_j = ", time.time() - st)
        color, nb_sains, nb_malades, nb_gueris, nb_deces = vertice_color(population, n)

        # tableau pour plot les courbes
        tab_malades += [nb_malades]
        tab_sains += [nb_sains]
        tab_gueris += [nb_gueris]
        tab_decede += [nb_deces]

        if gif == 1:
            #sauvegarde de la population au jour j sous forme de graph. Nom du fichier : jour_j.png
            g = networkx.convert_matrix.from_numpy_matrix(matrice_adja)
            name = "jour {0}".format(jour)
            networkx.draw_circular(g, with_labels=True, node_color = color)
            plt.text(-1,0.99, name, fontsize="medium")
            plt.text(-1, 0.9, "sain", backgroundcolor=sain)
            plt.text(-1, 0.8, "malade", backgroundcolor=malade)
            plt.text(-1, 0.7, "gueris", backgroundcolor=remis)
            plt.text(-1, 0.6, "decede", backgroundcolor=decede, color="white")
            plt.savefig("jour_{0}".format(jour))
            plt.clf()

    #plot les courbes
    plt.plot(tab_malades, c=malade, label='nombre malades')
    plt.plot(tab_gueris, c=remis, label='nombre gueris')
    plt.plot(tab_sains, c=sain, label='nombre jamais infectés')
    plt.plot(tab_decede, c=decede, label='nombre decedés')
    plt.legend()
    plt.savefig("courbe_propa_{0}".format(k_prim))
    print("Courbes sauvegardées sous : courbe_propa_{0}".format(k_prim))
    plt.clf()
    print("\n")
    return population

## Tableau avec les couleurs de chaque sommets + nombre de sains, malades, gueris, deces
#@param population: liste des individus
#@param n: nombre de sommets
#àreturn les informations sur le nombre de chaque catégories
def vertice_color(population, n):
    color = n*[sain]
    nb_sains, nb_malades, nb_gueris, nb_deces = (0,0,0,0)
    for i in range(n):
        if population[i].etat == 1:
            color[i] = malade
            nb_malades += 1
        elif population[i].etat == 2:
            color[i] = remis
            nb_gueris += 1
        elif population[i].etat == 3:
            color[i] = decede
            nb_deces += 1
    return color, n - nb_malades - nb_gueris - nb_deces, nb_malades, nb_gueris-nb_deces, nb_deces

def verifyer(popu, popu_confine, n):
    for i in range(n):
        if popu_confine[i][j] == 1 and popu[i][j] == 0:
            for j in range(n):
                print("ERROR !")
                return
    print("OK")

## Permet de simuler un test sur l'invidu
#@param individu: l'individu à tester
#@return si l'individu est malade, vrai avec 70% de chance
#@return sinon vrai avec 10% de chance
def test_est_malade(individu):
    if individu.etat == 1:
        return tirage(0.7)
    elif individu.etat == 0:
        return tirage(0.1)
    

def simulation(n, k, k_prim, r, p, q):
    print("Taille de la population : {taille} individus\n".format(taille = n))
    popu_depart = population(n, r)
    (graph_popu, popu) = create_random_circular(n, k, popu_depart)
    # print("la moyenne devrait etre ~= {0}. Elle est de {1}".format(2*k, moyenne_voisin(graph_popu, n)))

    graph_popu_confine, popu_confine = confinement(n, k_prim, k, graph_popu, popu)
    # print("la moyenne devrait etre ~= {0}. Elle est de {1}".format(2*k_prim, moyenne_voisin(graph_popu_confine, n)))
    popu_confine_malade = patient_0(popu_confine,n)
    propagation(graph_popu_confine, popu_confine_malade, n, p, q, r, 'statique')

n = 10000 #nombre d'individu
k = 50 #nombre de copains au départ
k_prim = 25 #nombre de copains apres application du confinement
r = 5 #duree de la maladie
p = 0.2 #probabilité de décès
q = 0.02 #probabilité d'attrapé la maladie
j = 0
gif = 0

simulation(n, k, k_prim, r, p, q)
# if '-gif' in sys.argv:
#     gif = 1 #booléen global pour savoir si des images pour un gif doivent etre générées

# for r in range(1, 40):
#     simulation(n, k, k_prim, r, p, q)
