#!/usr/bin/env python

from __future__ import print_function
import matplotlib.pyplot as plt
from math import *
from random import *

## Classe contenant les fonctions de l'Astart
class AStarGraph(object):

    ##Initialise la liste des obstacles
    def __init__(self):
        self.obstacles = []
        # for i in range (0,300):
        #     for j in range (0,200):
        #         if randint(0,20)==1:
        #             self.obstacles.append([(i,j)])
        for i in range(140,170):
            self.obstacles.append([(10,i)])
        for i in range(10,40):
            self.obstacles.append([(i,170)])
        for i in range(10,40):
            self.obstacles.append([(i,140)])

        for i in range(10,40):
            self.obstacles.append([(10,i)])
        for i in range(10,40):
            self.obstacles.append([(i,40)])
        for i in range(10,40):
            self.obstacles.append([(i,10)])

        for i in range(90,170):
            self.obstacles.append([(280,i)])
        for i in range(210,280):
            self.obstacles.append([(i,90)])
        for i in range(210,280):
            self.obstacles.append([(i,170)])

        for i in range(140,170):
            self.obstacles.append([(10,i)])
        for i in range(10,30):
            self.obstacles.append([(i,170)])
        for i in range(10,30):
            self.obstacles.append([(i,140)])



    ##Définition de l'heuristique utilisée (euclidienne)
    def heuristic(self, start, goal):
        dx = (abs(start[0] - goal[0]))**2
        dy = (abs(start[1] - goal[1]))**2
        return sqrt(dx+dy)


    ##Obtient les voisins d'un point (ie tous les carrés autour)
    def get_vertex_neighbours(self, pos):
        n = []
        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,1),(1,-1),(-1,-1)]:
            x2 = pos[0] + dx
            y2 = pos[1] + dy
            if x2 < 0 or x2 > 300 or y2 < 0 or y2 > 200:
                continue
            n.append((x2, y2))
        return n

    ##Permet de retrouver le cout d'un mouvement, si c'est un obstacle le cout
    ##est infini. Si on a un graphe pondéré ça permet de le changer ici
    def move_cost(self, a, b):
        for obstacle in self.obstacles:
            if b in obstacle:
                return float('inf')
        return 1


##Permet d'effectuer une recherche avec l'Astar
#@param start: le point d'entré
#@param end: le point de sortie
#@param graph: le graphe représentant le monde
#@return le chemin trouvé
def AStarSearch(start, end, graph):

    G = {} #Cout entre le point de départ et le point actuel
    F = {} #Cout total passant pas le point, on utilise pas H car F=H+G

    if end[0]>300:
        end=(300,end[1])
    if end[0]<0:
        end=(0,end[1])
    if end[1]>200:
        end=(end[0],200)
    if end[1]<0:
        end=(end[0],0)

    G[start] = 0
    F[start] = graph.heuristic(start, end)

    closedVertices = set() #closed list
    openVertices = set([start]) #open list
    cameFrom = {} #parent

    while len(openVertices) > 0:
        current = None
        currentFscore = None
        for pos in openVertices:
            if current is None or F[pos] < currentFscore:
                currentFscore = F[pos]
                current = pos

        if current == end:
            path = [current]
            while current in cameFrom:
                current = cameFrom[current]
                path.append(current)
            path.reverse()
            return path, F[end]

        openVertices.remove(current)
        closedVertices.add(current)

        for neighbour in graph.get_vertex_neighbours(current):
            if neighbour in closedVertices:
                continue
            candidateG = G[current] + graph.move_cost(current, neighbour)

            if neighbour not in openVertices:
                openVertices.add(neighbour)
            elif candidateG >= G[neighbour]:
                continue

            cameFrom[neighbour] = current
            G[neighbour] = candidateG
            H = graph.heuristic(neighbour, end)
            F[neighbour] = G[neighbour] + H

## Permet de savoir si un individu est proche d'un autre
def collide(x,y,x2,y2):
    if x<x2+3 and x+3>x2 and y<y2+3 and 3+y>y2:
        return 1
    return 0


if __name__=="__main__":
    graph = AStarGraph()

    x=-20
    y=20
    nbr_infection=0
    
    result=[]
    result1, cost = AStarSearch((20,20), (20+randint(x,y),20+randint(x,y)), graph)
    plt.plot([v[0] for v in result1], [v[1] for v in result1])
    result.append(result1)

    result2, cost= AStarSearch((20,100), (20+randint(x,y),100+randint(x,y)),graph)
    plt.plot([v[0] for v in result2], [v[1] for v in result2])
    result.append(result2)

    result3, cost = AStarSearch((20,180), (20+randint(x,y),180+randint(x,y)), graph)
    plt.plot([v[0] for v in result3], [v[1] for v in result3])
    result.append(result3)

    result4, cost = AStarSearch((60,60), (60+randint(x,y),60+randint(x,y)), graph)
    plt.plot([v[0] for v in result4], [v[1] for v in result4])
    result.append(result4)

    result5, cost = AStarSearch((60,140), (60+randint(x,y),140+randint(x,y)), graph)
    plt.plot([v[0] for v in result5], [v[1] for v in result5])
    result.append(result5)

    result6, cost = AStarSearch((100,20), (100+randint(x,y),20+randint(x,y)), graph)
    plt.plot([v[0] for v in result6], [v[1] for v in result6])
    result.append(result6)

    result7, cost = AStarSearch((100,100), (100+randint(x,y),100+randint(x,y)), graph)
    plt.plot([v[0] for v in result7], [v[1] for v in result7])
    result.append(result7)

    result8, cost = AStarSearch((100,180), (100+randint(x,y),180+randint(x,y)), graph)
    plt.plot([v[0] for v in result8], [v[1] for v in result8])
    result.append(result8)

    result9, cost = AStarSearch((140,60), (140+randint(x,y),60+randint(x,y)), graph)
    plt.plot([v[0] for v in result9], [v[1] for v in result9])
    result.append(result9)

    result10, cost = AStarSearch((140,140), (140+randint(x,y),140+randint(x,y)), graph)
    plt.plot([v[0] for v in result10], [v[1] for v in result10])
    result.append(result10)

    result11, cost = AStarSearch((180,20), (180+randint(x,y),20+randint(x,y)), graph)
    plt.plot([v[0] for v in result11], [v[1] for v in result11])
    result.append(result11)

    result12, cost = AStarSearch((180,100), (180+randint(x,y),100+randint(x,y)), graph)
    plt.plot([v[0] for v in result12], [v[1] for v in result12])
    result.append(result12)

    result13, cost = AStarSearch((180,180), (180+randint(x,y),180+randint(x,y)), graph)
    plt.plot([v[0] for v in result13], [v[1] for v in result13])
    result.append(result13)

    result14, cost = AStarSearch((220,60), (220+randint(x,y),60+randint(x,y)), graph)
    plt.plot([v[0] for v in result14], [v[1] for v in result14])
    result.append(result14)

    result15, cost = AStarSearch((220,140), (220+randint(x,y),140+randint(x,y)), graph)
    plt.plot([v[0] for v in result15], [v[1] for v in result15])
    result.append(result15)

    result16, cost = AStarSearch((260,20), (260+randint(x,y),20+randint(x,y)), graph)
    plt.plot([v[0] for v in result16], [v[1] for v in result16])
    result.append(result16)

    result17, cost = AStarSearch((260,100), (260+randint(x,y),100+randint(x,y)), graph)
    plt.plot([v[0] for v in result17], [v[1] for v in result17])
    result.append(result17)

    result18, cost = AStarSearch((260,180), (260+randint(x,y),180+randint(x,y)), graph)
    plt.plot([v[0] for v in result18], [v[1] for v in result18])
    result.append(result18)

    potentiel=[]
    infection=[]
    for i in result:
        for j in result:
            if i!=j:
                for k in i:
                    for l in j:
                        if collide(k[0],k[1],l[0],l[1])==1:
                            if randint(0,100)==1 or randint(0,100)==2:
                                infection.append(k)
                                infection.append(l)
                                nbr_infection+=2
                            else:
                                potentiel.append(k)
                                potentiel.append(l)

    plt.scatter([v[0] for v in potentiel],[v[1] for v in potentiel],color='gray',s=7)
    plt.scatter([v[0] for v in infection],[v[1] for v in infection],color='red',s=10)

    plt.xlim(-1,300)
    plt.ylim(-1,200)
    plt.show()
