# The MIT License (MIT)
#
# Copyright (c) 2015 Qihoo 360 Technology Co., Ltd. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

MESSAGE(STATUS "Using bundled Findlibpcre2.cmake...")
FIND_PATH(
        LIBPCRE2_INCLUDE_DIR
        pcre2.h
        /usr/include/
        /usr/local/include
        /usr/local/include/pcre2
        /usr/local/opt/pcre2/include/pcre2
        /usr/lib64/
        /usr/lib/
        /usr/bin/
        /lib64
)

FIND_LIBRARY(
        LIBPCRE2_LIBRARIES NAMES libpcre2-8.a libpcre2-8.so pcre2
        PATHS /usr/lib /usr/local/lib /usr/local/opt/pcre2/lib /usr/lib64 /lib64/ /lib/
)