add_library(structures STATIC
    aquarium.c
    fish.c
    hash/hash_fish.c
    hash/hash_mob_model.c
    hash/hash_view.c
    dic_mob_model.c
    mob_model.c
    mobility.c
    view.c
    intersection.c
    moves/randomwaypoint.c
    moves/horizontalwaypoint.c
    moves/verticalwaypoint.c)