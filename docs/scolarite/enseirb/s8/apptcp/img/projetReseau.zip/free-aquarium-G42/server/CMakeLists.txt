cmake_minimum_required(VERSION 3.12)
project(aquarium_server C)

set(CMAKE_C_STANDARD 99)
set(CMAKE_MODULE_PATH ${PROJECT_SOURCE_DIR}/modules)


# PCRE2 (regex)
find_package(libpcre2 REQUIRED)
mark_as_advanced(
        LIBPCRE2_INCLUDE_DIR
        LIBPCRE2_LIBRARIES
)
if (LIBPCRE2_INCLUDE_DIR AND LIBPCRE2_LIBRARIES)
    message(STATUS "Found libpcre2 libraries")
    include_directories(${LIBPCRE2_INCLUDE_DIR})
    message(${LIBPCRE2_LIBRARIES})
    message(${LIBPCRE2_INCLUDE_DIR})
else (LIBPCRE2_INCLUDE_DIR AND LIBPCRE2_LIBRARIES)
    message(FATAL_ERROR "Failed to find libpcre2 libraries")
endif (LIBPCRE2_INCLUDE_DIR AND LIBPCRE2_LIBRARIES)


add_subdirectory(src)

# Installation
install(TARGETS server
        RUNTIME DESTINATION ${PROJECT_SOURCE_DIR}/install)

# Copy config files
install(FILES
        config-samples/controller.cfg
        config-samples/topologies/a.aqua
        config-samples/topologies/b.aqua
        DESTINATION ${PROJECT_SOURCE_DIR}/install)