# CMake generated Testfile for 
# Source directory: /home/sedelpeuch/ENSEIRB-MATMECA/8/free-aquarium-G42/server
# Build directory: /home/sedelpeuch/ENSEIRB-MATMECA/8/free-aquarium-G42/server/cmake-build-debug
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("src")
subdirs("tests")
