add_library(commands STATIC
        prompt.c
        command.c
        client-commands.c
        server-commands.c
        callbacks/default.c
        callbacks/aquarium-callbacks.c
        aquarium-file-parser.c
        internal-error.c
        callbacks/fish-callbacks.c
        callbacks/authentication-callbacks.c
        callbacks/server-callbacks.c)


target_link_libraries(commands
        ${LIBPCRE2_LIBRARIES}
        structures
        log
        globals
        parser)