file(REMOVE_RECURSE
  "CMakeFiles/globals.dir/globals.c.o"
  "libglobals.a"
  "libglobals.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/globals.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
