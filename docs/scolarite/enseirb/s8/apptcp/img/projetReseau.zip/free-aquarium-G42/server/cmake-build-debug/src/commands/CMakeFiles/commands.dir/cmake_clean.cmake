file(REMOVE_RECURSE
  "CMakeFiles/commands.dir/aquarium-file-parser.c.o"
  "CMakeFiles/commands.dir/callbacks/aquarium-callbacks.c.o"
  "CMakeFiles/commands.dir/callbacks/authentication-callbacks.c.o"
  "CMakeFiles/commands.dir/callbacks/default.c.o"
  "CMakeFiles/commands.dir/callbacks/fish-callbacks.c.o"
  "CMakeFiles/commands.dir/callbacks/server-callbacks.c.o"
  "CMakeFiles/commands.dir/client-commands.c.o"
  "CMakeFiles/commands.dir/command.c.o"
  "CMakeFiles/commands.dir/internal-error.c.o"
  "CMakeFiles/commands.dir/prompt.c.o"
  "CMakeFiles/commands.dir/server-commands.c.o"
  "libcommands.a"
  "libcommands.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/commands.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
