add_library(log STATIC
        log.c)