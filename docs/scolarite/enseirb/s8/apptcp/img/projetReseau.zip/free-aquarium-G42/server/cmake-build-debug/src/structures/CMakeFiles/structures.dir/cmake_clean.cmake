file(REMOVE_RECURSE
  "CMakeFiles/structures.dir/aquarium.c.o"
  "CMakeFiles/structures.dir/dic_mob_model.c.o"
  "CMakeFiles/structures.dir/fish.c.o"
  "CMakeFiles/structures.dir/hash/hash_fish.c.o"
  "CMakeFiles/structures.dir/hash/hash_mob_model.c.o"
  "CMakeFiles/structures.dir/hash/hash_view.c.o"
  "CMakeFiles/structures.dir/intersection.c.o"
  "CMakeFiles/structures.dir/mob_model.c.o"
  "CMakeFiles/structures.dir/mobility.c.o"
  "CMakeFiles/structures.dir/moves/horizontalwaypoint.c.o"
  "CMakeFiles/structures.dir/moves/randomwaypoint.c.o"
  "CMakeFiles/structures.dir/moves/verticalwaypoint.c.o"
  "CMakeFiles/structures.dir/view.c.o"
  "libstructures.a"
  "libstructures.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/structures.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
