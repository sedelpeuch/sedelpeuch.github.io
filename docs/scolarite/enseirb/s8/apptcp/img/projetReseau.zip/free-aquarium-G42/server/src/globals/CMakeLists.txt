add_library(globals STATIC
        globals.c
        globals.h)
