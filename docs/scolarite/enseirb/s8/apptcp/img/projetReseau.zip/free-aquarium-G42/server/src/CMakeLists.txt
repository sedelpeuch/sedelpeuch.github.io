add_executable(server main.c
        config/config-file-parser.c
        config/config-file-parser.h)

add_subdirectory(regex-compiler)
add_subdirectory(globals)
add_subdirectory(structures)
add_subdirectory(commands)
add_subdirectory(log)

# thpool
add_library(threadpool STATIC
        threadpool/thpool.c
        threadpool/thpool.h)

# pthread & thread pool
set(THREADS_PREFER_PTHREAD_FLAG ON)
find_package(Threads REQUIRED)
target_link_libraries(server PRIVATE
        Threads::Threads
        structures
        commands
        globals
        threadpool
        log
        ${LIBPCRE2_LIBRARIES})