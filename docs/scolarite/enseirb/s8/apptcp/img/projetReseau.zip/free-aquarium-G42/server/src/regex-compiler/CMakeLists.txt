add_library(parser STATIC
        regex-compiler.c)


target_link_libraries(parser
        ${LIBPCRE2_LIBRARIES}
        log)