add_library(config STATIC
        config-file-parser.c)


target_link_libraries(config
        ${LIBPCRE2_LIBRARIES}
        log
        globals)