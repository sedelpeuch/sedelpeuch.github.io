#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "utils.h"

int main(int argc, char *argv[]) {
    int rc = 0 , i=0;
    int fd = open(argv[1], O_WRONLY|O_CREAT,S_IRUSR|S_IWUSR);
    exit_if(fd < 0, "open");
    for (i=2; i<argc; i++) {
        rc = write(fd, argv[i], strlen(argv[i]));
        exit_if(rc != strlen(argv[i]),"write");

        rc = write(fd, "\n", 1);
        exit_if(rc != 1, "write newline");
    }
#if 0
    close(fd);
    rc = execvp(argv[2], &argv[2]);
    exit_if(rc == -1, "execvp");

#else
    pid_t pid = fork();
    exit_if(pid == -1, "fork");
    if (pid==0) {
        rc = dup2(fd,STDOUT_FILENO);
        exit_if(rc == -1, "dup2");
        rc = execvp(argv[2],&argv[2]);
        exit_if(rc == -1, "execvp");
    }
    else {
        close(fd);
        int status = 0;
        pid_t waited_pid = wait(&status);
        exit_if(waited_pid != pid, "wait wrong pid");
        if (WIFEXITED(status)) {
            printf("Exit avec le code %d \n", WEXITSTATUS(status));
        }
        if (WIFSIGNALED(status)) {
            printf("Signal %d \n", WTERMSIG(status));
        }
    }
#endif
}
