#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "utils.h"
#include <dirent.h>
#define BUFFER_SIZE 4

void symbole(struct dirent* p, char* current){
    struct stat s;
    char path[500];
    sprintf(path, "%s/%s", current, p->d_name);
    int tmp = stat(path, &s);
    exit_if(tmp==-1,"stat");
    if (S_ISREG(s.st_mode)) {
        printf("-");
    }
    if (S_ISFIFO(s.st_mode)) {
        printf("FIFO -");
    }
    if (S_ISDIR(s.st_mode)) {
        printf("dir -");
    }
}


int main(int argc, char *argv[]) {
    DIR* pDIR;
    for (int i= 1; i<argc; i++) {
        pDIR = opendir(argv[i]);
        exit_if(pDIR == NULL, "opendir");
        struct dirent* pDirEnt = readdir(pDIR);
        while (pDirEnt != NULL) {
            printf("%s \n",pDirEnt->d_name);
            symbole(pDirEnt, argv[i]);
            pDirEnt = readdir (pDIR);
        }
        closedir(pDIR);
    }
    return EXIT_SUCCESS;
}
