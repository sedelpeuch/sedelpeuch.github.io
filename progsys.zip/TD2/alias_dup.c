#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "utils.h"

#define BUFFER_SIZE 4

void transfer( int fd_in, int fd_out )
{
    char buffer[BUFFER_SIZE];
    ssize_t len_read, wrote, rc;

    while( 1 ) {
        len_read = read( fd_in, buffer, BUFFER_SIZE);
        exit_if( len_read == -1, "read" );

        if ( len_read == 0 ) {
            /* EOF*/
            return;
        }

        wrote = 0;
        /*
         * Si jamais write n'écrit pas assez, on doit boucler pour
         * tout écrire avant de repasser à read
         */
        do{
            rc = write( fd_out, buffer + wrote, len_read - wrote );
            exit_if( rc == -1, "write" );
            wrote += rc;
        } while( wrote < len_read );
    }
}

int main(int argc, char *argv[]) {
    int fd = open("donnees.txt",O_RDONLY);
    exit_if(fd == -1, "open");
    transfer(fd, STDOUT_FILENO);
    int fd2 = dup(fd);
    exit_if(fd2 == -1, "open");
    transfer(fd2,STDOUT_FILENO);
    fd = close(fd);
    fd2 = close (fd2);
    exit_if(fd == -1, "close");
    exit_if(fd2 == -1, "close");
    return EXIT_SUCCESS;
}
