#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "utils.h"
#include <dirent.h>

int main(int argc, char *argv[]) {
    pid_t pid;
    printf("PID : %d",getpid());
    flush(stdout);
    pid = fork();
    if (pid == 0) {
        printf("PIDf  : %d",getpid());
        printf("PIDp : %d\n",getppid());
    }
    else{}
    return 0;
}
