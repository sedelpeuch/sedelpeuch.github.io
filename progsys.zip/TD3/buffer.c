#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "utils.h"
#include <dirent.h>

#define CHAINE1 "Hello \n"

#define CHAINE2 "World !"

#define UTILISER_FPRINTF1 1

#define UTILISER_FPRINTF2 1

#define UTILISER_SORTIE_ERREUR1 0

#define UTILISER_SORTIE_ERREUR2 1

#define UTILISER_EXIT 0

int main(int argc, char *argv[]) {
    size_t length1 = strlen(CHAINE1);
    size_t length2 = strlen(CHAINE2);

    int exit1 = STDOUT_FILENO;
    FILE *exitp1 = stdout;

    int exit2 = STDOUT_FILENO;
    FILE *exitp2 = stdout;

    if (UTILISER_SORTIE_ERREUR1==1) {
        exit1 = STDERR_FILENO;
        exitp1 = stderr;
    }
    if (UTILISER_SORTIE_ERREUR2==1) {
        exit2 = STDERR_FILENO;
        exitp2 = stderr;
    }

    if (UTILISER_FPRINTF1==1) {
        fprintf(exitp1,"%s",CHAINE1);
    }
    else {
        int fd = write(exit1,CHAINE1,length1);
        exit_if(fd==-1, "write");
    }

    if (UTILISER_FPRINTF2==1) {
        fprintf(exitp2,"%s",CHAINE2);
    }
    else {
        int fd = write(exit2,CHAINE2,length2);
        exit_if(fd==-1, "write");
    }

    if (UTILISER_EXIT==1) {
        _exit(2);
    }
    exit(3);
}
