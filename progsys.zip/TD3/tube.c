#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "utils.h"

#define READ_SIZE 500
#ifndef NB_WRITE
#define NB_WRITE 10
#endif

int main(int argc, char **argv)
{
    int fds[2];
    int rc;

    rc = pipe(fds);
    exit_if(rc == -1, "pipe", __LINE__);

    int read_fd = fds[0];
    int write_fd = fds[1];

    pid_t pid = fork();
    exit_if(pid < 0, "fork", __LINE__);

    if (pid==0) {
        close(write_fd);
        char buffer[READ_SIZE];
        int read_size = read(read_fd, buffer, READ_SIZE);
        exit_if(read_size == -1, "read from pipe",__LINE__);

        rc = write(STDOUT_FILENO, buffer, read_size);
        exit_if(rc != read_size, "Write after read",__LINE__);

        fprintf(stderr, "Je suis le fils et je quitte");
    }
    else{
        close(read_fd);
        rc = dup2(write_fd, STDOUT_FILENO);
        exit_if(rc <0, "dup2", __LINE__);
        close(write_fd);

        rc= execlp("ps", "ps", (char*) NULL);
        exit_if(rc== -1, "execlp", __LINE__);
    }
}
