#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>
#include <sys/mman.h>
#include <fcntl.h>

#define BUFFER_SIZE 2048
int main(int argc, char *argv[]) {
    int fd = open("libadd.a", O_RDONLY);
    exit_if(fd < 0, "open",__LINE__);

    void* addr = mmap(NULL, BUFFER_SIZE, PROT_EXEC, MAP_SHARED, fd, 0);
    exit_if(addr == MAP_FAILED, "mmap", __LINE__);

    int (*f) (int, int) = addr;
    printf("18 + 2 = %d \n", f(18,2));

    int rc = munmap(addr, BUFFER_SIZE);
    exit_if(rc != 0, "munmap", __LINE__);

    rc = close(fd);
    exit_if(rc == -1, "close", __LINE__);


    return 0;
}
