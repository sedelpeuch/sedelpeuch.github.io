#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>

#define USE_SIGNAL 0

void handler(int s){
    printf("Received signal : %d\n",s);
}

int main(int argc, char *argv[]) {
    printf("PID : %d \n",getpid());

#if USE_SIGNAL == 1
    signal(SIGUSR1,handler);
#else
    struct sigaction sa, previous_sa;
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags=0;
    sigaction(SIGUSR1,&sa,&previous_sa);
#endif

    while(1){
        pause();
    }

#if USE_SIGNAL == 1
    signal(SIGUSR1, SIG_DFL);
#else
    sigaction(SIGUSR1, &previous_sa, NULL);
#endif
    return 0;
}
