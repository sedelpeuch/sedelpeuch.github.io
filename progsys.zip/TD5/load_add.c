#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>
#include <sys/mman.h>
#include <fcntl.h>

#define BUFFER_SIZE 2048
int add(int a, int b){
    return a+b;
}

int main(int argc, char *argv[]) {

    char buffer[BUFFER_SIZE];
    int fd = open("libadd.a", O_CREAT|O_RDWR, S_IRUSR|S_IWUSR);
    exit_if(fd < 0, "open",__LINE__);
    int rc = write(fd, buffer, BUFFER_SIZE);
    exit_if(rc != BUFFER_SIZE, "write create",__LINE__);

    void* addr = mmap(NULL, BUFFER_SIZE, PROT_WRITE | PROT_EXEC, MAP_SHARED, fd, 0);
    exit_if(addr == MAP_FAILED, "mmap",__LINE__);

    memcpy(addr, &add, BUFFER_SIZE);

    rc = munmap(addr, BUFFER_SIZE);
    exit_if(rc != 0, "munmap",__LINE__);
    rc = close(fd);
    exit_if(rc != 0, "close", __LINE__);
    return 0;
}
