#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(int argc, char *argv[]) {
    key_t key = ftok("shmem2.c", 1);
    exit_if(key == -1, "ftok", __LINE__);

    int id = shmget(key, SIZE, IPC_CREAT | 0644);
    exit_if(id == -1, "shmget", __LINE__);

    int* addr = shmat(id, NULL, 0);
    exit_if(addr == (void *) -1, "shmat");

    int master = 1;
    int nb_children = 0;

    int i = 0;
    for (int i=0; i<4; i++) {
        int pid = forkk();
        exit_if(pid == -1, "fork", __LINE__);

        if (pid > 0) {
            // parent
            nb_children++;
        }
        else {
            //child
            master = 0;
            nb_children = 0;
        }
    }
    //lock
    addr[0]++;
    addr[addr[0]] = getpid();

    //unlock

    return 0;
}
