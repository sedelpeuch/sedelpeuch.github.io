#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>
#include <sys/mman.h>
#include <fcntl.h>
#define SIZE 128

void handler(int s){
    printf("Received signal : %d\n",s);
}

int main(int argc, char *argv[]) {
    int fd;
    char buffer[SIZE];
    void* addr;
    fd = open("text.txt",O_RDWR|O_CREAT, 0644);
    exit_if(fd<0,"open",__LINE__);

    int rc = write(fd, buffer, SIZE);
    exit_if(rc != SIZE, "write", __LINE__);

    addr = mmap(NULL,SIZE,PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    exit_if(addr == MAP_FAILED, "mmap",__LINE__);

    pid_t pid = getpid();
    printf("My PID : %d \n",pid);
    memcpy(addr, &pid, sizeof(pid));
#if USE_SIGNAL == 1
    signal(SIGUSR1,handler);
#else
    sigset_t set_usr1,set_all, old_set;
    struct sigaction sa, previous_sa;
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags=0;

    sigemptyset(&set_usr1);
    sigaddset(&set_usr1,SIGUSR1);
    sigfillset(&set_all);
    sigdelset(&set_all, SIGUSR1);
    rc = sigprocmask(SIG_BLOCK, &set_usr1, &old_set);
    sigsuspend(&set_all);

    rc = sigprocmask(SIG_BLOCK, &old_set, NULL);
    sigaction(SIGUSR1,&sa,&previous_sa);
#endif

    while(1){
        pause();
    }

#if USE_SIGNAL == 1
    signal(SIGUSR1, SIG_DFL);
#else
    sigaction(SIGUSR1, &previous_sa, NULL);

    munmap(addr,SIZE);
    close(fd);
#endif
    return 0;
}
