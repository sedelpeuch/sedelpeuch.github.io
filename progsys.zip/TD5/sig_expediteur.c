#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>
#include <sys/mman.h>
#include <fcntl.h>
#define SIZE 128

void handler(int s){
    printf("Received signal : %d\n",s);
}

int main(int argc, char *argv[]) {
    int fd;
    void* addr;
    ssize_t len_read = 0, offset = 0;

    fd = open("text.txt",O_RDWR);
    exit_if(fd<0,"open",__LINE__);

    addr = mmap(NULL,SIZE,PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    exit_if(addr == MAP_FAILED, "mmap",__LINE__);

    pid_t recv_pid;
    memcpy(&recv_pid, addr, sizeof(recv_pid));

    do{
        len_read = read(STDIN_FILENO, addr+offset, SIZE);
        exit_if(len_read == -1, "read", __LINE__);
    }while(len_read != 0);

    kill(recv_pid, SIGUSR1);

    munmap(addr,SIZE);
    close(fd);
    return 0;
}
