#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"
#include <sys/signal.h>
#include <sys/mman.h>
#include <fcntl.h>

#define SIZE 128

int main(int argc, char *argv[]) {

    int* p = mmap(NULL, sizeof(int), PROT, MAP_PRIVATE |  MAP_ANONYMOUS, -1, 0);
    exit_if(p == MAP_FAILED, "map",__LINE__);
    fprintf(stderr, "%p",p);
    fprintf(stderr, "%d",*p);
    *p = 42;
    fprintf(stderr, "%d\n",*p);
    exit_if(munmap(p,sizeof(int)) != 0, "munman",__LINE__);
    return 0;
}
