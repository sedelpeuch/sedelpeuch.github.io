#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "utils.h"

int main(int argc, char **argv)
{
    int fds[2];
    int in_next = STDIN_FILENO;
    pid_t pid_enfant, pid;
    int status;

    if (1 >= argc) {
        fprintf(stderr, "Usage: %s command --- ... --- command\n", argv[0]);
        return EXIT_FAILURE;
    }

    for (;;) {
        char **args = ++argv;
        while (NULL != *argv && strncmp(*argv, "---", 3)) {
            ++argv;
        }

        if (NULL != *argv) {
            /* On n'est pas le dernier processus du pipeline */
            exit_if(pipe(fds)==-1, "pipe",__LINE__);
        }

        pid_enfant = fork();
        exit_if(pid_enfant==-1,"pid enfant", __LINE__);
        if (0 == pid_enfant) {
            /* FILS */
            if (STDIN_FILENO != in_next) {
                /* On n'est pas dans le premier processus du pipeline */
                dup2(in_next, STDIN_FILENO);
                close(in_next);
            }
            if (NULL != *argv) {
                /* On n'est pas le dernier processus du pipeline */
                dup2(fds[1], STDOUT_FILENO);
                close(fds[0]);
                close(fds[1]);
            }
            *argv = NULL;
            execvp(*args, args);
        }
        /* PERE */
        if (STDIN_FILENO != in_next)
            close(in_next);
        if (NULL == *argv)
            break;

        close(fds[1]);
        in_next = fds[0];
    }

    /* On attend le bon enfant */
    do {
        pid = wait(&status);
        exit_if(pid==-1,"pid",__LINE__);
    } while (pid != pid_enfant);

    if (WIFEXITED(status))
        return WEXITSTATUS(status);
    else {
        if (WIFSIGNALED(status))
            fprintf(stderr, "Signal %d\n", WTERMSIG(status));

        return EXIT_FAILURE;
    }
}
