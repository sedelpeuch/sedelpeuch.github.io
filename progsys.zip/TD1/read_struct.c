#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>


#include "utils.h"


int main(int argc, char *argv[]) {
    ssize_t res;
    struct nopad in_s;
    res = read(STDIN_FILENO, &in_s, sizeof(in_s));
    exit_if(res != sizeof(in_s), "read struct error");
    res = write(STDOUT_FILENO, &in_size, sizeof(in_size));
    exit_if(res != sizeof(in_size), "read size error");

    printf("");
    return EXIT_SUCCESS;
}
