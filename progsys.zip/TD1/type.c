#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <unistd.h>
#include <string.h>


#include "utils.h"

int main(int argc, char *argv[]) {
    struct stat buf;
    int ret = fstat(STDIN_FILENO, &buf);
    exit_if(ret == -1, "error stat");
    mode_t mode = buf.st_mode;
    printf(" Fichier %d \n",S_ISREG(mode));
    printf(" Répertoire %d \n",S_ISDIR(mode));
    printf(" Device char %d \n",S_ISCHR(mode));
    printf(" Device bloc  %d \n",S_ISBLK(mode));
    printf(" Fifo %d \n",S_ISFIFO(mode));
    printf(" Lien symbolique %d \n",S_ISLNK(mode));
    printf(" Socket %d \n",S_ISSOCK(mode));

    return EXIT_SUCCESS;
}
