#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include "utils.h"

int main(int argc, char *argv[])
{
  for (int i = 1; i < argc; i++) {
    size_t length = strlen(argv[i]); // strlen() est toléré dans cet exemple, mais pas forcément dans les prochains
    ssize_t byte_count = write(STDOUT_FILENO, argv[i], length);
    exit_if(byte_count != length, "write space");
  }

  return EXIT_SUCCESS;
}
