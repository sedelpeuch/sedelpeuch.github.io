#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include "utils.h"

int main(int argc, char *argv[]) {
    long mylong = 345;
    ssize_t rc, len;

    len = sizeof(long);
    rc = read(STDIN_FILENO, &mylong, len);
    exit_if(rc != len, "read");

    printf("mylong : %ld \n",mylong);
    return EXIT_SUCCESS;
}
