#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include "utils.h"

#define BUFFER_SIZE 255

int main(int argc, char *argv[])
{
    char buff[BUFFER_SIZE];
    int r = 0;
    int s = 0;
    do{
        r = read(STDIN_FILENO, buff, BUFFER_SIZE);
        exit_if(r == -1, "read");
        int cursor = 0;
        do {
            s = write(STDOUT_FILENO, buff + cursor, r - cursor);
            cursor += s;
            exit_if(s == -1, "write");
        } while (cursor != r);
    }while(r != 0);
    return EXIT_SUCCESS;
}
