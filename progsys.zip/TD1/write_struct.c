#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>

#include "utils.h"


int main(int argc, char *argv[]) {
    ssize_t res;
    struct nopad s = {
    .c1 = 'a',
    .l = 5,
    .c = 'b',
    };
    res = write(STDIN_FILENO, &s, sizeof(s));
    exit_if(res < 0, "write struct error");
    res = write(STDOUT_FILENO, &res, sizeof(res));
    exit_if(res < 0, "write size error");

    return EXIT_SUCCESS;
}
