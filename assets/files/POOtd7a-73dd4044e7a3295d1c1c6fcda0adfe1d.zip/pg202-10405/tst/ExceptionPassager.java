package tec;

final public class ExceptionPassager extends FauxPassager{

    public ExceptionPassager() {
        super();
    }

    public void nouvelArret(Vehicule bus, int numeroArret) {
        bus.arretDemanderSortie(this);
    }
}
