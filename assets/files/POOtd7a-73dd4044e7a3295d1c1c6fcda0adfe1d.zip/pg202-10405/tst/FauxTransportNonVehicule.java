package tec;

final public class FauxTransportNonVehicule implements Transport {
    public void allerArretSuivant() {}
}
