package tec;

import java.lang.reflect.InvocationTargetException;

final class TestArretPrudent extends TestPassagerAbstrait{
    protected PassagerAbstrait creerPassager(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        if (comportNouvArret != ArretPrudent.getInstance() && comportNouvArret != null) {
            throw new IllegalArgumentException("Le comportement d'arrêt doit être ArretPrudent");
        }

        return new FausseMontee(nom, destination, ArretPrudent.getInstance());
    }

    public TestArretPrudent() {}

    public void testCombinaisonsAutorisees() throws CombinaisonInterditeException {}

    public void testCombinaisonsInterdites() throws CombinaisonInterditeException {}

    public void testChoixPlaceArret() throws CombinaisonInterditeException {
        /* Premier cas : le passager est assis et loin de la destination
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Toto le zero", 5, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

            p.changerEnAssis();
            p.nouvelArret(faux, 1);

            assert 0 == faux.logs.size() : "loin de la destination";
        }

        /* Deuxieme cas : le passager est assis et arrive a 3 arrets de la destination
         * (test de borne)
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Toto le zero", 5, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

            p.changerEnAssis();
            p.nouvelArret(faux, 2);

            assert 0 == faux.logs.size() : "loin de la destination (borne)";
        }

        /* Troisieme cas : le passager est assis et arrive a 2 arrets de la destination
         * (test de borne)
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Toto le zero", 5, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

            p.changerEnAssis();
            p.nouvelArret(faux, 3);

            assert this.getLastLog(faux) == "arretDemanderDebout" : "demande debout borne";
        }

        /* Quatrieme cas : le passager est assis et arrive a 1 arret de la destination
         * (test dans l'intervalle)
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Toto le zero", 5, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

            p.changerEnAssis();
            p.nouvelArret(faux, 4);

            assert this.getLastLog(faux) == "arretDemanderDebout" : "demande debout intervalle";
        }

        /* Cinquieme cas : le passager est assis, arrive proche de la destination
         * mais il n'y a plus de place debout
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Antoine Chartron", 5, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.ASSIS);

            p.changerEnAssis();
            p.nouvelArret(faux, 3);

            assert faux.logs.size() == 0 : "ne peut pas se lever";
        }

        /* Sixieme cas : le passager est deja debout et arrive proche de la destination
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Jean Bombeur", 5, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.DEBOUT);

            p.changerEnDebout();
            p.nouvelArret(faux, 3);

            assert faux.logs.size() == 0 : "déjà debout";
        }

        /* Septieme cas : le passager est assis et est à plus de 5 arrêts de sa destination
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Jean Renault", 7, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.ASSIS);

            p.changerEnAssis();
            p.nouvelArret(faux, 1);

            assert faux.logs.size() == 0 : "déjà assis";
        }

        /* Huitieme cas : le passager est debout et est à plus de 5 arrêts de sa destination
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Johnny Hallyday", 7, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.ASSIS);

            p.changerEnDebout();
            p.nouvelArret(faux, 1);

            assert this.getLastLog(faux) == "arretDemanderAssis" : "demande assis";
        }

        /* Neuvieme cas : le passager est debout, est encore loin de la destination
         * mais il n'y a plus de place assise
         */
         {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Aymeric Ferron", 7, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.DEBOUT);

            p.changerEnAssis();
            p.nouvelArret(faux, 1);

            assert faux.logs.size() == 0 : "ne peut pas s'asseoir";
        }

         /* Dixieme cas : le passager est debout et proche de la destination
         */
        {
            ComportementNouvelArret cna = ArretPrudent.getInstance();
            PassagerAbstrait p = creerPassager("Toto le zero", 3, cna);
            FauxVehicule faux = new FauxVehicule(FauxVehicule.DEBOUT);

            p.changerEnDebout();
            p.nouvelArret(faux, 1);

            assert 0 == faux.logs.size() : "reste debout proche de la destination";
        }

    }

    public void testInstanciation() throws CombinaisonInterditeException {}
    public void testChoixPlaceMontee() throws CombinaisonInterditeException {}

    public void testGestionEtat() throws CombinaisonInterditeException {
      this.gestionEtat(ArretPrudent.getInstance());
    }
}
