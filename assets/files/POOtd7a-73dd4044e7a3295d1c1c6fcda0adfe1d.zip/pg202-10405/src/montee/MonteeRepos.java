package tec;

public class MonteeRepos extends PassagerAbstrait {
    public MonteeRepos(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        super(nom, destination, comportNouvArret);

        // Interdit la combinaison MonteeRepos -- ArretNerveux
        if(comportNouvArret == ArretNerveux.getInstance()) {
            throw new CombinaisonInterditeException(this, comportNouvArret);
        } else if (destination < 0) {
            throw new IllegalArgumentException(String.format("Valeur destination négative. " +
                    "Reçu : \"%s\", Valeurs acceptées : destination >= 0.\n", destination));
        }
    }

    @Override
    protected void choixPlaceMontee(Vehicule v) {
        if (v.aPlaceAssise()) {
            v.monteeDemanderAssis(this);
        } else if (v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }
}
