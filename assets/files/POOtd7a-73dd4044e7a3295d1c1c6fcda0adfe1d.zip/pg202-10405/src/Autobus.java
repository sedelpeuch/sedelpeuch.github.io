package tec;

import java.util.ArrayList;
import java.util.List;

public final class Autobus extends Vehicule implements Transport {
    private final String msgFmtExcMontee = "Le passager est déjà dans l'autobus";
    private int arret;
    final private Jauge jaugeAssis;
    final private Jauge jaugeDebout;
    final private List<Passager> passagers;

    /**
     * Construit un autobus.
     * @throws IllegalArgumentException si placesAssises ou placesDebout est négatif
     */
    public Autobus(int placesAssises, int placesDebout)
    {
        if (placesAssises < 0 || placesDebout < 0) {
        throw new IllegalArgumentException(String.format("Valeur placesAssises ou/et placesDebout négative(s). " +
                "Reçu : placesAssises : \"%s\", placesDebout : \"%s\" " +
                ", Valeurs acceptées : placesAssises >= 0 et placesDebout >= 0.\n", placesAssises, placesDebout));
    }
        jaugeAssis = new Jauge(placesAssises,0);
        jaugeDebout = new Jauge(placesDebout,0);
        passagers = new ArrayList<>(placesDebout + placesAssises);
        arret = 0;
    }

    /**
     * Passe au prochain arrêt et prévient les passagers.
     */
    @Override
    public final void allerArretSuivant()
    {
        arret++;
        List<Passager> clone = new ArrayList<Passager>(passagers);

        for (Passager passager : clone) {
            passager.nouvelArret(this, arret);
        }
    }

    /**
     * Indique s'il y a une place assise de disponible.
     */
    @Override
    public final boolean aPlaceAssise()
    {
        return jaugeAssis.estVert();
    }

    /**
     * Indique s'il y a une place debout de disponible.
     */
    @Override
    public final boolean aPlaceDebout()
    {
        return jaugeDebout.estVert();
    }

    /**
     * Un passager passe en position assise.
     * Cette méthode NE vérifie PAS qu'il y a effectivement des places assises ou que le passager est debout.
     * Un passager peut être autorisé à prendre une place assise même lorsqu'il n'y en a plus (selon sa stratégie
     * de nouvel arrêt).
     * @precond p.estDebout() == true
     */
    @Override
    public final void arretDemanderAssis(Passager p)
    {
        jaugeAssis.incrementer();
        jaugeDebout.decrementer();
        p.changerEnAssis();
    }

    /**
     * Un passager passe en position debout.
     * Cette méthode NE vérifie PAS qu'il y a effectivement des places debout ou que le passager est assis.
     * Un passager peut être autorisé à prendre une place debout même lorsqu'il n'y en a plus (selon sa stratégie
     * de nouvel arrêt).
     * @precond p.estAssis() == true
     */
    @Override
    public final void arretDemanderDebout(Passager p)
    {
        jaugeAssis.decrementer();
        jaugeDebout.incrementer();
        p.changerEnDebout();
    }



    /**
     * Fait sortir un passager et actualise les jauges.
     */
    @Override
        public final void arretDemanderSortie(Passager p)
        {
            if (p.estDebout()) {
                jaugeDebout.decrementer();
            }
            else if (p.estAssis()) {
                jaugeAssis.decrementer();
            }
            passagers.remove(p);

            p.changerEnDehors();
        }


    /**
     * Un passager monte dans le bus et prend une place assise, s'il n'est pas déjà à bord.
     * Cette méthode NE vérifie PAS qu'il y a effectivement des places assises.
     * Un passager peut être autorisé à prendre une place assise même lorsqu'il n'y en a plus (selon sa stratégie
     * de montée).
     * @throws IllegalArgumentException si le passager est déjà à bord
     */
    @Override
    public final void monteeDemanderAssis(Passager p)
    {
        if (chercherPassager(p) != -1) {
            throw new IllegalArgumentException(this.msgFmtExcMontee);
        }
        jaugeAssis.incrementer();
        passagers.add(p);
        p.changerEnAssis();
    }

    /**
     * Un passager monte dans le bus et prend une place debout, s'il n'est pas déjà à bord.
     * Cette méthode NE vérifie PAS qu'il y a effectivement des places debout.
     * Un passager peut être autorisé à prendre une place debout même lorsqu'il n'y en a plus (selon sa stratégie
     * de montée).
     * @throws IllegalArgumentException si le passager est déjà à bord
     */
    @Override
    public final void monteeDemanderDebout(Passager p)
    {
        if (chercherPassager(p) != -1) {
            throw new IllegalArgumentException(this.msgFmtExcMontee);
        }
        jaugeDebout.incrementer();
        passagers.add(p);
        p.changerEnDebout();
    }

    @Override
    public String toString(){
        return "[arret " + this.arret + "] assis" + jaugeAssis.toString() + " debout" + jaugeDebout.toString();
    }

    /**
     * Renvoie l'index du passager s'il est à bord, -1 sinon.
     */
    private int chercherPassager(Passager p)
    {
        return passagers.indexOf(p);
    }

    /**
     * Renvoie le premier emplacement vide dans le bus.
     * S'il n'y en a pas, retourne -1.
     */
    private int chercherEmplacementVide()
    {
        return chercherPassager(null);
    }

}
