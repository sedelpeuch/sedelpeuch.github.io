package tec;

public final class ArretAgoraphobe extends ComportementNouvelArret{
    private static ArretAgoraphobe arretAgoraphobe = null;

    private ArretAgoraphobe(){}

    public static ComportementNouvelArret getInstance() {
        if (arretAgoraphobe == null) {
            arretAgoraphobe = new ArretAgoraphobe();
        }
        return arretAgoraphobe;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (!v.aPlaceAssise() && !v.aPlaceDebout()) {
            v.arretDemanderSortie(p);
        }
    }
}