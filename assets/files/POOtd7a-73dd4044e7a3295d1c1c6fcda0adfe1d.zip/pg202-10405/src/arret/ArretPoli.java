package tec;

public final class ArretPoli extends ComportementNouvelArret{
    private static ArretPoli arretPoli = null;

    private ArretPoli(){}

    public static ComportementNouvelArret getInstance() {
        if (arretPoli == null) {
            arretPoli = new ArretPoli();
        }
        return arretPoli;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (p.estAssis()
                && !v.aPlaceAssise()
                && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        }
    }
}
