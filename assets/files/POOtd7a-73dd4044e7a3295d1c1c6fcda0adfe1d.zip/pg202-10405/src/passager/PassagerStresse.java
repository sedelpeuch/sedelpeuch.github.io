package tec;

/**
 * @deprecated Depuis la version 6.0a/b, PassagerStresse
 * doit être remplacé par une instanciation new MonteeFatigue(nom, destination, ArretPrudent.getInstance()).
 */
@Deprecated
public final class PassagerStresse extends MonteeFatigue {
    public PassagerStresse(String nom, int destination) throws CombinaisonInterditeException {
        super(nom, destination, ArretPrudent.getInstance());
    }
}
