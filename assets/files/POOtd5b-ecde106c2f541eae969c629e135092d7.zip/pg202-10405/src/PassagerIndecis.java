package tec;

class PassagerIndecis extends PassagerAbstrait {

    public PassagerIndecis(String nom, int destination) {
        super(nom, destination);
    }

    @Override
    public void choixPlaceMontee(Vehicule v) {
        if(v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }

    @Override
    public void choixPlaceArret(Vehicule v, int arret) {
        if(estDebout() && v.aPlaceAssise()) {
            v.arretDemanderAssis(this);
        } else if(estAssis() && v.aPlaceDebout()) {
            v.arretDemanderDebout(this);
        }
    }

    @Override
    public String toString(){
        return "[p. indécis] " + super.toString();
    }
}
