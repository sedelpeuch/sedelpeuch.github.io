package tec;

public class FabriqueTec{

  /*
  * Surcharger le constructeur pour ne pas l'exposer
  */
  private FabriqueTec(){
  }

  /*
  * Fonction créant un Autobus
  */
  public static Transport faireAutobus(int placesAssises, int placesDebout){
    return new Autobus(placesAssises, placesDebout);
  }

  /*
  * Fonction créant un Passager
  */
  public static Usager fairePassager(String type, String nom, int destination) {
        switch(type) {
            case "PassagerStandard":
                return new PassagerStandard(nom, destination);
            case "PassagerStresse":
                return new PassagerStresse(nom, destination);
            case "PassagerIndecis":
                return new PassagerIndecis(nom, destination);
            default:
                return new PassagerStandard(nom, destination);
        }
    }
}
