package tec;


import java.lang.reflect.InvocationTargetException;

class TestPassagerIndecis extends TestPassagerAbstrait {
    public static void main(String[] args) throws IllegalAccessException,
            InstantiationException, NoSuchMethodException, InvocationTargetException {
        // Test Runner
        // tec.TestRunner.runTestsForClass(TestPassagerIndecis.class);
        // Solution TD5
        TestPassagerAbstrait.runTests(TestPassagerIndecis.class);
    }

    protected PassagerAbstrait creerPassager(String nom, int destination) {
        return new tec.PassagerIndecis(nom, destination);
    }
    
    public TestPassagerIndecis() {}

    /* Etat apres instanciation
     * Un seul cas
     */
    public void testInstanciation() {
        PassagerAbstrait p = creerPassager("xxx", 3);

        assert false == p.estAssis();
        assert false == p.estDebout();
        assert true == p.estDehors();
    }

    public void testChoixPlaceMontee() {

      PassagerAbstrait p = creerPassager("a",4);

      /* Premier cas : le véhicule a des places debout */
      FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

      p.monterDans(faux);

      assert "monteeDemanderDebout" == getLastLog(faux) : "debout";

      /* Deuxième cas : le véhicule n'a plus de place debout */
      faux = new FauxVehicule(FauxVehicule.ASSIS);
      p = creerPassager("b",5);

      p.monterDans(faux);

      assert 0 == faux.logs.size() : "pas de place";

      /* Troisième cas : le véhicule n'a plus de place */
      faux = new FauxVehicule(FauxVehicule.PLEIN);
      p = creerPassager("b",5);

      p.monterDans(faux);

      assert 0 == faux.logs.size() : "pas de place";
    }

    public void testChoixPlaceArret(){
      PassagerAbstrait p = creerPassager("a",4);

      /* Premier cas : le passager est assis, demande une place debout et
      * de la place est disponible
      */
      FauxVehicule faux = new FauxVehicule(FauxVehicule.DEBOUT);
      p.changerEnAssis();

      p.choixPlaceArret(faux,2);

      assert "arretDemanderDebout" == getLastLog(faux) : "debout";

      /* Deuxième cas : le passager est assis, demande une place debout mais
      * il n'y a pas de place
      */
      faux = new FauxVehicule(FauxVehicule.ASSIS);
      p.changerEnAssis();

      p.choixPlaceArret(faux,2);

      assert 0 == faux.logs.size() : "pas de place debout";

      /* Troisième cas : le passager est debout, demande une place assise et
      * de la place est disponible
      */
      faux = new FauxVehicule(FauxVehicule.ASSIS);
      p.changerEnDebout();

      p.choixPlaceArret(faux,2);

      assert "arretDemanderAssis" == getLastLog(faux) : "assis";

      /* Quatrième cas : le passager est debout, demande une place assise mais
      * il n'y a pas de place
      */
      faux = new FauxVehicule(FauxVehicule.PLEIN);
      p.changerEnDebout();

      p.choixPlaceArret(faux,2);

      assert 0 == faux.logs.size() : "pas de place";
    }
}
