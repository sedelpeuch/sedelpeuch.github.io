<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    include_once ($root. "/connectDB.php");
?>

<!DOCTYPE html>
<html>
<head>

<title> SGBD Club</title>
<link rel="stylesheet" href="/css/main.css">

</head>
<body>

<?php
   $root = $_SERVER['DOCUMENT_ROOT'];
   include_once($root . "/navbar.php");
?>
<center>
<h1> Table brute de Club </h1>
</center>

<?php
$sql = "SELECT * FROM Club";
$result = $conn->query($sql);
while($data = mysqli_fetch_array($result))
{
    $tableau[]=$data;
    //détermine le nombre de colonnes
    $nbcol=1;
}

    echo '<table id="" class="center">';
    echo '<tr>';
    echo '<th>','numero club','</td>';
    echo '</tr>';

    $nb=count($tableau);
    for($i=0;$i<$nb;$i++){

    echo '<tr>';
    echo '<td>',$tableau[$i]['num_club'],'</td>';
    echo '</tr>';
    }

    echo '</table>';
$conn->close();
?>

</body>
</html>
