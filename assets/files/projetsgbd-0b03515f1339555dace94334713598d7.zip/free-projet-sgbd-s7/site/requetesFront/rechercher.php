<?php
$root = $_SERVER['DOCUMENT_ROOT'];
include_once $root . "/connectDB.php";
?>

<!DOCTYPE html>
<html>
<head>
  <title>Rechercher</title>
  <link rel="stylesheet" href="/css/main.css">
</head>
<body>

  <?php
$root = $_SERVER['DOCUMENT_ROOT'];
include_once $root . "/navbar.php";
?>

  <script type="text/javascript" src="/js/tab.js"></script>

  <center>
    <h1>🆂🅶🅱🅳 <blue style="color:#3377ff;">🆂</blue><red style="color:#ff1313;">🅴</red><yellow style="color:#ffd113;">🅰</yellow><blue style="color:#3377ff;">🆁</blue><green style="color:#33ab22;">🅲</green><red style="color:#ff1313;">🅷</red></h1>
    <p>Effectuez des recherches dans la base à partir des données que vous connaissez. Pour les valeurs entières, laissez <em>-1</em> pour indiquer que vous ne connaissez pas la valeur, laissez <em>vide</em> pour les zones de texte et enfin cochez <em>inconnue</em> pour indiquer que vous ne connaissez pas la date.</p>
  </center>

  <!-- Tab links -->
  <h2> Données à rechercher :</h2>
  <div class="tab">
    <button class="button" onclick="openInsert(event, 'Action')" id="defaultOpen">Action</button>
    <button class="button" onclick="openInsert(event, 'Categorie')">Catégorie</button>
    <button class="button" onclick="openInsert(event, 'Club')">Club</button>
    <button class="button" onclick="openInsert(event, 'Equipe')">Équipe</button>
    <button class="button" onclick="openInsert(event, 'Joueur')">Joueur</button>
    <button class="button" onclick="openInsert(event, 'Personne')">Personne</button>
    <button class="button" onclick="openInsert(event, 'Rencontre')">Rencontre</button>
  </div>

  <!-- Tab content -->
  <div id="Action" class="tabcontent">
    <h3>Rechercher une action</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="num_j">Numéro du joueur:</label>
        <input type="number" name="num_j" id="num_j" min="-1" value="-1" required="true">
      </p>
      <p>
        <label for="num_r">Numéro de rencontre:</label>
        <input type="number" name="num_r" id="num_r" min="-1" value="-1" required="true">
      </p>
      <p>
        <label for="score">Score:</label>
        <input type="number" name="score" id="score" min="-1" value="-1" required="true">
      </p>
      <p>
        <label for="faute">Nombre de fautes:</label>
        <input type="number" name="nb_f" id="nb_f" min="-1" value="-1" required="true">
      </p>
      <input type="hidden" name="frmname" value="action">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

  <div id="Categorie" class="tabcontent">
    <h3>Rechercher une catégorie</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="num_cate">Numéro catégorie:</label>
        <input type="num" name="num_cate" min="-1" value="-1" id="num_cate" required="true">
      </p>
      <p>
        <label for="nom_cate">Nom catégorie (laisser vide si non connu):</label>
        <input type="text" name="nom_cate" id="nom_cate">
      </p>
      <input type="hidden" name="frmname" value="categorie">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

  <div id="Club" class="tabcontent">
    <h3>Rechercher un club</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="club">Numéro de club:</label>
        <input type="number" name="club" id="club" min="1" value="1" required="true">
      </p>
      <input type="hidden" name="frmname" value="club">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

  <div id="Equipe" class="tabcontent">
    <h3>Rechercher une équipe</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="num_equ">Numéro Equipe :</label>
        <input type="number" min="1" value="1" name="num_equ" id="num_equ" required="true">
      </p>
      <input type="hidden" name="frmname" value="equipe">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

  <div id="Joueur" class="tabcontent">
    <h3>Rechercher un joueur</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="nom">Nom (laisser vide si non connu):</label>
        <input type="text" name="nom" id="nom">
      </p>
      <p>
        <label for="prenom">Prénom (laisser vide si non connu):</label>
        <input type="text" name="prenom" id="prenom">
      </p>
      <p>
        <label for="date_n">Date de naissance :</label>
        <input type="date" value="<?php echo date("Y-m-d"); ?>" name="date_n" id="date_n" required="true">
        <input type="checkbox" name="inco_date_nai" id="inco_date_nai" checked>
        <label for="inco_date_nai">inconnue</label>
      </p>
      <p>
        <label for="adr">Adresse (laisser vide si non connu):</label>
        <input type="text" name="ad" id="ad">
      </p>
      <p>
        <label for="num_c">Numéro du club dans lequel est la personne:</label>
        <input type="number" min="-1" value="-1" name="num_c" id="num_c" required="true">
      </p>
      <p>
        <label for="date_a">Date adhésion au club :</label>
        <input type="date" value="<?php echo date("Y-m-d"); ?>" name="date_a" id="date_a" required="true">
        <input type="checkbox" name="inco_date_c" id="inco_date_c" checked>
        <label for="inco_date_c">inconnue</label>
      </p>
      <p>
        <label for="num_equipe">Numéro équipe du joueur :</label>
        <input type="number" min="-1" value="-1" name="num_equipe" id="num_equipe" required="true">
      </p>
      <p>
        <label for="num_j">Numéro personne associé :</label>
        <input type="number" min="-1" value="-1" name="num_j" id="num_j" required="true">
      </p>
      <input type="hidden" name="frmname" value="joueur">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

  <div id="Personne" class="tabcontent">
    <h3>Rechercher une personne</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="nom">Nom (laisser vide si non connu):</label>
        <input type="text" name="nom" id="nom">
      </p>
      <p>
        <label for="prenom">Prénom (laisser vide si non connu):</label>
        <input type="text" name="prenom" id="prenom">
      </p>
      <p>
        <label for="date_n">Date de naissance :</label>
        <input type="date" value="<?php echo date("Y-m-d"); ?>" name="date_n" id="date_n" required="true">
        <input type="checkbox" name="inco_date_nai" id="inco_date_nai" checked>
        <label for="inco_date_nai">inconnue</label>
      </p>
      <p>
        <label for="adr">Adresse (laisser vide si non connu):</label>
        <input type="text" name="ad" id="ad">
      </p>
      <p>
        <label for="date_a">Date adhésion au club :</label>
        <input type="date" value="<?php echo date("Y-m-d"); ?>" name="date_a" id="date_a" required="true">
        <input type="checkbox" name="inco_date_c" id="inco_date_c" checked>
        <label for="inco_date_c">inconnue</label>
      </p>
      <p>
        <label for="fonction">Fonction au sein du bureau du club :</label>
        <select name="fonction">
          <option value="inconnue">Inconnue</option>
          <option value="president">Président</option>
          <option value="secretaire">Secrétaire</option>
          <option value="tresorier">Trésorier</option>
        </select>
      </p>
      <p>
        <label for="num_c">Numéro du club dans lequel est la personne:</label>
        <input type="number" min="-1" value="-1" name="num_c" id="num_c" required="true">
      </p>
      <input type="hidden" name="frmname" value="personne">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

  <div id="Rencontre" class="tabcontent">
    <h3>Rechercher une rencontre</h3>
    <form action="/requetesBack/rechercher.php" method="post" target="_blank">
      <p>
        <label for="date">Date de la rencontre :</label>
        <input type="date" value="<?php echo date("Y-m-d"); ?>" name="date" id="date" required="true">
        <input type="checkbox" name="inco_date" id="inco_date" checked>
        <label for="inco_date">inconnue</label>
      </p>
      <p>
        <label for="e1">Numéro équipe 1 :</label>
        <input type="number" min="-1" value="-1" name="e1" id="e1" required="true">
      </p>
      <p>
        <label for="e1">Numéro équipe 2 :</label>
        <input type="number" min="-1" value="-1" name="e2" id="e2" required="true">
      </p>
      <input type="hidden" name="frmname" value="rencontre">
      <input type="submit" value="Rechercher">
      <input type="reset">
    </form>
  </div>

</body>

<script> // Get the element with id="default" and click on it
document.getElementById("defaultOpen").click();
</script>