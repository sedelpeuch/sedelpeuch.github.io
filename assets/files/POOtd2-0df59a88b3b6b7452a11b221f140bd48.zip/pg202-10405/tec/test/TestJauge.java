class TestJauge {
    private TestJauge() {
        System.out.print(".");
    }

    private void testDansIntervalle() {
        int max = 67899;
        int depart = 100;

        Jauge j = new Jauge(max, depart);
        assert j.estVert(): "La jauge n'est pas verte dans l'intervalle";
        assert !j.estRouge(): "La jauge est rouge dans l'intervalle";
    }

    private void testSuperieurIntervalle() {
        int max = 255;
        int depart = 258;

        Jauge j = new Jauge(max, depart);
        assert !j.estVert(): "La jauge est verte alors que depart > max";
        assert j.estRouge(): "La jauge n'est pas rouge alors que depart > max";
    }

    private void testEgalMaxIntervalle() {
        int max = 255;
        int depart = 255;

        Jauge j = new Jauge(max, depart);
        assert !j.estVert(): "La jauge est verte alors que depart == max";
        assert j.estRouge(): "La jauge n'est pas rouge alors que depart == max";;
    }

    private void testDepartNegatif() {
        int max = 255;
        int depart = -1;

        Jauge j = new Jauge(max, depart);
        assert !j.estVert(): "La jauge est verte quand depart negatif";
        assert !j.estRouge(): "La jauge est rouge quand depart negatif";
    }

    private void testDepartNul() {
        int max = 255;
        int depart = 0;

        Jauge j = new Jauge(max, depart);
        assert j.estVert(): "La jauge n'est pas verte alors que depart = " + depart;
        assert !j.estRouge(): "La jauge est pas rouge alors que depart = 0" + depart;
    }

    private void testIncrementerDansIntervalle() {
        int max = 5;
        int depart = 1;

        Jauge j = new Jauge(max, depart);
        j.incrementer();
        assert j.estVert(): "La jauge n'est pas verte dans l'intervalle";
        assert !j.estRouge(): "La jauge est rouge dans l'intervalle";
    }

    private void testIncrementerDepassementIntervalle() {
        int max = 5;
        int depart = 4;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++) {
            j.incrementer();
            assert !j.estVert(): "La jauge est toujours verte en dépassant l'intervalle";
            assert j.estRouge(): "La jauge n'est pas rouge en dépassant l'intervalle";
        }
    }

    private void testIncrementerAtteindreIntervalle() {
        int max = 5;
        int depart = -1;

        Jauge j = new Jauge(max, depart);
        j.incrementer();

        assert j.estVert() : "La jauge n'est verte en entrant dans l'intervalle";
        assert !j.estRouge() : "La jauge est rouge en entrant dans l'intervalle";
    }

    private void testIncrementerInferieurIntervalle() {
        int max = 5;
        int depart = -4;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.incrementer()) {
            assert !j.estVert() : "La jauge est verte sous l'intervalle";
            assert !j.estRouge() : "La jauge est rouge sous l'intervalle";
        }
    }

    private void testIncrementerSuperieurIntervalle() {
        int max = 5;
        int depart = 6;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.incrementer()) {
            assert !j.estVert() : "La jauge est verte au-dessus de l'intervalle";
            assert j.estRouge() : "La jauge n'est pas rouge au-dessus de l'intervalle";
        }
    }

    private void testDecrementerDansIntervalle() {
        int max = 5;
        int depart = 2;

        Jauge j = new Jauge(max, depart);
        j.decrementer();
        assert j.estVert(): "La jauge n'est pas verte dans l'intervalle";
        assert !j.estRouge(): "La jauge est rouge dans l'intervalle";
    }

    private void testDecrementerSortirIntervalle() {
        int max = 707;
        int depart = 0;

        Jauge j = new Jauge(max, depart);
        j.decrementer();
        assert !j.estVert(): "La jauge est verte en sortant de l'intervalle";
        assert !j.estRouge(): "La jauge est rouge sous l'intervalle";
    }

    private void testDecrementerAtteindreIntervalle() {
        int max = 55;
        int depart = 55;

        Jauge j = new Jauge(max, depart);
        j.decrementer();

        assert j.estVert() : "La jauge n'est verte en entrant dans l'intervalle";
        assert !j.estRouge() : "La jauge est rouge en entrant dans l'intervalle";
    }

    private void testDecrementerInferieurIntervalle() {
        int max = 5;
        int depart = -4;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.decrementer()) {
            assert !j.estVert() : "La jauge est verte sous l'intervalle";
            assert !j.estRouge() : "La jauge est rouge sous l'intervalle";
        }
    }

    private void testDecrementerSuperieurIntervalle() {
        int max = 5;
        int depart = 10;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.decrementer()) {
            assert !j.estVert() : "La jauge est verte au-dessus de l'intervalle";
            assert j.estRouge() : "La jauge n'est pas rouge au-dessus de l'intervalle";
        }
    }


    public static void main(String[] args) {
        boolean estMisAssertion = false;
        assert estMisAssertion = true;

        if (!estMisAssertion) {
            System.out.println("Execution impossible sans l'option -ea");
            return;
        }

        new TestJauge().testDansIntervalle();
        new TestJauge().testSuperieurIntervalle();
        new TestJauge().testEgalMaxIntervalle();
        new TestJauge().testDepartNegatif();
        new TestJauge().testDepartNul();
        new TestJauge().testIncrementerDansIntervalle();
        new TestJauge().testIncrementerDepassementIntervalle();
        new TestJauge().testIncrementerAtteindreIntervalle();
        new TestJauge().testIncrementerInferieurIntervalle();
        new TestJauge().testIncrementerSuperieurIntervalle();
        new TestJauge().testDecrementerDansIntervalle();
        new TestJauge().testDecrementerSortirIntervalle();
        new TestJauge().testDecrementerAtteindreIntervalle();
        new TestJauge().testDecrementerSuperieurIntervalle();
        new TestJauge().testDecrementerInferieurIntervalle();

        System.out.println("OK");
    }
}
