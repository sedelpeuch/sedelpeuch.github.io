class Autobus implements Vehicule{
  private int arret;
  private Jauge jauge_assis;
  private Jauge jauge_debout;
  private Passager[] passagers;

  /**
  Construit un autobus.
  Instancie les jauges et le tableau de passagers.
  Initialise l'arrêt.
  */
  public Autobus(int places_assises, int places_debout)
  {
    jauge_assis = new Jauge(places_assises,0);
    jauge_debout = new Jauge(places_debout,0);
    passagers = new Passager[places_debout+places_assises];
    arret = 0;
  }

  /**
  * Passe au prochain arrêt et prévient les passagers.
  * Incrémente arret.
  * Prévient tous les passagers qu'il s'agit d'un nouvel arrêt
  */

  @Override
  public void allerArretSuivant()
  {
    arret++;
    for(int i=0;i<passagers.length;i++)
    {
      if(passagers[i] != null)
      {
        passagers[i].nouvelArret(this,arret);
      }
    }
  }

  /**
  * Retourne si oui ou non il y a une place assise de disponible.
  */

  @Override
  public boolean aPlaceAssise()
  {
    return jauge_assis.estVert();
  }

  /**
  * Retourne si oui ou non il y a une place debout de disponible.
  */

  @Override
  public boolean aPlaceDebout()
  {
    return jauge_debout.estVert();
  }

  /**
  * Lorsqu'un passager de l'autobus est debout, il peut demander un siège.
  * S'il y a de la place, le passager la prend.
  * S'il n'existe pas, rien ne se passe.
  */

  @Override
  public void arretDemanderAssis(Passager p)
  {
    if (aPlaceAssise())
    {
      jauge_assis.incrementer();
      jauge_debout.decrementer();
      p.changerEnAssis();
    }
  }

  /**
  * Lorsqu'un passager de l'autobus est assis, il peut demander à se lever.
  * S'il y a de la place, le passager se lève.
  * Sinon, rien ne se passe.
  */

  @Override
  public void arretDemanderDebout(Passager p)
  {
    if (aPlaceDebout())
    {
      jauge_assis.decrementer();
      jauge_debout.incrementer();
      p.changerEnDebout();
    }
  }

  /**
  * Lorsqu'un passager demande à sortir, on actualise les jauges puis
  * on retire le passager du tableau de passagers.
  * Enfin, on actualise son état pour le mettre dehors.
  */

  @Override
  public void arretDemanderSortie(Passager p)
  {
    if(p.estDebout())
    {
      jauge_debout.decrementer();
    }
    else if(p.estAssis())
    {
      jauge_assis.decrementer();
    }
    int passager = chercherPassager(p);
    passagers[passager] = null;
    p.changerEnDehors();
  }

  /**
  * Lorsqu'un passager demande un siège en montant, on vérifie si un siège est
  * disponible.
  * Si c'est le cas, on actualise la jauge et on cherche un emplacement vide
  * dans le tableau de passager pour insérer le nouveau passager.
  * Enfin, on change son état en assis.
  * S'il n'y a pas de place, rien ne se passe.
  */

  @Override
  public void monteeDemanderAssis(Passager p)
  {
    if (aPlaceAssise())
    {
      jauge_assis.incrementer();
      int emplacement = chercherEmplacementVide();
      passagers[emplacement] = p;
      p.changerEnAssis();
    }
  }

  /**
  * Lorsqu'un passager demande à être debout en montant, on vérifie si de la
  * place est disponible.
  * Si c'est le cas, on actualise la jauge et on cherche un emplacement vide
  * dans le tableau de passager pour insérer le nouveau passager.
  * Enfin, on change son état en debout.
  * S'il n'y a pas de place, rien ne se passe.
  */

  @Override
  public void monteeDemanderDebout(Passager p)
  {
    if (aPlaceDebout())
    {
      jauge_debout.incrementer();
      int emplacement = chercherEmplacementVide();
      passagers[emplacement] = p;
      p.changerEnDebout();
    }
  }

  /**
  Cherche la place que le passager p occupe dans le tableau.
  */
  private int chercherPassager(Passager p)
  {
    for(int i=0;i<passagers.length;i++)
    {
      if(passagers[i] == p)
      {
        return i;
      }
    }
    return -1;
  }

  /**
  Retourne le premier emplacement vide dans le bus.
  S'il n'y en a pas, retourne -1.
  */
  private int chercherEmplacementVide()
  {
    return chercherPassager(null);
  }

}
