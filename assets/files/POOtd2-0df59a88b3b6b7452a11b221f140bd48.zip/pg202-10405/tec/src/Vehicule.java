public interface Vehicule{
  void allerArretSuivant();
  boolean aPlaceAssise();
  boolean aPlaceDebout();
  void monteeDemanderAssis(Passager p);
  void monteeDemanderDebout(Passager p);
  void arretDemanderDebout(Passager p);
  void arretDemanderAssis(Passager p);
  void arretDemanderSortie(Passager p);
}
