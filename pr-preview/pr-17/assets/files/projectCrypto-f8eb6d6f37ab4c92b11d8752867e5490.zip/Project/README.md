# Cryptologie

## TP Noté - 11 Mai 2021

## Auteurs : Sébastien DELPEUCH - Aymeric FERRON

*NB :*  les tests unitaires relatifs aux fonctions de notre TP se trouvent dans le fichier test.py ils peuvent
s'éxecuter simplement avec `python3 test.py` et utilisent le framework unitest

## Architecture du projet 

Les fonctions de la parties 1 et 2 sont dans le fichier *utils.py* 

Le fichier *prime.py* permet d'implémenter quelques fonctions de base avec les nombres premiers 

Le fichier *RSA.py* met en place le protocole RSA 

Le fichier *attack.py* met en place les attaques 

Le fichier *test.py* effectue les tests unitaires en utilisant unittest

La description de chaque fonction implémentée est disponible sous forme de docstring

## 1 - Un peu d'arithmétique (modulaire ou non)

*Cf fichier utils.py*

## 2 - Tests de primalité

### 2.1 - Crible d'Eratosthène

#### Q5.

La complexité en temps du crible d'Eratosthène est de O(exp(n)*ln(n)), elle est donc exponentielle.
*Source :* http://zanotti.univ-tln.fr/ALGO/I51/Crible.html

La complexité en espace du crible est de O(n), elle est donc linéaire.
*[Source](http://compoasso.free.fr/primelistweb/page/prime/eratosthene.php#:~:text=La%20complexit%C3%A9%20en%20m%C3%A9moire%20du,java%20%C3%A9gal%20%C3%A0%208%20bits)*

## 4 - Quelques attaques élémentaires

#### Q13.

Pour décoder le message caché de la question 13, nous avons accès à l'exposant
e ainsi qu'au nombre n. Nous avons commencé par décomposer n en nombres
premiers p et q grâce au site https://www.dcode.fr/decomposition-nombres-premiers



Nous avons trouvé p = 906343 et q = 225382967
Nous avons alors calculé phi = (p - 1) * (q - 1)
Nous avons maintenant toutes les informations pour décrypter le message avec notre fonction

On trouve comme message caché : **bravo!**
#### Q14.

On nous indique que les clefs *pk1* et *pk2* possèdent un facteur commun.
On le trouve en calculant le pgcd de *pk1* et *pk2*.
Connaissant un factteur p de notre n, il ne reste plus qu'à calculer
n/p pour trouver q. 
Ainsi, de même que précédemment, il ne reste plus qu'à calculer phi.

On trouve comme message caché : **https://info.keyfactor.com/factoring-rsa-keys-in-the-iot-era**
#### Q15.

Puisque e est petit, on peut les décomposer facilement en nombre premier à l'aide de https://www.dcode.fr/decomposition-nombres-premiers

On trouve comme messages cachés :
* bonjour 
* bonjour
* bonjour
#### Q16.
