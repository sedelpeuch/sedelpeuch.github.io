import random
import math
import utils
import secrets

"""
Ce fichier comporte des fonctions utilitaires pour manipuler / générer les nombres premiers
"""


def is_prime_pgcd(n):
    m = int(math.sqrt(n)) + 1
    for i in range(2, m):
        if utils.pgcd(n, i) != 1:
            return False
    return True


def gen_a_prime(a, i):
    """
    Cette fonction génere un nombre premier sur une plage de nombre donnée
    :param a: la borne minimale
    :param i: l'addition à la borne minimale
    :example: gen_a_prime(10,13) cherche les nombres premiers entre 10 et 13 soit 11 et 13
    :return: un nombre premier parmis ceux trouvés, aucun si il n'en existe pas
    """
    prime = []
    for n in range(a, a + i + 1):
        if is_prime_pgcd(n):
            prime.append(n)
    print(prime)
    return random.choice(prime)


def gen_double_prime(size):
    """
    Cette fonction génére un couple de nombre premier en utilisant le test de rabin
    :param size: la taille du nombre premier
    :return: le couple de nombre premier
    """
    q_is_prime = False
    p_is_prime = False
    p, q = -1, -1
    while not q_is_prime or not p_is_prime:
        if not q_is_prime:
            q = secrets.randbits(size)
            q_is_prime = utils.test_rabin(q, 50)
        if not p_is_prime:
            p = secrets.randbits(size)
            p_is_prime = utils.test_rabin(p, 50)
    return p, q
