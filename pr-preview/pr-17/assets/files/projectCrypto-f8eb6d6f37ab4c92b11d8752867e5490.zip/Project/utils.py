import random

"""
Ce fichier comporte l'implémentation des réponses des 2 premières parties 
"""

# Un peu d'arithmétique (modulaire ou non)

## pgcd, inverse modulaire

### Question 1

def pgcd(a, b):
    """
    Calcule le pgcd de a et b
    :param a: un entier positif
    :param b: un entier positif
    :return: si a ou b est négatif -1 sinon pgcd(a,b)
    """
    if a <= 0 or b <= 0:
        return -1
    while b != 0:
        a, b = b, a % b
    return a


def euclide_ext(a, b):
    """
    Mise en oeuvre de l'algorithme d'Euclide étendu.
    :param a: un entier positif
    :param b: un entier positif
    :return: si a ou b est négatif retourne -1, sinon un couple de Bezout (X,Y) tel que aX + bY = pgcd(a,b)
    :see : https://fr.wikipedia.org/wiki/Algorithme_d%27Euclide_%C3%A9tendu
    """
    if a <= 0 or b <= 0:
        return -1
    r1, u1, v1, r2, u2, v2 = a, 1, 0, b, 0, 1
    while r2 != 0:
        q = r1 // r2
        r1, u1, v1, r2, u2, v2 = r2, u2, v2, r1 - q * r2, u1 - q * u2, v1 - q * v2
    return r1, u1, v1


### Question 2

def inverse_modulaire(a, N):
    """
    Calcule l'inverse modulaire de a modulo N. C'est à dire trouve un b tel que ab = 1 mod N
    D'après le théorème de Bachet-Bézout, il existe un inverse modulaire si et seulement si PGCD(a,N)=1.
    :param a: un entier positif
    :param N: un entier positif
    :return: l'inverse modulaire de (a,N)
    :see : https://fr.wikipedia.org/wiki/Inverse_modulaire
    """
    if a <= 0 or N <= 0:
        return -1
    g, x, y = euclide_ext(a, N)
    if g != 1:
        return -1
    return x % N


## Exponentiation modulaire

def expo_modulaire(e, b, n):
    """
    Calcule l'exponentiation modulaire c'est-à-dire pow(e, b, n)
    :param e: l'exposant de l'exponentiation
    :param b: la base de l'exponentiation
    :param n: le module de l'exponentiation
    :return: l'exponentiation modulaire
    :see : https://fr.wikipedia.org/wiki/Exponentiation_modulaire
    """
    res = b
    for _ in range(e - 1):
        res = (res * b) % n
    print("Nombre de multiplication : ", e - 1, "\nNombre de modulo : ", e - 1)
    return res


def fast_expo_modulaire(e, b, n):
    """
    Calcule l'exponetiation modulaire rapide.
    :param e: l'exposant de l'exponentiation
    :param b: la base de l'exponentiation
    :param n: le module de l'exponentiation
    :return: l'exponentiation modulaire
    """
    result = 1
    while e > 0:
        if e & 1 > 0:
            result = (result * b) % n
        e >>= 1
        b = (b * b) % n
    return result


# Tests de primalité

## Crible d'ératosthène

# Q5

def crible_eratosthene(n):
    P = []
    for i in range(2, n + 1):
        if len(P) == 0:
            P.append(i)
        else:
            prem = True
            for k in P:
                if i % k == 0:
                    prem = False
            if prem == True:
                P.append(i)

    return P


## Test de Fermat

### Q6
def test_fermat(n, t):
    """
    Test de primalité de fermat utilisant le théorème 1
    :param n: un entier n à test
    :param t:  un entier t représentant le nombre de test à faire
    :return: False si le test échoue, True si le test n'échoue pas
    """
    for _ in range(0, t):
        x = random.randint(2, n)
        if fast_expo_modulaire(n - 1, x, n) != 1:
            return False
    return True


## Test de Rabin

### Q7

def q7_fonction(n):
    """
    Fonction qui pour un entier n pair, renvoie un couple (r,u) tel que n=2^r x u avec u impair
    :return: renvoie u et r tel que n=2^r x u avec u impair
    """
    u = n
    r = 0
    if n % 2 != 0:
        return -1
    while u % 2 == 0:
        u //= 2
        r += 1
    return r, u


### Q8

def test_rabin(n, t):
    """
    Effectue le test de rabin sur l'entier n
    :param n: un entier à tester
    :param t: le nombre de test à effectuer
    :return: Vrai si le test passe, Faux si il ne passe pas
    :see: https://www.lama.univ-savoie.fr/mediawiki/index.php/Algorithmes_probabilistes/d%C3%A9terministes_pour_tester_la_primalit%C3%A9_d%27un_entier
    """
    # On supprime les cas aux limites
    if n == 2 or n == 3:
        return True
    # On supprime les cas pairs
    if n % 2 == 0:
        return False
    r, s = 0, n - 1
    while s % 2 == 0:
        r += 1
        s //= 2
    for _ in range(t):
        a = random.randrange(2, n - 1)
        x = pow(a, s, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True