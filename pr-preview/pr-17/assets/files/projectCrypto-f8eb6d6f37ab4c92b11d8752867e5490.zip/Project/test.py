import unittest
import utils
import RSA
"""
Ce fichier comporte les tests unitaires des fonctions du projet en utilisant unittest. 
python3 test.py pour les lancer. 
"""

class Arithmetic(unittest.TestCase):
    def test_pgcd(self):
        self.assertEqual(1, utils.pgcd(5, 12))
        self.assertEqual(-1, utils.pgcd(0, 4))
        self.assertEqual(1, utils.pgcd(48918, 6181))
        self.assertEqual(50, utils.pgcd(100, 50))
        self.assertEqual(1, utils.pgcd(509, 15))

    def test_euclide_ext(self):
        self.assertEqual((2, 704, -153), utils.euclide_ext(1234, 5678))
        self.assertEqual(-1, utils.euclide_ext(0, 18))
        self.assertEqual((202, -2, 5), utils.euclide_ext(4444, 1818))
        self.assertEqual((1, -1, 34), utils.euclide_ext(509, 15))

    def test_inverse_modulaire(self):
        self.assertEqual(854, utils.inverse_modulaire(123, 4567))
        self.assertEqual(-1, utils.inverse_modulaire(612, -4516))
        self.assertEqual(-1, utils.inverse_modulaire(19191919, 4444))
        self.assertEqual(14, utils.inverse_modulaire(509, 15))

    def test_expo_modulaire(self):
        self.assertEqual(11, utils.expo_modulaire(13, 11, 19))
        self.assertEqual(173, utils.expo_modulaire(98, 17, 899))
        self.assertEqual(1, utils.expo_modulaire(18, -1, 899))

    def test_fast_expo_modulaire(self):
        self.assertEqual(11, utils.fast_expo_modulaire(13, 11, 19))
        self.assertEqual(173, utils.fast_expo_modulaire(98, 17, 899))
        self.assertEqual(1, utils.fast_expo_modulaire(18, -1, 899))

class Primalite(unittest.TestCase):
    def test_test_fermat(self):
        self.assertEqual(False, utils.test_fermat(4444, 100))
        self.assertEqual(True, utils.test_fermat(123457, 1000))
        self.assertEqual(False, utils.test_fermat(1234576, 1000))
        self.assertEqual(True, utils.test_fermat(12345769, 1000))
        self.assertEqual(False, utils.test_fermat(561, 1000))

    def test_q7_function(self):
        self.assertEqual(-1, utils.q7_fonction(5))
        self.assertEqual((4, 5), utils.q7_fonction(80))

    def test_test_rabin(self):
        self.assertEqual(False, utils.test_fermat(4444, 100))
        self.assertEqual(True, utils.test_fermat(123457, 1000))
        self.assertEqual(False, utils.test_fermat(1234576, 1000))
        self.assertEqual(True, utils.test_fermat(12345769, 1000))
        self.assertEqual(False, utils.test_fermat(561, 1000))

class RSA_test(unittest.TestCase):

    def test_encode_et_decode(self):
        message = "Nous nous appelons Sébastien et Aymeric"
        publique, privee = RSA.gen_rsa(512)
        message_encrypte = RSA.enc_rsa(message, publique)
        message_decrypte = RSA.dec_rsa(message_encrypte, publique, privee)
        self.assertEqual(message, message_decrypte)



if __name__ == '__main__':
    unittest.main()
