import utils
import secrets

"""
Fichier comportant les fonctions pour encoder le système RSA (partie 3)
"""

# Q9
"""
Les fonctions rsa et gen_rsa permettent de générer un couple de clé RSA
"""

def str_to_int(m):
    s = 0
    b = 1
    for i in range(len(m)):
        s += ord(m[i]) * b
        b *= 256
    return s


def int_to_str(c):
    s = ""
    q, r = divmod(c, 256)
    s = s + str(chr(r))
    while q != 0:
        q, r = divmod(q, 256)
        s += str(chr(r))
    return s

def rsa(p, q, l):
    n = p * q
    phi = (p - 1) * (q - 1)
    facteurCommun = True
    inverse = False
    while (inverse == False):
        e = secrets.randbits(l // 2)
        if (utils.pgcd(e, phi) == True):
            facteurCommun = False
        # e est l'exposent de chiffrement
        d = utils.inverse_modulaire(e, phi)  # exposant de déchiffrement
        if (d > 0 and d != e and e < phi and d < phi and facteurCommun == False):
            inverse = True
    return (n, e), d


def gen_rsa(l):
    valide = False
    while valide == False:
        p = secrets.randbits(l)
        q = secrets.randbits(l)

        a, b = False, False
        while (a == False) or (b == False):  # On cherche un nombre de 2048 bits qui pourrait être premier !

            if (a == False):
                if (utils.test_rabin(p, 25) == True):
                    a = True
                else:
                    p = secrets.randbits(l)
            if (b == False):
                if (utils.test_rabin(q, 25) == True):
                    b = True
                else:
                    q = secrets.randbits(l)
        return rsa(p, q, l)


# Q10 & 11

def enc_rsa(message, publique):
    """
    Encode un message en utilisant la clé publique
    :param message: un message (chaine de caractère)
    :param publique: une clé publique (généré avec gen_rsa())
    :return: le message encodé sous forme de tableau d'entier
    """
    n, e = publique
    m = str_to_int(message)
    return pow(m, e, n)


def dec_rsa(message, publique, privee):
    """
    Décode un message en utilisant la clé publique et privée
    :param message: un message (chaine de caractère)
    :param publique: une clé publique (générée avec gen_rsa())
    :param privee: uné clé privée (générée avec gen_rsa())
    :return: le message décodé sous forme de chaine de caractère
    """
    n, e = publique
    res = pow(message, privee, n)
    message = int_to_str(res)
    return message


# Q 12
def Q12_function():
    publique, privee = gen_rsa(512)
    print("La clé publique est", publique, "\nLa clé privée est", privee)
    message = "ceci est le message de la question 12"
    encode = enc_rsa(message, publique)
    print("L'encodage du message", message, "est", encode)
    print(dec_rsa(encode, publique, privee))