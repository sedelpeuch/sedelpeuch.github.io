package tec;

public class Autobus implements Vehicule {
    private int arret;
    private Jauge jaugeAssis;
    private Jauge jaugeDebout;
    private Passager[] passagers;

    /**
     Construit un autobus.
     Instancie les jauges et le tableau de passagers.
     Initialise l'arrêt.
     */
    public Autobus(int placesAssises, int placesDebout)
    {
        jaugeAssis = new Jauge(placesAssises,0);
        jaugeDebout = new Jauge(placesDebout,0);
        passagers = new Passager[placesDebout+placesAssises];
        arret = 0;
    }

    /**
     * Passe au prochain arrêt et prévient les passagers.
     * Incrémente arret.
     * Prévient tous les passagers qu'il s'agit d'un nouvel arrêt
     */

    @Override
    public void allerArretSuivant()
    {
        arret++;
        for(int i=0;i<passagers.length;i++)
        {
            if(passagers[i] != null)
            {
                passagers[i].nouvelArret(this,arret);
            }
        }
    }

    /**
     * Retourne si oui ou non il y a une place assise de disponible.
     */

    @Override
    public boolean aPlaceAssise()
    {
        return jaugeAssis.estVert();
    }

    /**
     * Retourne si oui ou non il y a une place debout de disponible.
     */

    @Override
    public boolean aPlaceDebout()
    {
        return jaugeDebout.estVert();
    }

    /**
     * Lorsqu'un passager de l'autobus est debout, il peut demander un siège.
     * S'il y a de la place, le passager la prend.
     * S'il n'existe pas, rien ne se passe.
     */

    @Override
    public void arretDemanderAssis(Passager p)
    {
        jaugeAssis.incrementer();
        jaugeDebout.decrementer();
        p.changerEnAssis();
    }

    /**
     * Lorsqu'un passager de l'autobus est assis, il peut demander à se lever.
     * S'il y a de la place, le passager se lève.
     * Sinon, rien ne se passe.
     */

    @Override
    public void arretDemanderDebout(Passager p)
    {
        jaugeAssis.decrementer();
        jaugeDebout.incrementer();
        p.changerEnDebout();
    }

    /**
     * Lorsqu'un passager demande à sortir, on actualise les jauges puis
     * on retire le passager du tableau de passagers.
     * Enfin, on actualise son état pour le mettre dehors.
     */

    @Override
    public void arretDemanderSortie(Passager p)
    {
        if(p.estDebout())
        {
            jaugeDebout.decrementer();
        }
        else if(p.estAssis())
        {
            jaugeAssis.decrementer();
        }
        int passager = chercherPassager(p);
        passagers[passager] = null;
        p.changerEnDehors();
    }

    /**
     * Lorsqu'un passager demande un siège en montant, on vérifie si un siège est
     * disponible.
     * Si c'est le cas, on actualise la jauge et on cherche un emplacement vide
     * dans le tableau de passager pour insérer le nouveau passager.
     * Enfin, on change son état en assis.
     * S'il n'y a pas de place, rien ne se passe.
     */

    @Override
    public void monteeDemanderAssis(Passager p)
    {
        jaugeAssis.incrementer();
        int emplacement = chercherEmplacementVide();
        passagers[emplacement] = p;
        p.changerEnAssis();
    }

    /**
     * Lorsqu'un passager demande à être debout en montant, on vérifie si de la
     * place est disponible.
     * Si c'est le cas, on actualise la jauge et on cherche un emplacement vide
     * dans le tableau de passager pour insérer le nouveau passager.
     * Enfin, on change son état en debout.
     * S'il n'y a pas de place, rien ne se passe.
     */

    @Override
    public void monteeDemanderDebout(Passager p)
    {
        jaugeDebout.incrementer();
        int emplacement = chercherEmplacementVide();
        passagers[emplacement] = p;
        p.changerEnDebout();
    }

    @Override
    public String toString(){
        return "[arret " + this.arret + "] assis" + jaugeAssis.toString() + " debout" + jaugeDebout.toString();
    }

    /**
     Cherche la place que le passager p occupe dans le tableau.
     */
    private int chercherPassager(Passager p)
    {
        for(int i=0; i<passagers.length; i++)
        {
            if(passagers[i] == p)
            {
                return i;
            }
        }
        return -1;
    }

    /**
     Retourne le premier emplacement vide dans le bus.
     S'il n'y en a pas, retourne -1.
     */
    private int chercherEmplacementVide()
    {
        return chercherPassager(null);
    }

}


