package tec;

public class PassagerStandard implements Passager{
    private String nom;
    private int destination;
    private Position position;
    
    public PassagerStandard(String nom, int destination){
        this.nom = nom;
        this.destination = destination;
        this.position = Position.DEHORS;
    }

    @Override
    public String nom(){
        return this.nom();
    }

    @Override
    public boolean estDehors(){
        return position.estDehors();
    }

    @Override
    public boolean estAssis(){
        return position.estAssis();
    }

    @Override
    public boolean estDebout(){
        return position.estDebout();
    }

    @Override
    public void changerEnDehors(){
        position = position.dehors();
    }

    @Override
    public void changerEnAssis(){
        position = position.assis();
    }

    @Override
    public void changerEnDebout(){
        position = position.debout();
    }

    @Override
    public void monterDans(Vehicule v){
        if(v.aPlaceAssise()) {
            v.monteeDemanderAssis(this);
        } else if(v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }

    @Override
    public void nouvelArret(Vehicule v, int numeroArret){
        if(destination <= numeroArret) {
            v.arretDemanderSortie(this);
        }
    }

    @Override
    public String toString(){
        return this.nom + " " + position.toString();
    }

}

