package tec;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

abstract class TestPassagerAbstrait {
  abstract protected PassagerAbstrait creerPassager(String nom, int destination);
  abstract public void testInstanciation();
  abstract public void testChoixPlaceMontee();
  abstract public void testChoixPlaceArret();

  public TestPassagerAbstrait() {}

  /* Gestion des changement d'état.
   *
   * Changer Debout puis Dehors puis assis.
   */
  public void testGestionEtat() {
    PassagerAbstrait p = creerPassager("yyy", 3);

    p.changerEnDebout();
    assert false == p.estAssis();
    assert true == p.estDebout();
    assert false == p.estDehors();

    p.changerEnDehors();
    assert false == p.estAssis();
    assert false == p.estDebout();
    assert true == p.estDehors();

    p.changerEnAssis();
    assert true == p.estAssis();
    assert false == p.estDebout();
    assert false == p.estDehors();
  }

  protected String getLastLog(FauxVehicule f) {
    return f.logs.get(f.logs.size() -1);
  }

  /**
   * Execute les tests pour une classe concrete heritant de TestPassagerAbstrait.
   * Cette solution contourne l'impossibilite d'heriter des methodes statiques en Java
   * et doit etre appelee par une classe concrete.
   * Alternativement, cette methode peut etre remplacee par TestRunner.runTestsForClass(),
   * qui decouvre les methodes de test a l'execution, sans utiliser l'heritage (mais ne
   * convient pas au TD5).
   * @param psgCl la classe concrete qui herite de TestPassagerAbstrait, sur laquelle
   *              executer les tests
   */
  protected static <T extends TestPassagerAbstrait> void runTests(Class<T> psgCl) throws NoSuchMethodException,
          IllegalAccessException, InvocationTargetException, InstantiationException {
    boolean estMisAssertion = false;
    assert estMisAssertion = true;

    Constructor<T> construct = psgCl.getConstructor();

    if (!estMisAssertion) {
      System.out.println("Execution impossible sans l'option -ea");
      return;
    }

    int nbTest = 0;

    //************ Verifier l'instanciation *************
    System.out.print('.'); nbTest++;
    construct.newInstance().testInstanciation();

    //********* Verifier changement d'etat **************
    System.out.print('.'); nbTest++;
    construct.newInstance().testGestionEtat();

    //********* Verifier les interactions  *************
    System.out.print('.'); nbTest++;
    construct.newInstance().testChoixPlaceMontee();

    System.out.print('.'); nbTest++;
    construct.newInstance().testChoixPlaceArret();

    System.out.println("(" + nbTest + "):OK: " + psgCl.getName());
  }
}
