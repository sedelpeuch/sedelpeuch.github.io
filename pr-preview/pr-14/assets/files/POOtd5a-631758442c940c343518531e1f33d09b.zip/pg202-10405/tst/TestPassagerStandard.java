package tec;


import java.lang.reflect.InvocationTargetException;

class TestPassagerStandard extends TestPassagerAbstrait {
    public static void main(String[] args) throws IllegalAccessException,
            InstantiationException, NoSuchMethodException, InvocationTargetException {
        // Test Runner
        // tec.TestRunner.runTestsForClass(TestPassagerStandard.class);
        // Solution TD5
        TestPassagerAbstrait.runTests(TestPassagerStandard.class);
    }

    protected PassagerAbstrait creerPassager(String nom, int destination) {
        return new tec.PassagerStandard(nom, destination);
    }

    public TestPassagerStandard() {}

    /* Etat apres instanciation
     * Un seul cas
     */
    public void testInstanciation() {
        PassagerAbstrait p = creerPassager("xxx", 3);

        assert false == p.estAssis();
        assert false == p.estDebout();
        assert true == p.estDehors();
    }

    /* Interaction a la montee
     * Trois cas
     *  - des places assises et debout
     *  - pas de place assise
     *  - aucune place.
     */
    public void testChoixPlaceMontee() {
        PassagerAbstrait p = creerPassager("yyy", 5);

        FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);
        p.monterDans(faux);

        assert "monteeDemanderAssis" == getLastLog(faux) : "assis";

        faux = new FauxVehicule(FauxVehicule.DEBOUT);
        p.monterDans(faux);

        assert "monteeDemanderDebout" == getLastLog(faux) : "debout";

        faux = new FauxVehicule(FauxVehicule.PLEIN);
        p.monterDans(faux);

        assert 0 == faux.logs.size() : "pas de place";
    }

    /* Interaction a un arret
     * Deux cas
     *  - numero d'arret < a la destination
     *  - numero d'arret >= a la destination
     */
    public void testChoixPlaceArret() {
        PassagerAbstrait p = creerPassager("yyy", 5);

        FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

        p.nouvelArret(faux, 1);
        assert 0 == faux.logs.size() : "pas a destination";

        p.nouvelArret(faux, 5);
        assert "arretDemanderSortie" == getLastLog(faux) : "destination";
    }
}
