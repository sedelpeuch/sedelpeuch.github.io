#include"thread.h"
#include <stdio.h>
#include <sys/queue.h>
#include <ucontext.h>

struct thread_entry* current_thread;
struct thread_queue* waiting_threads_head;

struct thread_entry {
    ucontext_t context;
    void* ret_val;
    STAILQ_ENTRY(thread_entry) entries;    /* Tail queue. */
};

STAILQ_HEAD(thread_queue, thread_entry) waiting_threads =
        STAILQ_HEAD_INITIALIZER(waiting_threads);

/**
 * Initializes the thread queue
 */
__attribute__((unused)) __attribute__((constructor)) void initialize() {
    STAILQ_INIT(&waiting_threads);                     /* Initialize the queue. */
    /* current_thread = thread_create(thread_t *newthread, void *(*func)(void *), void *funcarg) */
}

__attribute__((unused)) __attribute__((destructor)) void destroy() {

}

/* recuperer l'identifiant du thread courant.
 */
thread_t thread_self(void){return current_thread;}

/* creer un nouveau thread qui va exécuter la fonction func avec l'argument funcarg.
 * renvoie 0 en cas de succès, -1 en cas d'erreur.
 */
int thread_create(thread_t *newthread, void *(*func)(void *), void *funcarg){return 0;}

/* passer la main à un autre thread.
 */
int thread_yield(void) {
  STAILQ_INSERT_TAIL(&waiting_threads, current_thread, entries);
  current_thread = STAILQ_FIRST(&waiting_threads);
  STAILQ_REMOVE_HEAD(&waiting_threads, entries);
}

/* attendre la fin d'exécution d'un thread.
 * la valeur renvoyée par le thread est placée dans *retval.
 * si retval est NULL, la valeur de retour est ignorée.
 */
int thread_join(thread_t thread, void **retval){return 0;}

/* terminer le thread courant en renvoyant la valeur de retour retval.
 * cette fonction ne retourne jamais.
 *
 * L'attribut noreturn aide le compilateur à optimiser le code de
 * l'application (élimination de code mort). Attention à ne pas mettre
 * cet attribut dans votre interface tant que votre thread_exit()
 * n'est pas correctement implémenté (il ne doit jamais retourner).
 */
void thread_exit(void *retval)/*__attribute__ ((__noreturn__))*/{}

int thread_mutex_init(thread_mutex_t *mutex){return 0;}
int thread_mutex_destroy(thread_mutex_t *mutex){return 0;}
int thread_mutex_lock(thread_mutex_t *mutex){return 0;}
int thread_mutex_unlock(thread_mutex_t *mutex){return 0;}
