import subprocess
import matplotlib.pyplot as plt
import time
import argparse
import numpy as np
import os
import re


# Run test received in parameter.
# Use this function to create a boxplot graph.
# flags             : flags used at execution
# test_path         : path of the test
# test_args         : array of parameters for the current test
# is_parallel       : boolean to know if we want to use parallelism
def boxplot(flags, test_path, test_args, is_parallel):
    # Array to store results
    res_array = np.array([])

    for i in range(0, args.it):
        begin = time.time()
        if is_parallel:
            subprocess.run([test_path], stdout=subprocess.DEVNULL, env={'LD_LIBRARY_PATH': flags})
        else:
            subprocess.run(['taskset', '-c', '0', test_path], stdout=subprocess.DEVNULL, env={'LD_LIBRARY_PATH': flags})

        end = time.time()

        res_array = np.append(res_array, end - begin)

    return res_array


# Run test received in parameter.
# Use this function to create a line graph.
# flags             : flags used at execution
# test_path         : path of the test
# test_args         : array of parameters for the current test
# is_parallel       : boolean to know if we want to use parallelism
def lineplot(flags, test_path, test_args, is_parallel):
    # Transform the list of arguments into a single string
    delim = ' '
    inline_args = delim.join(test_args[1:])

    # Array to store the value of multiple execution for the same number of thread
    median_array = np.array([])
    res_array = np.array([])

    #if test_args[0] < args.step:
    #    args.step = 1

    for i in range(1, test_args[0], args.step):
        for j in range(0, args.it):
            begin = time.time()
            if is_parallel:
                subprocess.run(['taskset', '-c', '0-23', test_path, str(i), inline_args],
                            stdout=subprocess.DEVNULL, env={'LD_LIBRARY_PATH': flags})
            else:
                subprocess.run(['taskset', '-c', '0', test_path, str(i), inline_args],
                           stdout=subprocess.DEVNULL, env={'LD_LIBRARY_PATH': flags})

            end = time.time()

            median_array = np.append(median_array, end - begin)

        # Store the median into the result array
        res_array = np.append(res_array, np.median(median_array))

    return res_array


# Display the graph thanks to the array computed by boxplot or lineplot
# res_array         : array of result arrays
# res_labels        : array of label for each result array
# plot_type         : the wanted type of graph
# test_name         : name of the current test
# test_args         : array of parameters for the current test
def display(res_array, res_labels, plot_type, test_name, test_args):
    plt.figure()
    plt.ylabel('Time in second')

    if plot_type == boxplot:
        plt.title('Execution time for test ' + test_name + '\n depending on which library is used\n' + str(
            args.it) + ' iterations\n' + MACHINE)
        plt.boxplot(res_array, sym='', labels=res_labels)
        plt.grid(True, axis='y')

    elif plot_type == lineplot:
        # Create abscissa array, which is the number of thread used for each test.
        number_of_thread_array = np.arange(0, test_args[0], args.step)

        plt.title(
            'Execution time for test ' + test_name + '\n depending on which library is used and how many threads are used\n' + str(
                args.it) + ' iterations\n' + MACHINE)
        if test_name == '152-divide-and-conquer-sum' or test_name == '153-divide-and-conquer-sort':
            plt.xlabel('Number of array elements')
        else:
            plt.xlabel('Number of threads created')
        for i in range (0, len(res_array)):
            plt.plot(number_of_thread_array, res_array[i], label=res_labels[i])
        plt.legend()

    else:
        print('Incorrect plot type !')
        exit(1)

    plt.show()

# Run one test
def run_one(test_number, test_value):
    # Function name to execute to have a boxplot or line graph
    plot_type = test_value[0]
    test_args = test_value[1]
    run_paths = []

    res_array = [[], [], []]

    global_index = 0
    for branch in BRANCH_NAME_PARALLEL:
        run_paths = []
        is_parallel = 0
        subprocess.call('make clean', shell=True)
        subprocess.call('git checkout ' + branch, shell=True)

        # Get file path depending on the test number
        cmd = f"ls ./tests/{test_number}*"
        src_paths = os.popen(cmd).read().split(".c")[:-1]

        # Get the test name
        test_name = re.findall('[0-9]{2,}.*', src_paths[0])[0]
        run_paths.append('./build/bin/' + test_name)

        if branch is 'master':
            run_paths.append('./build/bin/' + test_name + '-pthread')
            is_parallel = 1

        for i in range (0, len(run_paths)):
            subprocess.call('make ' + run_paths[i], shell=True)
            res_array[global_index] = plot_type(LIBTHREAD_PATH, run_paths[i], test_args, is_parallel)
            global_index += 1

    seq_last_val = res_array[0][-1]
    para_last_val = res_array[1][-1]
    print("Speedup = sequential / paralell\n", seq_last_val, " / ", para_last_val, " = ", seq_last_val / para_last_val)
    display(res_array, ['sequential version', 'parallel version', 'pthread version'], plot_type, test_name, test_args)


# Run all tests
def run_all():
    for test_number, test_value in ALL_TESTS.items():
        run_one(test_number, test_value)


def main(args):
    # By default run all tests
    if args.file is None:
        run_all()

    test_args = ALL_TESTS.get(args.file)
    if test_args is None:
        print('Unknown test')
        exit(1)
    else:
        run_one(args.file, test_args)

# Parser
parser = argparse.ArgumentParser()
parser.add_argument('-f', dest='file', help='Test to run')
parser.add_argument('-i', dest='it', default=50, type=int, help='Number of iteration')
parser.add_argument('-t', dest='max_nb_threads', type=int, help='Max number of threads')
parser.add_argument('-y', dest='nb_yield_max', default='10', help='Max number of yield')
parser.add_argument('-s', dest='step', default=20, type=int, help='Step for iteration on threads')
args = parser.parse_args()

# Global vars
LIBTHREAD_PATH = 'build/lib'
TASKSET_VALUE = ''
DEFAULT_NB_THREAD = 260
BRANCH_NAME_PARALLEL = ['sequential', 'master']
MACHINE = "CPU specs : "

if args.max_nb_threads is not None:
    DEFAULT_NB_THREAD = args.max_nb_threads

ALL_TESTS = {'01': [boxplot, []],
             '02': [boxplot, []],
             '11': [boxplot, []],
             '12': [boxplot, []],
             '21': [lineplot, [DEFAULT_NB_THREAD]],
             '22': [lineplot, [DEFAULT_NB_THREAD]],
             '23': [lineplot, [DEFAULT_NB_THREAD]],
             '31': [lineplot, [DEFAULT_NB_THREAD, args.nb_yield_max]],
             '32': [lineplot, [DEFAULT_NB_THREAD, args.nb_yield_max]],
             '33': [lineplot, [DEFAULT_NB_THREAD, args.nb_yield_max]],
             '51': [lineplot, [40 if args.max_nb_threads is None else DEFAULT_NB_THREAD]],
             '152':[lineplot, [DEFAULT_NB_THREAD]],
             '153':[lineplot, [DEFAULT_NB_THREAD]],
             }

main(args)