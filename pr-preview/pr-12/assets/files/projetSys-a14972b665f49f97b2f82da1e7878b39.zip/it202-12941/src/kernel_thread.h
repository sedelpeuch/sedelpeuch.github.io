#ifndef KERNEL_THREAD_H
#define KERNEL_THREAD_H

#include <stdlib.h>
#include <assert.h>
#include <pthread.h>
#include <semaphore.h>
#include "log.h"
#include "context.h"
#include "globals.h"

#ifndef NB_KERNEL_THREADS
#define NB_KERNEL_THREADS 8
#endif

/**
 * The context used to find a new user thread at startup or after a thread_exit()
 */
__thread struct context kernel_thread_next_user_thread_context;

/**
 * The context used to unlock runq & yield to the next user thread in thread_yield()
 */
__thread struct context kernel_thread_yield_context;

/**
 * The pthread identifier of each non-initial kernel thread
 */
pthread_t non_init_kernel_threads[NB_KERNEL_THREADS - 1];

/**
 * The number of kernel thread blocked in kernel_thread_next_user_thread()
 */
struct atomic_counter waiting_kernel_threads = { .lock = 0, .counter = 0 };

/**
 * Used by thread_exit to tell kernel_thread_next_user_thread to unlock
 * last_user_thread_lock, if necessary.
 * @see kernel_thread_next_user_thread
 */
__thread int need_to_unlock_last_user_thread = 0;
/**
 * The lock which protects last_user_thread
 */
int last_user_thread_lock = 0;
/**
 * The last user thread that exited, which is destroyed in end_context_func.
 */
struct thread_entry* last_user_thread = NULL;

/**
 * The current user thread of each kernel thread
 */
__thread struct thread_entry* current_thread = NULL;
/**
 * The thread joined by current_thread, used to release
 * the lock acquired in thread_join().
 * @see kernel_thread_next_user_thread
 */
__thread struct thread_entry* thread_to_wait_to_unlock = NULL;
__thread int is_initial_kernel_thread = 0;


__attribute__((__noreturn__)) static inline void kernel_thread_destroy() {
    INFONOSELF("Destroying kernel thread");

    if (!is_initial_kernel_thread) {
        INFONOSELF("End of non-initial kernel thread");
        pthread_exit(NULL);
    }

    INFONOSELF("Waiting for other kernel threads to exit");

    for (size_t i = 0; i < NB_KERNEL_THREADS - 1; i++) {
        DEBUGNOSELF("Join?");
        // err is unused when asserts are disabled
        __attribute__((unused)) int err = pthread_join(non_init_kernel_threads[i], NULL);
        INFOLUNOSELF("Joined", non_init_kernel_threads[i]);
        assert(!err);
    }

    INFONOSELF("End of initial kernel thread");

    setcontext(&end_context.ucontext); // Should not return
    assert(0);
    pthread_exit((void*) -1);
}

/**
 * Unlock the runq & yield to another kernel thread
 */
__attribute__((__noreturn__)) static inline void kernel_thread_yield_user_thread() {
    DEBUGNOSELF("Kernel thread in intermediate yield context");
    assert(current_thread != NULL);

    // The lock was acquired in thread_yield
    atomic_unlock(&runq_lock);
    DEBUGNOSELF("Yield to next user thread");
    __attribute__((__unused__)) int err = setcontext(&current_thread->context.ucontext); // Should not return
    ERR("Error setting current_thread context in yield context");
    assert(!err);

    pthread_exit((void*) -1);
}

/**
 * Wait for another user thread in runq.
 * When every kernel thread is blocked in this function, exit the program.
 */
__attribute__((__noreturn__)) static inline void kernel_thread_next_user_thread() {
    // Release the lock acquired my thread_exit.
    // This lock makes sure that at the end of the program,
    // last_user_thread is the last user thread, which must
    // be freed by end_context_func.
    if (need_to_unlock_last_user_thread) {
        atomic_unlock(&last_user_thread_lock);
        need_to_unlock_last_user_thread = 0;
    }

    // If the current_thread has exited or is joined, we need to release
    // the lock on it.
    if (current_thread != NULL) {
        DEBUG("Unlocking current_thread status");
        atomic_unlock(&current_thread->status_lock);
    }

    // Used in thread_join(), when we need to unlock the waited thread as well as the current_thread
    if (thread_to_wait_to_unlock != NULL) {
        DEBUG("Unlocking thread_to_wait_to_unlock status");
        atomic_unlock(&thread_to_wait_to_unlock->status_lock);
        thread_to_wait_to_unlock = NULL;
    }

    // This variable is used to check if the kernel thread did at least one iteration
    // without getting a user thread.
    // In this situation, the kernel thread writes increments `waiting_kernel_threads.counter`.
    // If `waiting_kernel_threads.counter == NB_KERNEL_THREAD`, then every kernel thread is blocked:
    // there is no remaining user thread in the runq.
    int has_failed_getting_thread = 0;

    INFO("Kernel thread waiting for a new user thread");

    // Define the timeout of `sem_timedwait`
    struct timespec sem_timeout = {
            .tv_nsec = 1,
    };

    // While at least one thread has a thread to run
    while(waiting_kernel_threads.counter < NB_KERNEL_THREADS) {
        // Wait for a new user thread in the runq
        if (sem_timedwait(&runq_length, &sem_timeout) == 0) {
            // The runq is not empty: we can get our user thread

            // Try to lock the runq to get the user thread
            atomic_lock(&runq_lock); {
                // We can get a user thread
                current_thread = STAILQ_FIRST(&runq);
                INFOP("Kernel thread got a new user thread", current_thread);

                STAILQ_REMOVE_HEAD(&runq, entries);

                // We are going to setcontext, we must unlock everything
                atomic_unlock(&runq_lock);

                // Tell the other threads we're no longer waiting
                if (has_failed_getting_thread) {
                    atomic_counter_lock(&waiting_kernel_threads);
                    atomic_counter_decrement(&waiting_kernel_threads);
                    atomic_counter_unlock(&waiting_kernel_threads);
                }

                DEBUG("Running the next thread");
                setcontext(&current_thread->context.ucontext);
            } atomic_unlock(&runq_lock);
        } else {
            // The kernel thread failed to get a user thread.
            // If every other kernel thread is in the same situation, the loop must end:
            //   there is no user thread remaining
            if (!has_failed_getting_thread) {
                INFO("Failed to get a user thread (first failure)");
                has_failed_getting_thread = 1;

                atomic_counter_lock(&waiting_kernel_threads);
                atomic_counter_increment(&waiting_kernel_threads);
                atomic_counter_unlock(&waiting_kernel_threads);
            }
        }
    }

    // Every kernel thread failed getting a new user thread
    kernel_thread_destroy();
}


static inline void kernel_thread_initialize_yield_context() {
    context_initialize(&kernel_thread_yield_context);
    makecontext(&kernel_thread_yield_context.ucontext,
                (void (*)(void)) kernel_thread_yield_user_thread,
                0,
                NULL);
}

static inline void kernel_thread_initialize_get_user_thread_context() {
    context_initialize(&kernel_thread_next_user_thread_context);
    makecontext(&kernel_thread_next_user_thread_context.ucontext,
                (void (*)(void)) kernel_thread_next_user_thread,
                0,
                NULL);
}

/**
 * Initialize a kernel thread.
 * Function executed at startup (pthread_create).
 */
void kernel_thread_entrypoint() {
    INFO("Start of new kernel thread");
    kernel_thread_initialize_get_user_thread_context();
    kernel_thread_initialize_yield_context();
    setcontext(&kernel_thread_next_user_thread_context.ucontext);
}

#endif //KERNEL_THREAD_H
