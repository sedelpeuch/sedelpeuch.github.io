#include "thread.h"
#include "queue.h"
#include "log.h"
#include "atomic.h"
#include "context.h"
#include "globals.h"
#include "kernel_thread.h"
#include <ucontext.h>
#include <stdlib.h>
#include <assert.h>
#include <pthread.h>
#include <semaphore.h>

// main() prototype that is used to create the initial main thread
int main(int argc, char** argv);

/**
 * The value returned by main()
 */
int main_ret_val;

static inline void thread_initialize(struct thread_entry* thread);
static inline void thread_destroy(struct thread_entry* thread);

int end_context_func() {
    WARNNOSELF("Running ending context, bye");

    // Run by the first kernel thread
    assert(last_user_thread);
    thread_destroy(last_user_thread);

    sem_destroy(&runq_length);
    return main_ret_val;
}

/**
 * Prevent the main from destroying the initial kernel thread when its returns without thread_exit().
 * Instead, the kernel thread waits for another user thread in the runq.
 * @see kernel_thread_next_user_thread
 */
void main_wrapper(int argc, char** argv) {
    INFO("Call to main wrapper");
    main_ret_val = main(argc, argv);
    DEBUG("Back to main wrapper");

    INFO("Exiting main & trying to get another user thread");
    thread_exit(&main_ret_val);
}

/**
 * Endpoint called at library loading.
 * Initialize structures and create a main thread.
 */
__attribute__((unused)) __attribute__((constructor)) void initialize(int argc, char** argv) {
    LOG_HEADER;
    INFO("Constructor call");
    STAILQ_INIT(&runq);
    sem_init(&runq_length,
             0, // semaphore shared between kernel threads
             0);

    struct thread_entry* thread = malloc(sizeof(struct thread_entry));
    INFOP("Create thread", thread);
    getcontext(&thread->context.ucontext);
    thread_initialize(thread); // Locked by default

    // makecontext wraps function `wrapped_func` of args `wrapped_func_args` into `main_func`
    makecontext(&thread->context.ucontext, (void (*)(void)) main_wrapper, 2, argc, argv);
    thread->status_lock = 0; // Unlock

    STAILQ_INSERT_TAIL(&runq, thread, entries);
    sem_post(&runq_length);

    // Create a main context
    is_initial_kernel_thread = 1;

    getcontext(&end_context.ucontext);
    end_context.ucontext.uc_stack.ss_size = STACK_SIZE;
    end_context.ucontext.uc_stack.ss_sp = &end_context.ss_sp;
    end_context.valgrind_stack_id = VALGRIND_STACK_REGISTER(end_context.ucontext.uc_stack.ss_sp,
                                                            end_context.ucontext.uc_stack.ss_sp
                                                            + end_context.ucontext.uc_stack.ss_size);
    makecontext(&end_context.ucontext, (void (*)(void)) end_context_func, 1, NULL);

    kernel_thread_initialize_get_user_thread_context();
    kernel_thread_initialize_yield_context();

    // Create other kernel threads
    for (size_t i = 0; i < NB_KERNEL_THREADS - 1; i++) {
        pthread_create(&non_init_kernel_threads[i], NULL, (void* (*)(void*)) kernel_thread_entrypoint, NULL);
    }

    // Try to get its first kernel thread
    // We do not set the thread into current_thread to avoid deadlocks with already-created kernel threads,
    // when the main thread is joined by a child.
    setcontext(&kernel_thread_next_user_thread_context.ucontext);
}

/**
 * Deallocate a thread
 * @param thread A malloc'd thread structure
 */
static inline void thread_destroy(struct thread_entry* thread) {
    assert(thread != NULL);

    VALGRIND_STACK_DEREGISTER(thread->context.valgrind_stack_id);
    DEBUG("Destroy a thread");
    free(thread);
}

/**
 * Recuperer l'identifiant du thread courant.
 */
thread_t thread_self(void) {
    assert((LOG_MODE >= 3) || (current_thread != NULL) );
    return current_thread;
}

/**
 * Function wrapper used to create contexts that call `thread_exit()` implicitly.
 * If the wrapped function already exits with `thread_exit()`, the wrapper does not `thread_exit()`
 * once again since `thread_exit()` does not return.
 */
void thread_function_wrapper(void* wrapped_func, void* wrapped_args) {
    INFOP("Call to user thread function wrapper, with wrapped function of address: ", wrapped_func);
    assert(wrapped_func != NULL);
    void* (*w_func)(void*) = wrapped_func;
    void* ret_value = w_func(wrapped_args);

    INFO("Back to user thread function wrapper");
    thread_exit(ret_value);
}

/**
 * Initialize most fields of `thread` with default values
 * @see thread_create
 * @see thread_function_wrapper
 */
static inline void thread_initialize(struct thread_entry* thread) {
    INFOP("Initialize thread", thread);
    assert(thread != NULL);

    // Context initialization
    thread->context.ucontext.uc_stack.ss_size = STACK_SIZE;
    thread->context.ucontext.uc_stack.ss_sp = &thread->context.ss_sp;
    thread->context.valgrind_stack_id = VALGRIND_STACK_REGISTER(thread->context.ucontext.uc_stack.ss_sp,\
                            thread->context.ucontext.uc_stack.ss_sp + thread->context.ucontext.uc_stack.ss_size);
    thread->joining_thread = NULL;
    thread->exited = 0;
    thread->ret_val = NULL;
    thread->status_lock = 1; // Locked by default, to avoid joins on uninitialized threads (unlocked after thread_create)
    DEBUGP("Thread initialized", thread);
}

/**
 * Creer un nouveau thread qui va exécuter la fonction func avec l'argument funcarg.
 * renvoie 0 en cas de succès, -1 en cas d'erreur.
 * @see thread_function_wrapper
 * @see thread_initialize
 */
int thread_create(thread_t *newthread, void *(*func)(void *), void *funcarg) {
    struct thread_entry* thread = malloc(sizeof(struct thread_entry));
    *newthread = (thread_t) thread; // newthread must be initialized ASAP to avoid joins on uninitialized threads

    INFOP("Create thread", thread);
    assert(newthread != NULL);
    getcontext(&thread->context.ucontext);

    thread_initialize(thread); // The thread is locked by default to avoid early joins

    // makecontext wraps function `wrapped_func` of args `wrapped_func_args` into `main_func`
    assert(func != NULL);
    makecontext(&thread->context.ucontext, (void (*)(void)) thread_function_wrapper, 2, func, funcarg);

    atomic_lock(&runq_lock);
    STAILQ_INSERT_TAIL(&runq, thread, entries);
    atomic_unlock(&thread->status_lock); // Thread was locked by default
    atomic_unlock(&runq_lock);
    sem_post(&runq_length); // Another kernel thread will be able to take the user thread

    return 0; // TODO: handle errors
}

/**
 * Passer la main à un autre thread.
 */
int thread_yield(void) {
    INFO("Yielding");
    assert(current_thread != NULL);
    struct thread_entry* yielding_thread = current_thread;

    // Try to read NULL without taking the lock:
    // if the runq is NULL, we can avoid to take the lock and consider
    // we don't have to swap context.
    // Even if the content we read was invalid, we don't care:
    // we just want to read NULL or something else.
    struct thread_entry* next_thread = STAILQ_FIRST(&runq);

    // If there is only one thread, no need to swap contexts
    if (next_thread == NULL) {
        DEBUG("runq is empty, no need to swap contexts or lock");
        return 0;
    }

    // The runq seems not to be empty: take the lock
    atomic_lock(&runq_lock);

    // Read again (atomically)
    next_thread = STAILQ_FIRST(&runq);

    // The runq could still be empty
    // If there is only one thread, no need to swap contexts
    if (next_thread == NULL) {
        DEBUG("runq is empty, no need to swap contexts (took lock)");
        atomic_unlock(&runq_lock);
        return 0;
    }

    DEBUG("runq is not empty, yielding");
    assert(yielding_thread != next_thread);

    TRACE("Popping first thread & Inserting current_thread back to runq");
    STAILQ_INSERT_TAIL(&runq, current_thread, entries);
    current_thread = next_thread;
    STAILQ_REMOVE_HEAD(&runq, entries);

    assert(!yielding_thread->exited);
    assert(current_thread);

    // The runq lock *must* be released outside this context to prevent this context
    // from being destroyed too early.
    // The kernel_thread_yield_context context will release the lock & yield to the next user thread.
    __attribute__((__unused__)) int err =
            swapcontext(&yielding_thread->context.ucontext, &kernel_thread_yield_context.ucontext);
    assert(!err);

    DEBUG("Back to yield");
    return 0;
}

/**
 * Attendre la fin d'exécution d'un thread.
 * La valeur renvoyée par le thread est placée dans *retval.
 * Si retval est NULL, la valeur de retour est ignorée.
 */
int thread_join(thread_t thread, void **retval) {
    INFOP("Joining thread", thread);
    struct thread_entry* joining_thread = current_thread;

    struct thread_entry* thread_to_wait = (struct thread_entry*) thread;
    assert(joining_thread != NULL);
    assert(thread_to_wait != NULL);
    assert(joining_thread != thread_to_wait);

    // Lock the thread to wait
    atomic_lock(&thread_to_wait->status_lock);

    if (thread_to_wait->joining_thread != NULL && thread_to_wait->joining_thread != current_thread) {
        atomic_unlock(&thread_to_wait->status_lock);
        return -1;
    }

    // The waited thread has exited already: get the return value and free the thread structure
    if (thread_to_wait->exited) {
        if (retval != NULL) {
            *retval = thread_to_wait->ret_val;
        }
        DEBUGP("This thread has exited already: free", thread_to_wait);

        atomic_unlock(&thread_to_wait->status_lock);

        thread_destroy(thread_to_wait);
        return 0;
    }

    DEBUGP("The waited thread has not exited yet", thread_to_wait);
    assert(!thread_to_wait->exited);

    // The waited thread has not exited yet
    // Go to sleep: the waited thread will awake us at exit
    assert(thread_to_wait->joining_thread == NULL);
    thread_to_wait->joining_thread = joining_thread;

    thread_to_wait_to_unlock = thread_to_wait; // Lock will be released in kernel_thread_next_user_thread()

    atomic_lock(&joining_thread->status_lock); // We need to lock before swapcontext

    // Try to get a new user thread
    __attribute__((__unused__)) int err = swapcontext(&joining_thread->context.ucontext,
                                                      &kernel_thread_next_user_thread_context.ucontext);
    assert(!err);


    // The waited_thread has awaken us

    // Restore current_thread
    current_thread = joining_thread;

    DEBUG("Back to join");
    assert(thread_to_wait->exited);

    if (retval != NULL) {
        *retval = thread_to_wait->ret_val;
    }

    atomic_unlock(&thread_to_wait->status_lock); // Lock on thread_to_wait->status_lock was acquired in thread_exit()

    thread_destroy(thread_to_wait);

    atomic_unlock(&joining_thread->status_lock); // Lock on joining_thread->status_lock was acquired in thread_exit()

    return 0;
}

/**
 * Terminer le thread courant en renvoyant la valeur de retour retval.
 * Cette fonction ne retourne jamais.
 *
 * L'attribut noreturn aide le compilateur à optimiser le code de
 * l'application (élimination de code mort). Attention à ne pas mettre
 * cet attribut dans votre interface tant que votre thread_exit()
 * n'est pas correctement implémenté (il ne doit jamais retourner).
 */
__attribute__((__noreturn__)) void thread_exit(void *retval) {
    INFO("Exiting thread");
    __attribute__((__unused__)) int err;
    struct thread_entry* exiting_thread = current_thread;

    assert(exiting_thread != NULL);

    atomic_lock(&exiting_thread->status_lock);
    // The return value is stored so that the joining thread could retrieve it
    exiting_thread->ret_val = retval;
    exiting_thread->exited = 1;

    // If someone is already waiting for me
    if (exiting_thread->joining_thread != NULL) {
        DEBUG("Someone is already waiting for me");
        current_thread = exiting_thread->joining_thread;
        DEBUG("Awakening the joining thread");
        assert(!current_thread->exited);

        atomic_lock(&current_thread->status_lock); // joining_thread must be in a coherent context before swapcontext

        // Lock are not released here: it is done in the joining thread
        err = setcontext(&current_thread->context.ucontext);
    } else { // Some thread might join me later, my structure will be deallocated in thread_join()
        DEBUG("Nobody is waiting for me (yet)");

        // exiting_thread->status_lock MUST be unlocked in kernel_thread_next_user_thread_context,
        // otherwise the joining thread could kill this context before the setcontext.

        // We might be the last thread to exit
        // At the end of the program, last_user_thread is the last kernel thread to exit
        // and must be freed
        atomic_lock(&last_user_thread_lock); // Released in kernel_thread_next_user_thread
        last_user_thread = current_thread;
        need_to_unlock_last_user_thread = 1;

        err = setcontext(&kernel_thread_next_user_thread_context.ucontext); // Does not return

        atomic_unlock(&last_user_thread_lock); // Just in case setcontext fails
        ERR("Run a context of a thread that exited");
    }

    assert(!err);
    pthread_exit((void*) -1);
}

int thread_mutex_init(thread_mutex_t *mutex){return 0;}
int thread_mutex_destroy(thread_mutex_t *mutex){return 0;}
int thread_mutex_lock(thread_mutex_t *mutex){return 0;}
int thread_mutex_unlock(thread_mutex_t *mutex){return 0;}
