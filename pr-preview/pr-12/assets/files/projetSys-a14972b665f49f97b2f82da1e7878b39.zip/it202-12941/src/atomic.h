#ifndef ATOMIC_H
#define ATOMIC_H

#include "log.h"

struct atomic_counter {
    int lock;
    int counter;
};


static inline void atomic_lock(int* lock) {
    TRACEP("(L)", lock);
    while (!__sync_bool_compare_and_swap(lock, 0, 1));
    TRACEP("(LOK)", lock);
}

static inline void atomic_unlock(int* lock) {
    TRACEP("(U)", lock);
    *lock = 0;
    TRACEP("(UOK)", lock);
}

static inline int atomic_counter_lock(struct atomic_counter* alc) {
    atomic_lock(&alc->lock);
    TRACEI("(L) Count:", alc->counter);
    return alc->counter;
}

static inline void atomic_counter_unlock(struct atomic_counter* alc) {
    TRACEI("(U) Count:", alc->counter);
    atomic_unlock(&alc->lock);
}

static inline int atomic_counter_fetch(struct atomic_counter* alc) {
    return alc->counter;
}

static inline void atomic_counter_increment(struct atomic_counter* alc) {
    alc->counter++;
}

static inline void atomic_counter_decrement(struct atomic_counter* alc) {
    alc->counter--;
}

#endif //ATOMIC_H
