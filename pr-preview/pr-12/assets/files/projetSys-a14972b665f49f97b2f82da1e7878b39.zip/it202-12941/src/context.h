#ifndef CONTEXT_H
#define CONTEXT_H

#ifndef STACK_SIZE
#define STACK_SIZE (64*1024)
#endif

#include <valgrind/valgrind.h>
#include <ucontext.h>

/**
 * A structure that contains all information concerning a context
 */
struct context{
    ucontext_t ucontext;                 ///< Structure used to switch between contexts.
    char ss_sp[STACK_SIZE];              ///< Stack used by context. This is not the real type of ss_sp,
    int valgrind_stack_id;               ///< Used to help Valgrind keep track of memory errors in stack.
};

static inline void context_initialize(struct context* context) {
    getcontext(&context->ucontext);
    context->ucontext.uc_stack.ss_size = STACK_SIZE;
    context->ucontext.uc_stack.ss_sp = &context->ss_sp;
    context->valgrind_stack_id =
            VALGRIND_STACK_REGISTER(context->ucontext.uc_stack.ss_sp,
                                    context->ucontext.uc_stack.ss_sp
                                    + context->ucontext.uc_stack.ss_size);
}

#endif //CONTEXT_H
