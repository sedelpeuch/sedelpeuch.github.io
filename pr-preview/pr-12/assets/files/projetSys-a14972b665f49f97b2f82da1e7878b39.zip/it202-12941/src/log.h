#ifndef CODE_LOG_H
#define CODE_LOG_H

/**
 * @file Provide log macros.
 * Different levels of verbosity are available, depending on LOG_MODE:
 * - ERR(msg) if LOG_MODE >= 1
 * - WARN(msg) if LOG_MODE >= 2
 * - INFO(msg) if LOG_MODE >= 3
 * - TRACE(msg) if LOG_MODE >= 4
 */

#if LOG_MODE >= 1
#include <stdio.h>
    #define LOG_HEADER (fprintf(stderr, "%s   |   %s   |   %s   | %s%45s | %s\n", "Type", "Kern. Thread ID",\
        "User Thread ID", "Issuer", "", "Message"))
    #define LOGGER(mode, msg) (fprintf(stderr, "%4s   |   %15lu   |   %14p   | %-s:%-32sl. %-3d\t| %s\n", mode, pthread_self(),\
        thread_self(), __FILE__, __func__, __LINE__, msg))
    #define LOGGERP(mode, msg, ptr) (fprintf(stderr, "%4s   |   %15lu   |   %14p   | %-s:%-32sl. %-3d\t| %s (%p)\n", mode,\
        pthread_self(), thread_self(), __FILE__, __func__, __LINE__, msg, ptr))
    #define LOGGERI(mode, msg, i) (fprintf(stderr, "%s   |   %15lu   |   %14p   | %-s:%-32sl. %-3d\t| %s (%d)\n", mode,\
            pthread_self(), thread_self(), __FILE__, __func__, __LINE__, msg, i))
    #define LOGGERLU(mode, msg, l) (fprintf(stderr, "%s   |   %15lu   |   %14p   | %-s:%-32sl. %-3d\t| %s (%lu)\n", mode,\
            pthread_self(), thread_self(), __FILE__, __func__, __LINE__, msg, l))
    #define LOGGERNOSELF(mode, msg) (fprintf(stderr, "%4s   |   %15lu   |   %14s   | %-s:%-32sl. %-3d\t| %s\n", mode, pthread_self(),\
            "", __FILE__, __func__, __LINE__, msg))
    #define LOGGERLUNOSELF(mode, msg, l) (fprintf(stderr, "%s   |   %15lu   |   %14s   | %-s:%-32sl. %-3d\t| %s (%lu)\n", mode,\
            pthread_self(), "", __FILE__, __func__, __LINE__, msg, l))
    #define ERR(msg) (LOGGER("ERR", msg))
    #define ERRP(msg, ptr) (LOGGERP("ERR", msg, ptr))
    #define ERRI(msg, i) (LOGGERI("ERR", msg, i))
    #define ERRLU(msg, l) (LOGGERLU("ERR", msg, l))
    #define ERRNOSELF(msg) (LOGGERNOSELF("ERR", msg))
    #define ERRLUNOSELF(msg) (LOGGERLUNOSELF("ERR", msg, l))
#endif

#if LOG_MODE >= 2
#define WARN(msg) (LOGGER("WARN", msg))
#define WARNP(msg, ptr) (LOGGERP("WARN", msg, ptr))
#define WARNI(msg, i) (LOGGERI("WARN", msg, i))
#define WARNLU(msg, l) (LOGGERLU("WARN", msg, l))
#define WARNNOSELF(msg) (LOGGERNOSELF("WARN", msg))
#define WARNLUNOSELF(msg, l) (LOGGERLUNOSELF("WARN", msg, l))
#endif

#if LOG_MODE >= 3
#define INFO(msg) (LOGGER("INFO", msg))
#define INFOP(msg, ptr) (LOGGERP("INFO", msg, ptr))
#define INFOI(msg, i) (LOGGERI("INFO", msg, i))
#define INFOLU(msg, l) (LOGGERLU("INFO", msg, l))
#define INFONOSELF(msg) (LOGGERNOSELF("INFO", msg))
#define INFOLUNOSELF(msg, l) (LOGGERLUNOSELF("INFO", msg, l))
#endif

#if LOG_MODE >= 4
#define DEBUG(msg) (LOGGER("DEBG", msg))
#define DEBUGP(msg, ptr) (LOGGERP("DEBG", msg, ptr))
#define DEBUGI(msg, i) (LOGGERI("DEBG", msg, i))
#define DEBUGLU(msg, l) (LOGGERLU("DEBG", msg, l))
#define DEBUGNOSELF(msg) (LOGGERNOSELF("DEBG", msg))
#define DEBUGLUNOSELF(msg, l) (LOGGERLUNOSELF("DEBG", msg, l))
#endif

#if LOG_MODE >= 5
#define TRACE(msg) (LOGGER("TRAC", msg))
#define TRACEP(msg, ptr) (LOGGERP("TRAC", msg, ptr))
#define TRACEI(msg, i) (LOGGERI("TRAC", msg, i))
#define TRACELU(msg, l) (LOGGERLU("TRAC", msg, l))
#define TRACENOSELF(msg) (LOGGERNOSELF("TRC", msg))
#define TRACELUNOSELF(msg, l) (LOGGERLUNOSELF("TRC", msg, l))
#endif

#ifndef LOG_HEADER
#define LOG_HEADER
#endif
#ifndef ERR
#define ERR(msg)
#define ERRP(msg, ptr)
#define ERRI(msg, i)
#define ERRLU(msg, l)
#define ERRNOSELF(msg)
#define ERRLUNOSELF(msg, l)
#endif
#ifndef WARN
#define WARN(msg)
#define WARNP(msg, ptr)
#define WARNI(msg, i)
#define WARNLU(msg, l)
#define WARNNOSELF(msg)
#define WARNLUNOSELF(msg, l)
#endif
#ifndef INFO
#define INFO(msg)
#define INFOP(msg, ptr)
#define INFOI(msg, i)
#define INFOLU(msg, l)
#define INFONOSELF(msg)
#define INFOLUNOSELF(msg, l)
#endif
#ifndef DEBUG
#define DEBUG(msg)
#define DEBUGP(msg, ptr)
#define DEBUGI(msg, i)
#define DEBUGLU(msg, l)
#define DEBUGNOSELF(msg)
#define DEBUGLUNOSELF(msg, l)
#endif
#ifndef TRACE
#define TRACE(msg)
#define TRACEP(msg, ptr)
#define TRACEI(msg, i)
#define TRACELU(msg, l)
#define TRACENOSELF(msg)
#endif

#endif //CODE_LOG_H
