#ifndef GLOBALS_H
#define GLOBALS_H

#include "queue.h"
#include <stdlib.h>
#include <semaphore.h>

/**
 * Lock used by kernel threads when they read or write into the run queue.
 */
int runq_lock = 0;

/**
 * A semaphore to wake up a thread blocked in kernel_thread_next_user_thread(),
 * when a new user thread is available in the runq.
 */
sem_t runq_length;

/**
 * The exiting context, used when the last thread exits
 */
struct context end_context;


/**
 * A structure that contains all information concerning a thread, and that can be linked with other threads
 */
struct thread_entry {
    struct context context;             ///< The context, its stack, etc (@see struct context)
    struct thread_entry* joining_thread;///< A thread that waits this thread for a join, or NULL.
    int exited;                         ///< 1 if exited, 0 otherwise.
    void* ret_val;                      ///< The thread_exit() return value (used if the joining thread calls
                                        ///< thread_join() AFTER the thread_exit() of this thread).
    int status_lock;                    ///< Lock to prevent kernel threads to read/write `exited` & `ret_val;`
    STAILQ_ENTRY(thread_entry) entries; ///< Pointer used to link STAILQ entries.
};

/**
 * The queue that contains the threads waiting to be run
 */
STAILQ_HEAD(thread_queue, thread_entry) runq =
        STAILQ_HEAD_INITIALIZER(runq);

#endif //GLOBALS_H
