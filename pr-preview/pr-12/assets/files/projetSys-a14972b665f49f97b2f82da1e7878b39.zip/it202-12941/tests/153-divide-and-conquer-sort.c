#include <stdlib.h> 
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include "thread.h"

struct table {
    int* number_collection;
    int length;
};

void print_table(struct table *t);
static void* divide_and_conquer_sort(void* number_collection);

static void *sort_half(void *args){
    void **data = (void **) args;
    struct table *dest = (struct table *) data[0];
    struct table *src  = (struct table *) data[1];
    size_t *start      = (size_t *)       data[2];
    for(size_t i = 0; i < src->length && i < dest->length; i++){
        dest->number_collection[i] = src->number_collection[*start + i];
    }
    divide_and_conquer_sort(dest);
    return NULL;
}

void sort_both(struct table *table, struct table *table_left, struct table *table_right){
    size_t i  = 0;
        size_t i1 = 0;
        size_t i2 = 0;
        while( i < table->length ){
            assert(i == i1 + i2);
            assert(i1 <= table_left->length );
            assert(i2 <= table_right->length );
            if( i1 == table_left->length ){
                assert( i2 < table_right->length);
                table->number_collection[i] = table_right->number_collection[i2];
                i2++;
                i++;
            }else if(i2 == table_right->length) 
            {
                assert(i1 < table_left->length);
                table->number_collection[i] = table_left->number_collection[i1];
                i1++;
                i++;
            }else{
                assert(i1 < table_left->length && i2 < table_right->length );
                if(table_left->number_collection[i1] <= table_right->number_collection[i2] ){
                    table->number_collection[i] = table_left->number_collection[i1];
                    i1++;
                    i++;
                }else{
                    table->number_collection[i] = table_right->number_collection[i2];
                    i2++;
                    i++;
                }
            }
            assert( (i < 2 ) || ( table->number_collection[i - 2] <= table->number_collection[i - 1]) );
        }
}

static void* divide_and_conquer_sort(void* number_collection) {

    struct table* table = (struct table*) number_collection;

    thread_t th1, th2;

    int err;
    struct table table_left, table_right;
    size_t start1, start2;

    if( table->length == 2) {
        if(table->number_collection[1] < table->number_collection[0]){
            int temp = table->number_collection[0];
            table->number_collection[0] = table->number_collection[1];
            table->number_collection[1] = temp;
            assert(table->number_collection[0] < table->number_collection[1]);
        }
        assert(table->number_collection[0] <= table->number_collection[1]);
        return NULL;
    }
    else if ( table->length == 1) {
        return NULL;
    }
    else {
        table_left.length = (table->length+1) / 2;
        start1 = 0;
        table_left.number_collection = malloc(sizeof(int) * table_left.length );
        void *args1[3] = {&table_left, table, &start1};

        table_right.length = table->length / 2;
        start2 = table_left.length;
        table_right.number_collection = malloc(sizeof(int) * table_right.length );
        void *args2[3] = {&table_right, table, &start2};

        err = thread_create(&th1, sort_half, args1);
        assert(!err);

        err = thread_create(&th2, sort_half, args2);
        assert(!err);

        err = thread_join(th1, NULL);
        assert(!err);
        err = thread_join(th2, NULL);
        assert(!err);

        sort_both(table, &table_left, &table_right);

        free(table_left.number_collection);
        free(table_right.number_collection);

    }
    
    return NULL;

}

void print_table(struct table *t){
    printf("[ ");
    for(size_t i = 0; i < t->length - 1; i++){
        printf("%d, ", t->number_collection[i]);
    }
    printf("%d ]\n", t->number_collection[t->length - 1]);

}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("arguments manquants: nombre d'elements a trier\n");
        return -1;
    }

    int nb_elements = atoi(argv[1]);


    srand( time ( NULL ));

    struct table table;
    table.number_collection = malloc(sizeof(int)*nb_elements);
    table.length = nb_elements;
    int dispersion = 10;

    for(int i = 0; i < nb_elements ; i++) {
        table.number_collection[i] = rand() % (nb_elements * dispersion + 1);
    }

    print_table(&table);
    divide_and_conquer_sort(&table);
    print_table(&table);
   

   free(table.number_collection);

   return EXIT_SUCCESS;

}