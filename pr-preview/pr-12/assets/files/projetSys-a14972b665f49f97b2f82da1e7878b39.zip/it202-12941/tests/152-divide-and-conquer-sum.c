#include <stdlib.h> 
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include "thread.h"

struct table {
    int* number_collection;
    int length;
};

static void* divide_and_conquer_sum(void* number_collection) {

    struct table* table = (struct table*) number_collection;

    thread_t th1, th2;

    int err;
    struct table table_left, table_right;
    void *retval_left, *retval_right;

    if( table->length == 2) {
        return (void*) ( (unsigned long) (table->number_collection[0] + (unsigned long) table->number_collection[1]));
    }
    else if ( table->length == 1) {
        return (void*) ( (unsigned long) table->number_collection[0]);
    }
    else {
        table_left.number_collection = table->number_collection;
        table_left.length = (table->length+1) / 2;

        table_right.number_collection = table->number_collection + (table->length + 1) /2;
        table_right.length = table->length/2;

        err = thread_create(&th1, divide_and_conquer_sum, (void*) &table_left);
        assert(!err);

        err = thread_create(&th2, divide_and_conquer_sum, (void*) &table_right);
        assert(!err);

        err = thread_join(th1, &retval_left);
        assert(!err);
        err = thread_join(th2, &retval_right);
        assert(!err);
    }
    
    return (void*) ( (unsigned long) retval_left + (unsigned long) retval_right);

}

unsigned long glouton_sum(struct table *t){
    int *number_collection = t->number_collection;
    int length = t->length;
    unsigned long s = 0;
    for(int i = 0; i < length ; i ++ ){
        s += number_collection[i];
    }
    return s;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("arguments manquants: nombre d'elements a trier\n");
        return -1;
    }

    int nb_elements = atoi(argv[1]);


    srand( time ( NULL ));

    struct table table;
    table.number_collection = malloc(sizeof(int)*nb_elements);
    table.length = nb_elements;
    int dispersion = 10;

    for(int i = 0; i < nb_elements ; i++) {
        table.number_collection[i] = rand() % (nb_elements * dispersion + 1);
    }

   unsigned long sum = (unsigned long) divide_and_conquer_sum(&table);

   printf("%lu\n", sum);
   // assert( sum == glouton_sum(&table)); // To check that the computed sum is correct

   free(table.number_collection);

   return EXIT_SUCCESS;

}