# Projet de systèmes d'exploitation

## Auteurs

- Simon BULLOT
- Antoine CHARTRON
- Rémi DEHENNE
- Sébastien DELPEUCH
- Aymeric FERRON

## Description du projet

Dans le cadre du projet système du semestre 8 à l’ENSEIRB-MATMECA, nous sommes amenés à implémenter une bibliothèque de threads en espace utilisateur.

## Fonctionnalités implémentées

Notre projet se décompose en trois parties disposé sur trois branches distinctes de git.

- La branche `sequential` contient l'implémentation basique de notre bibliothèque de gestion de thread. Elle ne contient aucun des mécanismes avancée et est une version séquentielle (Modèle 1:M).
- Sur la branche `deadlock-signals`, se trouve l'implémentation séquentielle de la bibliothèque à laquelle le mécanisme de détection de thread et d'envoi de signaux est ajouté.
- Sur la branche `master`, on retrouve l'implémentation de notre bibliothèque qui utilise le parallélisme et supporte ainsi les machines multi-cœurs. Cette version ne contient pas les mécanismes avancés de la branche deadlock-signals. Cette version est actuellement celle qui passe les tests de performance du leaderboard.

## Règles de compilations

- `make` (cible par défaut) : Compile la bibliothèque et les tests.
- `make check` : Exécute les tests.
- `make valgrind` : Exécute les tests sous valgrind avec les options --leak-check=full --show-reachable=yes --track-origins=yes.
- `make pthreads` : Compile les tests pour les pthreads.
- `make graphs` : Lance le système pour tracer les graphes.
- `make install` : Installe les fichiers compilés dans le répertoire install avec l'architecture souhaitée.
- `make clean` : Nettoie le répertoire des fichiers de compilation et d'exécutions.
- `make build/bin/<test_name>.log` : Compile, exécute le test et affiche les logs (nécessite un `make clean` auparavant).
- `make build/bin/<test_name>.gdb` : Compile et exécute le test avec gdb.
- `make build/bin/<test_name>.run` : Compile et exécute le test.

## Génération de graphes

Pour générer tous les graphes à la suite il suffit de faire `make graphs` dans votre terminal. Cependant, il est aussi possible de paramétrer plus précisément les graphes qu'on souhaite obtenir.

En lançant directement `python3 graphs_launcher.py` il est possible de passer les options comme `-t` pour préciser le nombre de thread qu'on souhaite utiliser ou bien `-f` pour indiquer le numéro du test qu'on souhaite exécuter. Une option `-h` permet d'afficher les différentes options.

A noter que le script change un peu selon la branche depuis laquelle vous le lancez. Sur la branche master, le script changera de branche afin de faire une comparaison entre une exécution séquentielle et une exécution parallèle. Sur la branche deadlock-signals, certains tests ont des comportements particuliers, car nous ne pouvons pas faire une comparaison avec pthread qui ne gère pas tous les interblocages.
