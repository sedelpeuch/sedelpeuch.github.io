# Projet de compilation - ENSEIRB-MATMECA, Filière Informatique, Semestre 7 - 2020/2021

__Auteurs :__ Sébastien Delpeuch et Aymeric Ferron

## Objectif

L'objectif de ce projet est de créer un compilateur pour un mini langage nommé MyC vers
du code à 3 adresses.

L'objectif que nous nous fixons pour ce projet est de réaliser a minima la version "passable"
(ie les points 1 à 4). Nous avons également réalisé le point 5 concernant le
typage avec des int.

Des pistes pour la réalisation du point 5 sont présentées dans la partie Spécification.

## Rendu pour le 15/11/20

Lors de l'analyse lexicale, première étape de la compilation, le compilateur lit
les lexèmes et transfert des données vers l'analyseur sémantique. Ce transfert
de données est possible grâce à une variable `yylval.val`.

Il convient dans un premier temps de choisir la structure de cette variable
afin que toutes les informations dont nous avons besoin puissent transiter
de l'analyseur lexical vers l'analyseur sémantique dans un premier temps,
puis remonter à l'intérieur même de l'analyseur sémantique.

Notre structure est la suivante :

```
  struct ATTRIBUTE {
    char * name;
    int int_val;
    float float_val;
    type type_val;
    int reg_number;


    // Complément

    int bool_val;
    char* cond_label;
    char* loop_label;
    };
```

Nous allons maintenant détailler l'utilité des différents champs de notre
structure :

+ `char * name` permet de stocker le nom d'une variable pour l'afficher ;  
+ `int int_val` permet de stocker la valeur entière d'un attribut ;
+ `float float_value` permet de stocker la valeur flottante d(un attribut) ;
+ `type type_val` permet de connaître le type de l'attribut et de savoir si
sa valeur est stockée dans le champ entier, flottant ou booléen ;
+ `int reg_number` permet de connaître le numéro de registre de l'attribut ;
+ `int bool_val` permet de stocker la valeur booléenne de l'attribut (ainsi, on différencie une valeur entière d'une valeur booléenne pour plus de clarté dans notre code) ;
+ `char * cond_label` permet de stocker la valeur syntaxique des structures
conditionnelles ("if" et "else") ;
+ `char * loop_label` permet de stocker la valeur syntaxique des structures
de boucle (`while`). Nous l'avons séparé de `cond_label` pour permettre l'ajout
potentiel d'autres boucles comme la boucle `for`.

Cette structure nous permettra de réaliser la version passable. Pour cette version de base, on ignore encore le typage et on estime que MyC ne compile que des `int`.

Afin de rendre la structure plus modulable dans la seconde partie de notre projet, nous prévoyons de réaliser les modifications suivantes afin de factoriser la valeur de l'attribut :

```
struct ATTRIBUTE {
  char * name;
  int reg_number;
  char * cond_label;
  char * loop_label;
  struct VALUE value;
  type type_val;
}
```

```
struct VALUE{
  int int_val;
  float float_val;
  int bool_val;
};
```

La structure `ATTRIBUTE` conserve de manière identique les champs `name`, `reg_number`,
`cond_label`, `loop_label` et `type_val`. Nous lui rajoutons une structure
`VALUE` qui permet de factoriser les différentes valeurs typées. L'idée est de
pouvoir trouver via `type_val` le type de la variable, puis via la structure
`VALUE` lui associer la bonne valeur.

Pour le point numéro 6 concernant les fonctions récursives, il faudra ajouter à
notre structure un moyen d'avoir une pile. Cette implémentation ne sera réalisée
que si
nous arrivons à valider les 5 premiers points. En conséquence nous n'avons pour
l'instant pas établi la structure `ATTRIBUTE` adéquate.

## Rendu Final 

### Spécification

À la fin du projet notre compilateur est capable de réaliser les actions
suivantes

- [x] un mécanisme de déclarations explicite de variables,
- [x] des expression arithmétiques arbitraire de type calculatrice,
- [x] des lectures ou écritures mémoires via des affectations avec variables utilisateurs ou pointeurs,
- [x] des structures de contrôles classiques (conditionelles et boucles),
- [x] un mécanisme de typage simple comprenant notamment des entiers int et des pointeurs int *,
- [ ] définitions et appels de fonctions récursives,

Quelques changements ont été effectués par rapport à la spécification du
15/11/2020. Notre structure `Attribute` a pris la forme suivant 

``` c
struct ATTRIBUTE {
  // Un résumé détaillé est fourni dans README.md (à la racine du projet)
  char * name; // stocke nom de l'attribut
  type type_val; // stocke le type de l'attribut
  int reg_number; // stocke le numéro de registre de l'attribut
  int int_val;
  int pointer_level;
  /* other attribute's fields can goes here */
  int lab_number;
};
```

La structure `VALUE` n'a finalement pas été implémentée puisque jugée inutile.
En revanche nous avons rajouté deux attributs, `pointer_level` permettant de
connaître le degrés de la structure et l'attribut `lab_number` fonctionnant
comme `reg_number` mais nous permettant d'attribuer un numéro de label à la
structure. Cela nous est utile pour les conditions, les boucles, les returns ...

L'architecture de notre dépôt respecte les consignes données, le dossier `src`
contient les sources du compilateur, le dossier `test` contient différents
différents scénarios de test dans des fichiers `.myc`. Le dossier `build`
contient les fichiers issus de la construction du compilateur. À la racine on
trouve l'exécutable `myc` dont nous détaillons le fonctionnement dans la section suivante.

### Mode d'emploi 

Nous mettons à votre disposition plusieurs moyens d'utiliser notre compilateur.
Dans un premier temps vous pouvez l'utiliser de manière libre en tapant la
commande `./myc`, à ce moment là vous pourrez taper du code myc, puis après un
`Ctrl-D` le code sera compilé et le résultat sera disponible dans `tst/cfile.c`
et `tst/hfile.c`. 

Si vous ne souhaitez pas écrire votre propre code myc vous pouvez dans un
premier temps lancer tous les scénarios de test et la compilation des fichiers
.c sortant via gcc en utilisant la commande `make run_test`

Finalement vous pouvez utiliser la commande `./compil <file>` prenant en entrée le nom
d'un fichier à compiler et produisant, à l'aide de notre compilateur myc les
fichiers compilés et l'exécutable issue
de la compilation via gcc de ces fichiers.

#### Attention !
Pour utiliser le script il est nécessaire de respecter les conditions
suivantes : 
+ le fichier que vous passez en argument ne doit pas être à la racine (on
préféra le mettre dans `tst/`)
+ lorsque vous appelez le script il est nécessaire de NE PAS préciser
l'extension, pour un fichier `tst/mytest.myc` on appellera le script ainsi
`./compil tst/mytest`. Cela produira dans le dossier `tst/` les fichiers
`mytest.c`, `mytest.h` puis compilera via gcc ces fichiers dans un exécutable `mytest`. 

### Remarques
