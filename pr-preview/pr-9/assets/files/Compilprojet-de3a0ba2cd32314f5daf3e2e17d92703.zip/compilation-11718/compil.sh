#!/usr/bin/env bash

make
./myc $1
gcc -o $1 $1.c
