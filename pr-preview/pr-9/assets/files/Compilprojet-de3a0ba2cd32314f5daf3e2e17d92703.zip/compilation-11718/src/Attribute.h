/*
 *  Attribute.h
 *
 *  Created by Janin on 10/2019
 *  Copyright 2018 LaBRI. All rights reserved.
 *
 *  Module for a clean handling of attibutes values
 *
 */

#ifndef ATTRIBUTE_H
#define ATTRIBUTE_H

typedef enum {INT, FLOAT} type;

/************************************************************************/
/* LIVRABLE I : Vous pouvez consulter le README.md où nous avons placé  */
/* les détails de l'implémentation de la structure ATTRIBUTE et où nous */
/* expliquons la structure VALUE et pourquoi elle est en commentaire.   */
/************************************************************************/

//Création d'une énumération pour déterminer si notre attribut est une Variable, structure, fonction
/* struct VALUE{ */
/*   int int_val; */
/*   float float_val; */
/*   int bool_val; */
/* }; */

struct ATTRIBUTE {
  // Un résumé détaillé est fourni dans README.md (à la racine du projet)
  char * name; // stocke nom de l'attribut
  type type_val; // stocke le type de l'attribut
  int reg_number; // stocke le numéro de registre de l'attribut
  int int_val;
  int pointer_level;
  char* pointer;
  /* other attribute's fields can goes here */
  int lab_number;
};


typedef struct ATTRIBUTE * attribute;

attribute new_attribute ();
/* returns the pointeur to a newly allocated (but uninitialized) attribute value structure */
char* thetype(attribute a);
void thelevel(attribute a);

#endif
