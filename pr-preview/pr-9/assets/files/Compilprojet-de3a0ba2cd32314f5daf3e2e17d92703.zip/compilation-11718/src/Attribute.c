#include "Attribute.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
attribute new_attribute () {
  attribute r;
  r  = malloc (sizeof (struct ATTRIBUTE));
  return r;
};

char* thetype(attribute a){
  switch(a->type_val){
    case INT:
      return "int";
      break;
    default :
      return "void";
      break;
  }
}

void thelevel(attribute a){
  a->pointer="";
  char buff[16];
  for (int i=1; i<=a->pointer_level; i++) {
    a->pointer="*";
  }
}
