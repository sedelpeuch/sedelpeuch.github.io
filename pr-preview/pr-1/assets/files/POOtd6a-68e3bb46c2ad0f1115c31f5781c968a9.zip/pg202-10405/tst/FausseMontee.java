package tec;

final class FausseMontee extends PassagerAbstrait {
    protected FausseMontee(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        super(nom, destination, comportNouvArret);

        // Toutes les combinaisons sont autorisees
    }

    @Override
    protected void choixPlaceMontee(Vehicule v){}
}