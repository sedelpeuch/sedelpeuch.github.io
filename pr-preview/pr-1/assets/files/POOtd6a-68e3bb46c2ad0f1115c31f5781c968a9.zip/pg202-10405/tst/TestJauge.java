package tec;

import java.lang.reflect.InvocationTargetException;

final class TestJauge {
    public void testDansIntervalle() {
        int max = 67899;
        int depart = 100;

        Jauge j = new Jauge(max, depart);
        assert j.estVert(): "La jauge n'est pas verte dans l'intervalle";
        assert !j.estRouge(): "La jauge est rouge dans l'intervalle";
    }

    public void testSuperieurIntervalle() {
        int max = 255;
        int depart = 258;

        Jauge j = new Jauge(max, depart);
        assert !j.estVert(): "La jauge est verte alors que depart > max";
        assert j.estRouge(): "La jauge n'est pas rouge alors que depart > max";
    }

    public void testEgalMaxIntervalle() {
        int max = 255;
        int depart = 255;

        Jauge j = new Jauge(max, depart);
        assert !j.estVert(): "La jauge est verte alors que depart == max";
        assert j.estRouge(): "La jauge n'est pas rouge alors que depart == max";;
    }

    public void testDepartNegatif() {
        int max = 255;
        int depart = -1;

        Jauge j = new Jauge(max, depart);
        assert !j.estVert(): "La jauge est verte quand depart negatif";
        assert !j.estRouge(): "La jauge est rouge quand depart negatif";
    }

    public void testDepartNul() {
        int max = 255;
        int depart = 0;

        Jauge j = new Jauge(max, depart);
        assert j.estVert(): "La jauge n'est pas verte alors que depart = " + depart;
        assert !j.estRouge(): "La jauge est pas rouge alors que depart = 0" + depart;
    }

    public void testIncrementerDansIntervalle() {
        int max = 5;
        int depart = 1;

        Jauge j = new Jauge(max, depart);
        j.incrementer();
        assert j.estVert(): "La jauge n'est pas verte dans l'intervalle";
        assert !j.estRouge(): "La jauge est rouge dans l'intervalle";
    }

    public void testIncrementerDepassementIntervalle() {
        int max = 5;
        int depart = 4;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++) {
            j.incrementer();
            assert !j.estVert(): "La jauge est toujours verte en dépassant l'intervalle";
            assert j.estRouge(): "La jauge n'est pas rouge en dépassant l'intervalle";
        }
    }

    public void testIncrementerAtteindreIntervalle() {
        int max = 5;
        int depart = -1;

        Jauge j = new Jauge(max, depart);
        j.incrementer();

        assert j.estVert() : "La jauge n'est verte en entrant dans l'intervalle";
        assert !j.estRouge() : "La jauge est rouge en entrant dans l'intervalle";
    }

    public void testIncrementerInferieurIntervalle() {
        int max = 5;
        int depart = -4;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.incrementer()) {
            assert !j.estVert() : "La jauge est verte sous l'intervalle";
            assert !j.estRouge() : "La jauge est rouge sous l'intervalle";
        }
    }

    public void testIncrementerSuperieurIntervalle() {
        int max = 5;
        int depart = 6;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.incrementer()) {
            assert !j.estVert() : "La jauge est verte au-dessus de l'intervalle";
            assert j.estRouge() : "La jauge n'est pas rouge au-dessus de l'intervalle";
        }
    }

    public void testDecrementerDansIntervalle() {
        int max = 5;
        int depart = 2;

        Jauge j = new Jauge(max, depart);
        j.decrementer();
        assert j.estVert(): "La jauge n'est pas verte dans l'intervalle";
        assert !j.estRouge(): "La jauge est rouge dans l'intervalle";
    }

    public void testDecrementerSortirIntervalle() {
        int max = 707;
        int depart = 0;

        Jauge j = new Jauge(max, depart);
        j.decrementer();
        assert !j.estVert(): "La jauge est verte en sortant de l'intervalle";
        assert !j.estRouge(): "La jauge est rouge sous l'intervalle";
    }

    public void testDecrementerAtteindreIntervalle() {
        int max = 55;
        int depart = 55;

        Jauge j = new Jauge(max, depart);
        j.decrementer();

        assert j.estVert() : "La jauge n'est verte en entrant dans l'intervalle";
        assert !j.estRouge() : "La jauge est rouge en entrant dans l'intervalle";
    }

    public void testDecrementerInferieurIntervalle() {
        int max = 5;
        int depart = -4;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.decrementer()) {
            assert !j.estVert() : "La jauge est verte sous l'intervalle";
            assert !j.estRouge() : "La jauge est rouge sous l'intervalle";
        }
    }

    public void testDecrementerSuperieurIntervalle() {
        int max = 5;
        int depart = 10;

        Jauge j = new Jauge(max, depart);

        int nb_iter = 3;

        for (int i = 0; i < nb_iter; i++, j.decrementer()) {
            assert !j.estVert() : "La jauge est verte au-dessus de l'intervalle";
            assert j.estRouge() : "La jauge n'est pas rouge au-dessus de l'intervalle";
        }
    }


    public static void main(String[] args) throws InvocationTargetException, NoSuchMethodException,
            InstantiationException, IllegalAccessException {
        TestRunner.runTestsForClass(TestJauge.class);
    }
}
