package tec;


import java.lang.reflect.InvocationTargetException;

final class TestMonteeRepos extends TestPassagerAbstrait {
    public static void main(String[] args) throws IllegalAccessException,
            InstantiationException, NoSuchMethodException, InvocationTargetException, CombinaisonInterditeException {
        // Test Runner
        // tec.TestRunner.runTestsForClass(TestMonteeRepos.class);
        // Solution TD5/TD6
        TestPassagerAbstrait.runTests(tec.TestMonteeRepos.class);
    }

    protected PassagerAbstrait creerPassager(String nom, int destination, ComportementNouvelArret cna)
            throws CombinaisonInterditeException {
        return new MonteeRepos(nom, destination, cna);
    }
    
    public TestMonteeRepos() {}

    public void testCombinaisonsAutorisees() throws CombinaisonInterditeException {
        PassagerAbstrait p;
        // Les comportements ArretPrudent, ArretAgoraphobe, ArretCalme et ArretPoli
        // doivent être autorisés
        p = creerPassager("xxx", 3, ArretPrudent.getInstance());
        p = creerPassager("xxx", 3, ArretAgoraphobe.getInstance());
        p = creerPassager("xxx", 3, ArretCalme.getInstance());
        p = creerPassager("xxx", 3, ArretPoli.getInstance());
    }

    public void testCombinaisonsInterdites() throws CombinaisonInterditeException {
        PassagerAbstrait p;

        try {
            // Le comportement ArretNerveux doit lever une exception
            p = creerPassager("xxx", 3, ArretNerveux.getInstance());
            assert false;
        } catch(CombinaisonInterditeException e) {
        }
    }

    /* Etat apres instanciation
     * Un seul cas
     */
    public void testInstanciation() throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("xxx", 3, FauxArret.getInstance());

        assert false == p.estAssis();
        assert false == p.estDebout();
        assert true == p.estDehors();
    }

    /* Interaction a la montee
     * Trois cas
     *  - des places assises et debout
     *  - pas de place assise
     *  - aucune place.
     */
    public void testChoixPlaceMontee() throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("yyy", 5, FauxArret.getInstance());

        FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);
        p.monterDans(faux);

        assert "monteeDemanderAssis" == getLastLog(faux) : "assis";

        faux = new FauxVehicule(FauxVehicule.DEBOUT);
        p.monterDans(faux);

        assert "monteeDemanderDebout" == getLastLog(faux) : "debout";

        faux = new FauxVehicule(FauxVehicule.PLEIN);
        p.monterDans(faux);

        assert 0 == faux.logs.size() : "pas de place";
    }

    /* Interaction a un arret
     * Deux cas
     *  - numero d'arret < a la destination
     *  - numero d'arret >= a la destination
     */
    public void testChoixPlaceArret() throws CombinaisonInterditeException{ }

    public void testGestionEtat() throws CombinaisonInterditeException {
      this.gestionEtat(FauxArret.getInstance());
    }
}
