package tec;

public interface Transport {
    /**
     * Indique au véhicule l'arrêt suivant en déclenche sur chaque passager
     * la méthode arretSuivant().
     */
    public void allerArretSuivant();
}
