package tec;

public final class ArretNerveux extends ComportementNouvelArret{
    private static ArretNerveux ARRET_NERVEUX = null;

    private ArretNerveux(){}

    public static ComportementNouvelArret getInstance() {
        if (ARRET_NERVEUX == null) {
            ARRET_NERVEUX = new ArretNerveux();
        }
        return ARRET_NERVEUX;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (p.estDebout() && v.aPlaceAssise()) {
            v.arretDemanderAssis(p);
        } else if (p.estAssis() && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        }
    }
}
