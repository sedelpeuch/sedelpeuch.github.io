package tec;

public final class ArretPrudent extends ComportementNouvelArret{
    private static ArretPrudent ARRET_PRUDENT = new ArretPrudent();

    private ArretPrudent(){}

    public static ComportementNouvelArret getInstance() {
        if(ARRET_PRUDENT == null) {
            ARRET_PRUDENT = new ArretPrudent();
        }
        return ARRET_PRUDENT;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (distanceDestination < 3
                && p.estAssis()
                && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        } else if (distanceDestination > 5
                && p.estDebout()
                && v.aPlaceAssise()) {
            v.arretDemanderAssis(p);
        }
    }
}
