package tec;

public final class ArretCalme extends ComportementNouvelArret{
    private static ArretCalme ARRET_CALME = null;

    private ArretCalme(){}

    public static ComportementNouvelArret getInstance() {
        if (ARRET_CALME == null) {
            ARRET_CALME = new ArretCalme();
        }
        return ARRET_CALME;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {}
}