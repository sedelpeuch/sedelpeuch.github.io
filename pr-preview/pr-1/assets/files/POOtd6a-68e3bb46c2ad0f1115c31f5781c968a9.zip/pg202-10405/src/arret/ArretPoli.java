package tec;

public final class ArretPoli extends ComportementNouvelArret{
    private static ArretPoli ARRET_POLI = null;

    private ArretPoli(){}

    public static ComportementNouvelArret getInstance() {
        if (ARRET_POLI == null) {
            ARRET_POLI = new ArretPoli();
        }
        return ARRET_POLI;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (p.estAssis()
                && !v.aPlaceAssise()
                && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        }
    }
}
