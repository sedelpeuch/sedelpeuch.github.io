package tec;

public final class ArretAgoraphobe extends ComportementNouvelArret{
    private static ArretAgoraphobe ARRET_AGORAPHOBE = null;

    private ArretAgoraphobe(){}

    public static ComportementNouvelArret getInstance() {
        if (ARRET_AGORAPHOBE == null) {
            ARRET_AGORAPHOBE = new ArretAgoraphobe();
        }
        return ARRET_AGORAPHOBE;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (!v.aPlaceAssise() && !v.aPlaceDebout()) {
            v.arretDemanderSortie(p);
        }
    }
}