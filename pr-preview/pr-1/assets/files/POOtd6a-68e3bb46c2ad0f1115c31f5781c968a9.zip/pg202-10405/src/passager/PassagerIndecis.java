package tec;

/**
 * @deprecated Depuis la version 6.0a/b, PassagerIndecis
 * doit être remplacé par une instanciation new MonteeSportif(nom, destination, ArretNerveux.getInstance()).
 */
@Deprecated
public final class PassagerIndecis extends MonteeSportif {
    public PassagerIndecis(String nom, int destination) throws CombinaisonInterditeException {
        super(nom, destination, ArretNerveux.getInstance());
    }
}
