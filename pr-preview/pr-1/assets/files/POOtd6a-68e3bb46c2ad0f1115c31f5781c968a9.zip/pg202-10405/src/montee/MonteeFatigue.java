package tec;

public class MonteeFatigue extends PassagerAbstrait {
    public MonteeFatigue(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        super(nom, destination, comportNouvArret);

        // Interdit la combinaison MonteeFatigue -- ArretNerveux
        if (comportNouvArret == ArretNerveux.getInstance()) {
            throw new CombinaisonInterditeException(this, comportNouvArret);
        }
    }

    @Override
    protected void choixPlaceMontee(Vehicule v){
        if (v.aPlaceAssise()) {
            v.monteeDemanderAssis(this);
        }
    }
}
