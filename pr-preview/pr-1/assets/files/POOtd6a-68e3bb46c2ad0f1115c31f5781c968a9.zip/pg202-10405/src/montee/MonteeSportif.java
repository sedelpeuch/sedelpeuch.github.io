package tec;

public class MonteeSportif extends PassagerAbstrait {
    public MonteeSportif(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        super(nom, destination, comportNouvArret);

        // Interdit la combinaison MonteeSportif -- ArretCalme
        if(comportNouvArret == ArretCalme.getInstance()) {
            throw new CombinaisonInterditeException(this, comportNouvArret);
        }
    }

    @Override
    protected void choixPlaceMontee(Vehicule v) {
        if (v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }
}
