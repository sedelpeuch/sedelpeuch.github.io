package tec;

public class MonteeRepos extends PassagerAbstrait {
    public MonteeRepos(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        super(nom, destination, comportNouvArret);

        // Interdit la combinaison MonteeRepos -- ArretNerveux
        if(comportNouvArret == ArretNerveux.getInstance()) {
            throw new CombinaisonInterditeException(this, comportNouvArret);
        }
    }

    @Override
    protected void choixPlaceMontee(Vehicule v) {
        if (v.aPlaceAssise()) {
            v.monteeDemanderAssis(this);
        } else if (v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }
}
