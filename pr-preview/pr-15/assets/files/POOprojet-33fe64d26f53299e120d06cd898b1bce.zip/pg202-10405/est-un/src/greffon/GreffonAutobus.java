package tec;

import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

public final class GreffonAutobus extends Autobus {

    private final List<CollecteVehicule> collectes;


    public GreffonAutobus(int nbPlacesAssises, int nbPlacesDebout) {
        super(nbPlacesAssises, nbPlacesDebout);
        this.collectes = new ArrayList<>();
    }


    public final void ajouterCollecte(CollecteVehicule collecte) {
        collectes.add(collecte.clone());
    }

    @Override
    public final void allerArretSuivant() {
        for (CollecteVehicule c : collectes) {
            try {
                c.changerArret();
            } catch (IOException e) {
                throw new IllegalStateException("String to open file in CollecteFichier is incorrect", e);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        super.allerArretSuivant();
    }

    @Override
    public final void monteeDemanderAssis(Passager p) {
        super.monteeDemanderAssis(p);
        for (CollecteVehicule c : collectes) {
            c.uneEntree(p);
        }
    }

    @Override
    public final void monteeDemanderDebout(Passager p) {
        super.monteeDemanderDebout(p);
        for (CollecteVehicule c : collectes) {
            c.uneEntree(p);
        }
    }

    @Override
    public void arretDemanderSortie(Passager p) {
        super.arretDemanderSortie(p);
        for (CollecteVehicule c : collectes) {
            c.uneSortie(p);
        }
    }

    public void afficherCollectes() {
        for (CollecteVehicule c : collectes) {
            c.afficher();
        }
    }


}
