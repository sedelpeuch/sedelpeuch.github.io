package tec;

public final class TecException extends Exception {
    public TecException(String msg) {
        super(msg);
    }

    public TecException(Throwable cause) {
        super(cause);
    }
}
