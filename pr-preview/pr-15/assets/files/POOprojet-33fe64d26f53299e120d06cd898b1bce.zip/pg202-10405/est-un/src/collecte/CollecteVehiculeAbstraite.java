package tec;

import java.io.IOException;

public abstract class CollecteVehiculeAbstraite implements tec.CollecteVehicule {
    private int nbPsgMontes;
    private int nbPsgDescendus;
    private int nbArretsParcourus;

    protected CollecteVehiculeAbstraite() {
        // Initialisation implicite des attributs
    }

    abstract protected void collecter() throws IOException;

    abstract public CollecteVehicule clone();

    public final void uneEntree(Passager p) {
        nbPsgMontes += 1;
    }

    public final void uneSortie(Passager p) {
        nbPsgDescendus += 1;
    }

    public final void changerArret() throws IOException {
        collecter();
        reset();
        nbArretsParcourus += 1;
    }

    private void reset() {
        nbPsgDescendus = 0;
        nbPsgMontes = 0;
    }

    public void afficher() {
    }

    protected final String formaterCollecte() {
        final String psgMontes = nbPsgMontes > 1
                ? "passagers sont montés"
                : "passager est monté";

        final String psgDescendus = nbPsgDescendus > 1
                ? "passagers sont descendus"
                : "passager est descendu";


        return String.format("%d %s.\n%d %s.\nArrêt numéro %d.",
                nbPsgMontes, psgMontes, nbPsgDescendus, psgDescendus, nbArretsParcourus);
    }
}