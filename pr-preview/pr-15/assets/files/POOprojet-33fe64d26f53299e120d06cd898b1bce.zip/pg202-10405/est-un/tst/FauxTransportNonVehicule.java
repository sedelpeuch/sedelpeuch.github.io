package tec;

final class FauxTransportNonVehicule implements Transport {
    public void allerArretSuivant() {
    }
}
