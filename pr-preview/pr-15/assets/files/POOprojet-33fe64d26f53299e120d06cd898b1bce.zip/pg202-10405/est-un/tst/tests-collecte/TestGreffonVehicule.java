package tec;

import java.lang.reflect.InvocationTargetException;

final class TestGreffonVehicule {

    /**
     * Etat apres instanciation
     */
    public void testInstanciation() {

        GreffonAutobus greffon = new GreffonAutobus(3, 4);
    }

    /**
     * Gestion de l'ajout d'une collecte.
     * <p>
     * Vérifier qu'une collecte est bien crée lors de l'ajout d'une collecte
     * au greffon.
     */
    public void testAjoutCollecte() {
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.VIDE);

        GreffonAutobus greffon = new GreffonAutobus(3, 4);


        //***************** Ajout collecte *************************
        FausseCollecteVehicule fCol = new FausseCollecteVehicule();

        greffon.ajouterCollecte(fCol);
        assert getLastLog(fCol) == "FausseCollecteVehicule" : "Ajout d'une collecte";

    }

    /**
     * Gestion des messages d'une collecte.
     * <p>
     * Vérifier l'appel aux méthodes de montees et de sortie d'une Collecte par le greffon.
     */
    public void testMsgActionCollecte() {
        FausseCollecteVehicule fCol = new FausseCollecteVehicule();

        GreffonAutobus greffon = new GreffonAutobus(3, 4);
        greffon.ajouterCollecte(fCol);
        FauxPassager fPas = new FauxPassager();
        FauxPassager fPas2 = new FauxPassager();
        //***************** Entree collecte *************************

        greffon.monteeDemanderAssis(fPas);
        assert getLastLog(fCol) == "uneEntree" : "Montee assis demandee";

        greffon.monteeDemanderDebout(fPas2);
        assert getLastLog(fCol) == "uneEntree" : "Montee debout demandee";

        //****************** Sortie Collecte************************************

        greffon.arretDemanderSortie(fPas);
        assert getLastLog(fCol) == "uneSortie" : "Sortie demandee";

        //******************* Aller arret suivant******************************

        greffon.allerArretSuivant();
        assert getLastLog(fCol) == "changerArret" : "Aller arret suivant";

    }

    /**
     * Gestion de l'affichage d'une collecte.
     * <p>
     * Vérifier l'appel à la méthode d'affichage d'une Collecte par le greffon.
     */
    public void testAffichageCollecte() {
        FausseCollecteVehicule fCol = new FausseCollecteVehicule();

        GreffonAutobus greffon = new GreffonAutobus(3, 4);
        greffon.ajouterCollecte(fCol);

        //***************** Affichage collecte *************************

        greffon.afficherCollectes();
        assert getLastLog(fCol) == "afficher" : "Affichage d'une collecte";

    }

    private String getLastLog(FauxVehicule f) {
        return f.logs.get(f.logs.size() - 1);
    }

    private String getLastLog(FausseCollecteVehicule c) {
        return c.logs.get(c.logs.size() - 1);
    }

}
