package tec;

final class TestPosition {
    TestPosition() {
        System.out.print(".");
    }

    public void testEstDehorsCreation() {
        Position pos = Position.creer();
        assert pos.estDehors() : "Devrait être dehors à la création";
        assert !pos.estAssis() : "Ne devrait pas être assis à la création !";
        assert !pos.estDebout() : "Ne devrait pas être debout à la création !";
        assert !pos.estInterieur() : "Ne devrait pas être à l'intérieur à la création !";
    }

    public void testEstAssis() {
        Position pos = Position.creer();
        pos = pos.assis();
        assert !(pos.estDehors()) : "Ne devrait pas être dehors après avoir été mis assis.";
        assert pos.estAssis() : "Devrait être assis après avoir été mis assis";
        assert !pos.estDebout() : "Ne devrait pas être debout après avoir été mis assis";
        assert pos.estInterieur() : "Devrait être à l'intérieur apès avoir été mis assis";
    }

    public void testEstDebout() {
        Position pos = Position.creer();
        pos = pos.debout();
        assert !pos.estDehors() : "Ne devrait pas être dehors après avoir été mis debout.";
        assert !pos.estAssis() : "Ne devrait pas être assis après avoir été mis debout";
        assert pos.estDebout() : "Devrait être debout après avoir été mis debout";
        assert pos.estInterieur() : "Devrait être à l'intérieur après avoir été mis debout";
    }

    public void testEstDehors() {
        Position pos = Position.creer();
        pos = pos.dehors();

        // On passe en position debout pour tester le retour en position dehors
        pos = pos.debout();
        pos = pos.dehors();
        assert pos.estDehors() : "Devrait être dehors après avoir été mis dehors";
        assert !pos.estInterieur() : "Ne devrait pas être à l'intérieur après avoir été mis dehors !";
        assert !pos.estAssis() : "Ne devrait pas être assis après avoir été mis dehors !";
        assert !pos.estDebout() : "Ne devrait pas être debout après avoir été mis dehors !";
    }
}