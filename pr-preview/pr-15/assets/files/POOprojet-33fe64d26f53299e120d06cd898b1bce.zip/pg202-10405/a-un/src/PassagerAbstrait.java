package tec;

abstract class PassagerAbstrait extends Passager implements Usager {
    private String nom;
    private final int destination;
    private Position position;
    private final ComportementNouvelArret comportNouvArret;

    public PassagerAbstrait(String nom, int destination, ComportementNouvelArret comportNouvArret) {
        if (destination < 0) {
            throw new IllegalArgumentException("La destination d'un passager doit être positive ou nulle");
        }

        this.nom = nom;
        this.destination = destination;
        this.position = Position.creer();
        this.comportNouvArret = comportNouvArret;
    }

    final protected int getDestination(int arretCourant) {
        return destination - arretCourant;
    }

    @Override
    final public String nom() {
        return this.nom();
    }

    @Override
    final public boolean estDehors() {
        return position.estDehors();
    }

    @Override
    final public boolean estAssis() {
        return position.estAssis();
    }

    @Override
    final public boolean estDebout() {
        return position.estDebout();
    }

    @Override
    final public void changerEnDehors() {
        position = position.dehors();
    }

    @Override
    final public void changerEnAssis() {
        position = position.assis();
    }

    @Override
    final public void changerEnDebout() {
        position = position.debout();
    }


    /**
     * Permet au passager de monter bord du véhicule `t`, selon sa stratégie de montée.
     * Un passager peut décider de ne pas monter, par exemple si le véhicule est plein (dépend de la stratégie
     * de montée).
     *
     * @throws TecException si le passager est déjà à bord ou que `t` n'implémente pas Vehicule.
     */
    @Override
    final public void monterDans(Transport t) throws TecException {
        if (t instanceof Vehicule) {
            Vehicule b = (Vehicule) t;
            try {
                choixPlaceMontee(b);
            } catch (IllegalArgumentException e) {
                throw new TecException(e);
            }
        } else {
            throw new TecException("Impossible de transtyper `t` de `Transport` en `Vehicule`");
        }
    }

    @Override
    final public void nouvelArret(Vehicule v, int numeroArret) {
        if (destination <= numeroArret) {
            v.arretDemanderSortie(this);
        } else {
            choixPlaceArret(v, numeroArret);
        }
    }

    @Override
    public String toString() {
        return this.nom + " " + position.toString();
    }

    protected abstract void choixPlaceMontee(Vehicule v);

    protected void choixPlaceArret(Vehicule v, int arret) {
        this.comportNouvArret.choixPlaceArret(this, v, this.getDestination(arret));
    }

}
