package tec;

public class CombinaisonInterditeException extends Exception {

    public CombinaisonInterditeException() {
    }

    public CombinaisonInterditeException(Passager p, ComportementNouvelArret c) {
        super(String.format("Combinaison interdite : %s - %s",
                p.getClass().getCanonicalName(),
                c.getClass().getCanonicalName()));
    }
}
