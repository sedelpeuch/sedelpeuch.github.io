package tec;

public final class ArretCalme extends ComportementNouvelArret {
    private static ArretCalme arretCalme = null;

    private ArretCalme() {
    }

    public static ComportementNouvelArret getInstance() {
        if (arretCalme == null) {
            arretCalme = new ArretCalme();
        }
        return arretCalme;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
    }
}