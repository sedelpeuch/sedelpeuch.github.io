package tec;

public interface Usager {
    /**
     * Fait monter (ou non) le passager, selon sa stratégie de montée.
     *
     * @param t le véhicule dans lequel le passager peut monter.
     * @throws TecException si le passager est déjà à bord ou que `t` n'implémente pas Vehicule.
     */
    public void monterDans(Transport t) throws TecException;
}
