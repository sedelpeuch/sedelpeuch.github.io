package tec;

public final class ArretNerveux extends ComportementNouvelArret {
    private static ArretNerveux arretNerveux = null;

    private ArretNerveux() {
    }

    public static ComportementNouvelArret getInstance() {
        if (arretNerveux == null) {
            arretNerveux = new ArretNerveux();
        }
        return arretNerveux;
    }

    @Override
    void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
        if (p.estDebout() && v.aPlaceAssise()) {
            v.arretDemanderAssis(p);
        } else if (p.estAssis() && v.aPlaceDebout()) {
            v.arretDemanderDebout(p);
        }
    }
}
