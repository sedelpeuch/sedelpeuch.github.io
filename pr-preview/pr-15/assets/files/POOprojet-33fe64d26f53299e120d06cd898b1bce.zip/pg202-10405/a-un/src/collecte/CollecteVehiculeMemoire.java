package tec;

import java.util.List;
import java.util.ArrayList;
import java.io.PrintStream;

public final class CollecteVehiculeMemoire extends CollecteVehiculeAbstraite {

    /*
     *  Collection de chaînes de caractères correspondant à la collecte
     *  d'informations.
     */
    private final List<String> historique;

    public CollecteVehiculeMemoire() {
        super();
        this.historique = new ArrayList<>();
    }

    final public void collecter() {
        this.historique.add(formaterCollecte());
    }

    /*
     * Fonction d'affichage pour la collecte
     */
    final public void afficher() {
        this.afficher(System.out);
    }

    final void afficher(PrintStream ps) {
        for (String info : this.historique) {
            ps.println(info);
        }
    }

    public CollecteVehicule clone() {
        return new CollecteVehiculeMemoire();
    }
}
