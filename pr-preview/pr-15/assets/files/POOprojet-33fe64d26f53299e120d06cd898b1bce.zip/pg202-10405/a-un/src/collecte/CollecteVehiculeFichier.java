package tec;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public final class CollecteVehiculeFichier extends CollecteVehiculeAbstraite {
    private final String filepath;
    private FileWriter fileWriter = null;

    public CollecteVehiculeFichier(String filepath) {
        super();
        this.filepath = filepath;
        /*
         * Le fileWriter n'est pas ouvert par le constructeur
         * pour n'ouvrir le fichier que si on souhaite reellement ecrire dedans.
         * Les instances crees par le client n'ont pas a ouvrir de fichier
         * car seuls les clones stockes dans GreffonAutobus appellent collecter() et ecrivent
         * dans un fichier.
         */

        /*
         * Le fichier est ferme automatiquement lorsque la CollecteVehicule
         * est detruite car FileWriter implemente AutoCloseable.
         */
    }

    public CollecteVehicule clone() {
        return new CollecteVehiculeFichier(this.filepath);
    }

    private void ouvrirFileWriter() throws IOException {
        if (this.fileWriter == null) {
            this.fileWriter = new FileWriter(this.filepath);
        }
    }

    protected final void collecter() throws IOException {
        ouvrirFileWriter();
        PrintWriter pw = new PrintWriter(this.fileWriter);
        pw.println(formaterCollecte());
        pw.flush();
    }
}