package tec;

/**
 * @deprecated Depuis la version 6.0a/b, PassagerStandard
 * doit être remplacé par une instanciation new MonteeRepos(nom, destination, ArretCalme.getInstance()).
 */
@Deprecated
public final class PassagerStandard extends MonteeRepos {
    public PassagerStandard(String nom, int destination) throws CombinaisonInterditeException {
        super(nom, destination, ArretCalme.getInstance());
    }
}
