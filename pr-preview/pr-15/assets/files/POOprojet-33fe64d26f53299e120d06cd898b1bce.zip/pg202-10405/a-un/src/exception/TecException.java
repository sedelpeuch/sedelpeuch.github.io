package tec;

final public class TecException extends Exception {
    public TecException(String msg) {
        super(msg);
    }

    public TecException(Throwable cause) {
        super(cause);
    }
}
