package tec;

public interface CollecteVehicule extends Cloneable {
    void uneEntree(Passager p);

    void uneSortie(Passager p);

    void changerArret() throws Exception;

    void afficher();

    CollecteVehicule clone();
}
