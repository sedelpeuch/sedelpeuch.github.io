package tec;

public class MonteeSportif extends PassagerAbstrait {
    public MonteeSportif(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        super(nom, destination, comportNouvArret);

        // Interdit la combinaison MonteeSportif -- ArretCalme
        if (comportNouvArret == ArretCalme.getInstance()) {
            throw new CombinaisonInterditeException(this, comportNouvArret);
        } else if (destination < 0) {
            throw new IllegalArgumentException(String.format("Valeur destination négative. " +
                    "Reçu : \"%s\", Valeurs acceptées : destination >= 0.\n", destination));
        }
    }

    @Override
    protected void choixPlaceMontee(Vehicule v) {
        if (v.aPlaceDebout()) {
            v.monteeDemanderDebout(this);
        }
    }
}
