import tec.*;

import java.io.IOException;


class SimpleCollecteAUn {

    /*
     * Affiche l'etat des deux instances passees en parametre.
     * La methode println(Object x) de la classe PrintWriter
     * declenche la methode toString() sur l'objet passe
     * en parametre (x.toString()) et affiche la chaine
     * de caracteres obtenue..
     */
    static private void deboguerEtat(Transport t, Usager p) {
        System.out.println(p);
        System.out.println(t);
    }


    static public void main(String[] args) throws CombinaisonInterditeException, TecException, IOException {
        Transport t = new Autobus(3, 4);
        CollecteVehicule collecte = new CollecteVehiculeFichier("test.out");
        Greffon serenity = new Greffon(t, collecte);
        serenity.ajouterCollecte(new CollecteVehiculeMemoire());
        Usager kaylee = new MonteeRepos("Kaylee", 5, ArretCalme.getInstance());
        Usager jayne = new MonteeSportif("Jayne", 6, ArretNerveux.getInstance());
        Usager inara = new MonteeFatigue("Inara", 7, ArretPrudent.getInstance());

        //0
        System.out.println(serenity);

        serenity.allerArretSuivant();
        //1
        kaylee.monterDans(serenity);

        System.out.println(serenity);
        System.out.println(kaylee);

        serenity.allerArretSuivant();
        //2
        jayne.monterDans(serenity);

        System.out.println(serenity);
        System.out.println(kaylee);
        System.out.println(jayne);

        serenity.allerArretSuivant();
        //3
        inara.monterDans(serenity);

        System.out.println(serenity);
        System.out.println(kaylee);
        System.out.println(jayne);
        System.out.println(inara);

        serenity.allerArretSuivant();
        //4
        System.out.println(serenity);
        System.out.println(kaylee);
        System.out.println(jayne);
        System.out.println(inara);

        serenity.allerArretSuivant();
        //5
        System.out.println(serenity);
        System.out.println(kaylee);
        System.out.println(jayne);
        System.out.println(inara);

        serenity.allerArretSuivant();
        //6
        System.out.println(serenity);
        System.out.println(kaylee);
        System.out.println(jayne);
        System.out.println(inara);

        serenity.allerArretSuivant();
        //7
        System.out.println(serenity);
        System.out.println(kaylee);
        System.out.println(jayne);
        System.out.println(inara);
        serenity.allerArretSuivant();

        serenity.afficherCollectes();
    }
}
