package tec;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class Greffon extends Vehicule implements Transport {

    private final CollecteVehicule collecte;
    private Vehicule vehicule;


    public Greffon(Transport t, CollecteVehicule c) {
        this.collecte = c.clone();

        if (t instanceof Vehicule) {
            vehicule = (Vehicule) t;
        } else {
            throw new IllegalArgumentException("t doit hériter de Vehicule");
        }
    }

    public final void ajouterCollecte(CollecteVehicule collecte) {
        Greffon g = new Greffon((Transport) this.vehicule, collecte);
        this.vehicule = g;
    }

    @Override
    public void allerArretSuivant() {
        this.allerArretSuivant(this);
    }

    @Override
    public void allerArretSuivant(Vehicule autobus) {
        Transport t = (Transport) vehicule;
        t.allerArretSuivant(autobus);
        try {
            collecte.changerArret();
        } catch (IOException e) {
            throw new IllegalStateException("String to open file in CollecteFichier is incorrect", e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    boolean aPlaceAssise() {
        return vehicule.aPlaceAssise();
    }

    @Override
    boolean aPlaceDebout() {
        return vehicule.aPlaceDebout();
    }

    @Override
    void monteeDemanderAssis(Passager p) {
        vehicule.monteeDemanderAssis(p);
        collecte.uneEntree(p);
    }

    @Override
    void monteeDemanderDebout(Passager p) {
        vehicule.monteeDemanderDebout(p);
        collecte.uneEntree(p);
    }

    @Override
    void arretDemanderDebout(Passager p) {
        vehicule.arretDemanderDebout(p);
    }

    @Override
    void arretDemanderAssis(Passager p) {
        vehicule.arretDemanderAssis(p);
    }

    @Override
    void arretDemanderSortie(Passager p) {
        vehicule.arretDemanderSortie(p);
        collecte.uneSortie(p);
    }

    public void afficherCollectes() {
        if (vehicule instanceof Greffon) {
            Greffon greffon = (Greffon) vehicule;
            greffon.afficherCollectes();
        }
        collecte.afficher();
    }
}
