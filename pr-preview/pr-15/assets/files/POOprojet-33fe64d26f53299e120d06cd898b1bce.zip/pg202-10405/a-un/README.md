# Programmation Orientée Objet : Transports en Commun

Simulation de transports en commun, réalisé dans le cadre des modules « Programmation Orientée Objet »
et « Projet de Programmation Orientée Objet » à l'ENSEIRB-MATMECA (2020-2021).
Le sujet est disponible à l'adresse <http://georgy.vvv.enseirb-matmeca.fr/PG202-203/>.

## Démarrage

Les instructions suivantes vous permettent d'obtenir une copie du projet sur votre machine.

### Prérequis

Pour lancer ce programme, vous devez disposer d'un Java Development Toolkit (JDK) et d'un Java Runtime Environment (JRE)
en version 7 ou plus.

### Installation

Tout d'abord, il est nécessaire de cloner le projet, puis de se déplacer dans les répertoires `pg202-10405/est-un` ou
`pg202-10405/a-un`.

```
git clone https://<YOUR_LOGIN>@thor.enseirb-matmeca.fr/git/pg202-10405
cd pg202-10405/est-un # ou pg202-10405/a-un
```

Il peut alors être compilé et exécuté avec :

```sh
make
```

La règle de compilation par défaut compile les fichiers sans greffon (plugin) et exécute le client
`SimpleSansCollecte.class`. Puis, les fichiers sont compilés à nouveau en incluant un service de collecte
(logs), pour exécuter un client qui utilise ce service (`SimpleCollecteEstUn.class` / `SimpleCollecteAUn.class`).
À l'exécution, le client affiche des logs sur la sortie standard, ainsi qu'un journal `testCollecteVehiculeFichier.out`
dans le répertoire `build/`.

Alternativement, les commandes de construction suivantes peuvent être appelées :

```sh
make build              # Compile les sources sans la collecte
make build-collecte     # Compile les sources avec la collecte
make run                # Compile les sources sans la collecte et exécute SimpleSansCollecte.class
make run-collecte       # Compile les sources avec la collecte et exécute SimpleCollecteEstUn.class / SimpleCollecteAUn.class
make test               # Compile toutes les sources et tests, puis lance les tests
make build-tests        # Compile toutes les sources et tests
make run-tests          # Compile toutes les sources et tests, puis lance les tests (identique à `test`) 
make clean              # Supprime le répertoire de construction (`build/`)
```

## Tests

Les tests peuvent être compilés et exécutés avec la règle `test` :

```sh
make test
```

## Technologies utilisées

* [Java](https://www.java.com) - Langage utilisé
* [GNU Make](https://www.gnu.org/software/make/) - Outil de construction automatique

## Gestion de versions

La [plateforme Thor](https://thor.enseirb-matmeca.fr/ruby/) de l'ENSEIRB-MATMECA est utilisé pour le versionnement
de code.


## Auteurs

* **Rémi Dehenne** -- [rdehenne@enseirb-matmeca.fr](mailto:rdehenne@enseirb-matmeca.fr)

* **Sébastien Delpeuch** -- [sedelpeuch@enseirb-matmeca.fr](mailto:sedelpeuch@enseirb-matmeca.fr)

* **Aymeric Ferron** -- [ayferron@enseirb-matmeca.fr](mailto:ayferron@enseirb-matmeca.fr)

* **Tom Moënne-Loccoz** -- [tmoennelocco@enseirb-matmeca.fr](mailto:tmoennelocco@enseirb-matmeca.fr)

* **Aurélien Moinel** -- [amoinel001@enseirb-matmeca.fr](mailto:amoinel001@enseirb-matmeca.fr)
