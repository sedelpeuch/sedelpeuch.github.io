package tec;

final class FauxArret extends ComportementNouvelArret {
    private static FauxArret FAUX_ARRET = null;

    private FauxArret() {
    }

    static ComportementNouvelArret getInstance() {
        if (FAUX_ARRET == null) {
            FAUX_ARRET = new FauxArret();
        }
        return FAUX_ARRET;
    }

    @Override
    public void choixPlaceArret(Passager p, Vehicule v, int distanceDestination) {
    }
}