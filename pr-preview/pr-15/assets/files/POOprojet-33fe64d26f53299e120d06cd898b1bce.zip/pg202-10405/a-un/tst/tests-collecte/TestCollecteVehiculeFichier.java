package tec;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;

final class TestCollecteVehiculeFichier {
    String stringFichier = "testCollecteVehiculeFichier.out";
    Path cheminFichier = Paths.get(stringFichier);

    private void supprimerFichier() throws IOException, DirectoryNotEmptyException, IOException {
        try {
            Files.delete(cheminFichier);
        } catch (NoSuchFileException ignored) {
        }
    }

    private String lireFichier() throws IOException {
        try {
            return new String(Files.readAllBytes(cheminFichier));
        } catch (NoSuchFileException e) {
            throw new AssertionError("Le fichier " + cheminFichier + " est manquant.\n", e);
        } // Les autres exceptions sont propagees
    }

    public void testCollecteSansChangerArret() throws IOException {
        supprimerFichier();
        CollecteVehiculeFichier cvf = new CollecteVehiculeFichier(stringFichier);

        // --- On ne fait rien ---

        // --- Le fichier de collecte ne doit pas etre cree ---
        File f = new File(stringFichier);
        assert !f.exists() : "Le fichier de collecte ne doit pas etre cree si changerArret()" +
                " n'est pas appelee.";
    }

    public void testCollecteChangerArretAucunPassager() throws IOException {
        supprimerFichier();
        CollecteVehiculeFichier cvf = new CollecteVehiculeFichier(stringFichier);

        // --- Aucun passager ne se deplace ---
        cvf.changerArret();


        String contenuFichier = lireFichier();

        String expected = String.format("%d passager est monté.\n" +
                "%d passager est descendu.\nArrêt numéro %d.\n", 0, 0, 0);

        assert contenuFichier.equals(expected) : "La chaine ecrite par la collecte apres" +
                " changement d'arret est incorrecte.";
    }

    public void testCollectePassagersMontesPremierArret() throws Exception {
        supprimerFichier();
        CollecteVehiculeFichier cvf = new CollecteVehiculeFichier(stringFichier);

        // --- On fait monter des passagers ---
        cvf.uneEntree(new FauxPassager());
        cvf.uneEntree(new FauxPassager());
        cvf.uneEntree(new FauxPassager());
        cvf.changerArret();

        String contenuFichier = lireFichier();

        String expected = String.format("%d passagers sont montés.\n" +
                "%d passager est descendu.\nArrêt numéro %d.\n", 3, 0, 0);

        assert contenuFichier.equals(expected) : "La chaine ecrite par la collecte apres" +
                " changement d'arret est incorrecte.";
    }

    public void testCollectePassagersDescendusPremierArret() throws Exception {
        supprimerFichier();
        CollecteVehiculeFichier cvf = new CollecteVehiculeFichier(stringFichier);

        // --- On fait descendre des passagers ---
        cvf.uneSortie(new FauxPassager());
        cvf.uneSortie(new FauxPassager());
        cvf.uneSortie(new FauxPassager());
        cvf.uneSortie(new FauxPassager());
        cvf.changerArret();

        String contenuFichier = lireFichier();

        String expected = String.format("%d passager est monté.\n" +
                "%d passagers sont descendus.\nArrêt numéro %d.\n", 0, 4, 0);

        assert contenuFichier.equals(expected) : "La chaine ecrite par la collecte apres" +
                " la descente de passagers est incorrecte";
    }


    public void testCollectePassagersMonteesDescentesDifferentsArrets() throws Exception {
        String expectedStr0 = String.format("%d passager est monté.\n" +
                "%d passagers sont descendus.\nArrêt numéro %d.\n", 1, 3, 0);

        String expectedStr1 = expectedStr0 + String.format("%d passagers sont montés.\n" +
                "%d passagers sont descendus.\nArrêt numéro %d.\n", 2, 2, 1);

        String expectedStr2 = expectedStr1 + String.format("%d passager est monté.\n" +
                "%d passager est descendu.\nArrêt numéro %d.\n", 1, 0, 2);

        CollecteVehiculeFichier cvf = new CollecteVehiculeFichier(stringFichier);
        supprimerFichier();

        {
            // --- Arret 0 ---
            cvf.uneEntree(new FauxPassager());
            cvf.uneSortie(new FauxPassager());
            cvf.uneSortie(new FauxPassager());
            cvf.uneSortie(new FauxPassager());
            cvf.changerArret();

            // --- Collecte ---
            String contenuCollecte = lireFichier();

            assert contenuCollecte.equals(expectedStr0) : "La chaine ecrite par la collecte a " +
                    "l'arret 0 est incorrecte";
        }

        {
            // --- Arret 1 ---
            cvf.uneEntree(new FauxPassager());
            cvf.uneSortie(new FauxPassager());
            cvf.uneSortie(new FauxPassager());
            cvf.uneEntree(new FauxPassager());

            cvf.changerArret();

            // --- Collecte ---
            String contenuCollecte = lireFichier();

            assert contenuCollecte.equals(expectedStr1) : "La chaine ecrite par la collecte a " +
                    "l'arret 1 est incorrecte";
        }

        {
            // --- Arret 2 ---
            cvf.uneEntree(new FauxPassager());
            cvf.changerArret();

            // --- Collecte ---
            String contenuCollecte = lireFichier();

            assert contenuCollecte.equals(expectedStr2) : "La chaine ecrite par la collecte a " +
                    "l'arret 2 est incorrecte";
        }
    }
}
