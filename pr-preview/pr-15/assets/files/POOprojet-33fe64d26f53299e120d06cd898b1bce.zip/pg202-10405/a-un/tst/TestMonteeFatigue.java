package tec;

import java.lang.reflect.InvocationTargetException;

final class TestMonteeFatigue extends TestPassagerAbstrait {
    protected PassagerAbstrait creerPassager(String nom, int destination, ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException {
        return new MonteeFatigue(nom, destination, comportNouvArret);
    }

    public TestMonteeFatigue() {
    }

    public void testInstanciation() throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("xxx", 3, FauxArret.getInstance());

        assert false == p.estAssis();
        assert false == p.estDebout();
        assert true == p.estDehors();
    }

    public void testCombinaisonsAutorisees() throws CombinaisonInterditeException {
        PassagerAbstrait p;
        // Les comportements ArretPrudent, ArretAgoraphobe, ArretCalme et ArretPoli
        // doivent être autorisés
        p = creerPassager("xxx", 3, ArretPrudent.getInstance());
        p = creerPassager("xxx", 3, ArretAgoraphobe.getInstance());
        p = creerPassager("xxx", 3, ArretCalme.getInstance());
        p = creerPassager("xxx", 3, ArretPoli.getInstance());
    }

    public void testCombinaisonsInterdites() {
        PassagerAbstrait p;

        try {
            // Le comportement ArretNerveux doit lever une exception
            p = creerPassager("xxx", 3, ArretNerveux.getInstance());
            assert false;
        } catch (CombinaisonInterditeException e) {
        }
    }

    public void testChoixPlaceMontee() throws CombinaisonInterditeException, TecException {
        ComportementNouvelArret cna = FauxArret.getInstance();
        PassagerAbstrait p = creerPassager("xxx", 3, cna);
        FauxVehicule faux;

        faux = new FauxVehicule(FauxVehicule.VIDE);
        p.monterDans(faux);
        assert "monteeDemanderAssis" == getLastLog(faux) : "assis";

        faux = new FauxVehicule(FauxVehicule.DEBOUT);
        p.monterDans(faux);
        assert 0 == faux.logs.size() : "debout";

        faux = new FauxVehicule(FauxVehicule.PLEIN);
        p.monterDans(faux);

        assert 0 == faux.logs.size() : "pas de place";
    }

    public void testChoixPlaceArret() throws CombinaisonInterditeException {

    }

    public void testGestionEtat() throws CombinaisonInterditeException {
        this.gestionEtat(FauxArret.getInstance());
    }
}
