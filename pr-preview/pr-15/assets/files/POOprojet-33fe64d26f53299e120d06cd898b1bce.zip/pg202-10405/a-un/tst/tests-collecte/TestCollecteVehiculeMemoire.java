package tec;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

final class TestCollecteVehiculeMemoire {
    public void testCollecteVide() throws Exception {
        CollecteVehiculeMemoire cvm = new CollecteVehiculeMemoire();
        ByteArrayOutputStream fauxFluxSortie = new ByteArrayOutputStream();
        PrintStream fauxFlux = new PrintStream(fauxFluxSortie);

        // --- On ne fait rien ---

        // --- Collecte
        cvm.afficher(fauxFlux);
        String contenuCollecte = fauxFluxSortie.toString("UTF8");
        // pas besoin de lancer fauxFluxSortie.close(), car aucun effet (cf. doc ByteArrayOutputStream)

        fauxFlux.close(); // BufferedWriter peut quand meme etre ferme pour appeler close() son instance
        // OutputStreamWriter (dans tous les cas, BufferedWriter implemente AutoCloseable,
        // donc ce close() n'est pas obligatoire)

        assert contenuCollecte.equals("") : "La chaine affichee par une collecte vide doit etre vide";
    }

    public void testCollectePassagersMontesPremierArret() throws Exception {
        CollecteVehiculeMemoire cvm = new CollecteVehiculeMemoire();
        ByteArrayOutputStream fauxFluxSortie = new ByteArrayOutputStream();
        PrintStream fauxFlux = new PrintStream(fauxFluxSortie);

        // --- On fait monter des passagers ---
        cvm.uneEntree(new FauxPassager());
        cvm.uneEntree(new FauxPassager());
        cvm.uneEntree(new FauxPassager());
        cvm.changerArret();


        // --- Collecte ---
        cvm.afficher(fauxFlux);
        String contenuCollecte = fauxFluxSortie.toString("UTF8");
        fauxFlux.close();

        String expected = String.format("%d passagers sont montés.\n" +
                "%d passager est descendu.\nArrêt numéro %d.\n", 3, 0, 0);

        assert contenuCollecte.equals(expected) : "La chaine affichee par la collecte apres" +
                " la montee de passagers est incorrecte";
    }

    public void testCollectePassagersDescendusPremierArret() throws Exception {
        CollecteVehiculeMemoire cvm = new CollecteVehiculeMemoire();
        ByteArrayOutputStream fauxFluxSortie = new ByteArrayOutputStream();
        PrintStream fauxFlux = new PrintStream(fauxFluxSortie);

        // --- On fait descendre des passagers ---
        cvm.uneSortie(new FauxPassager());
        cvm.uneSortie(new FauxPassager());
        cvm.uneSortie(new FauxPassager());
        cvm.uneSortie(new FauxPassager());
        cvm.changerArret();


        // --- Collecte ---
        cvm.afficher(fauxFlux);
        String contenuCollecte = fauxFluxSortie.toString("UTF8");
        fauxFlux.close();

        String expected = String.format("%d passager est monté.\n" +
                "%d passagers sont descendus.\nArrêt numéro %d.\n", 0, 4, 0);

        assert contenuCollecte.equals(expected) : "La chaine affichee par la collecte apres" +
                " la descente de passagers est incorrecte";
    }

    public void testCollectePassagersMonteesDescentesDifferentsArrets() throws Exception {
        CollecteVehiculeMemoire cvm = new CollecteVehiculeMemoire();

        String expectedStr0 = String.format("%d passager est monté.\n" +
                "%d passagers sont descendus.\nArrêt numéro %d.\n", 1, 3, 0);

        String expectedStr1 = expectedStr0 + String.format("%d passagers sont montés.\n" +
                "%d passagers sont descendus.\nArrêt numéro %d.\n", 2, 2, 1);

        String expectedStr2 = expectedStr1 + String.format("%d passager est monté.\n" +
                "%d passager est descendu.\nArrêt numéro %d.\n", 0, 0, 2);

        {
            ByteArrayOutputStream fauxFluxSortie = new ByteArrayOutputStream();
            PrintStream fauxFlux = new PrintStream(fauxFluxSortie);

            // --- Arret 0 ---
            cvm.uneEntree(new FauxPassager());
            cvm.uneSortie(new FauxPassager());
            cvm.uneSortie(new FauxPassager());
            cvm.uneSortie(new FauxPassager());
            cvm.changerArret();


            // --- Collecte ---
            cvm.afficher(fauxFlux);
            String contenuCollecte = fauxFluxSortie.toString("UTF8");
            fauxFlux.close();

            assert contenuCollecte.equals(expectedStr0) : "La chaine affichee par la collecte a" +
                    " l'arret 0 est incorrecte";
        }

        {
            ByteArrayOutputStream fauxFluxSortie = new ByteArrayOutputStream();
            PrintStream fauxFlux = new PrintStream(fauxFluxSortie);

            // --- Arret 1 ---
            cvm.uneEntree(new FauxPassager());
            cvm.uneSortie(new FauxPassager());
            cvm.uneSortie(new FauxPassager());
            cvm.uneEntree(new FauxPassager());
            cvm.changerArret();


            // --- Collecte ---
            cvm.afficher(fauxFlux);
            String contenuCollecte = fauxFluxSortie.toString("UTF8");
            fauxFlux.close();

            assert contenuCollecte.equals(expectedStr1) : "La chaine affichee par la collecte a" +
                    " l'arret 1 est incorrecte";
        }

        {
            ByteArrayOutputStream fauxFluxSortie = new ByteArrayOutputStream();
            PrintStream fauxFlux = new PrintStream(fauxFluxSortie);

            // --- Arret 2 ---
            cvm.changerArret();


            // --- Collecte ---
            cvm.afficher(fauxFlux);
            String contenuCollecte = fauxFluxSortie.toString("UTF8");
            fauxFlux.close();

            assert contenuCollecte.equals(expectedStr2) : "La chaine affichee par la collecte a" +
                    " l'arret 2 est incorrecte'";
        }
    }
}
