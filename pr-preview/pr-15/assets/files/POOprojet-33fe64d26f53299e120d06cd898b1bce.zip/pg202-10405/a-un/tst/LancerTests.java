package tec;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

final class LancerTests {
    /**
     * Execute les methodes d'instance et de classe cl commencant par "test"
     *
     * @param cl la classe a tester
     */
    static <T> void lancer(Class<T> cl) throws IllegalAccessException, InstantiationException,
            InvocationTargetException, NoSuchMethodException {
        boolean estMisAssertion = false;
        assert estMisAssertion = true;

        if (!estMisAssertion) {
            System.out.println("Execution impossible sans l'option -ea");
            return;
        }

        int totalTestCount = 0;
        int successTestCount = 0;

        /*
          new_instance() n'est pas appelee sur la classe `cl` directement (deprecie depuis Java 9)
          https://docs.oracle.com/javase/9/docs/api/java/lang/Class.html#newInstance--
        */
        Constructor<T> construct = cl.getDeclaredConstructor();

        Method[] methods = cl.getMethods();

        for (Method m : methods) {
            if (m.getName().startsWith("test")) {
                totalTestCount++;
                try {
                    // Cree une nouvelle instance de cl et appelle la methode m()
                    m.invoke(construct.newInstance());
                    successTestCount++;
                    System.out.print(".");
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace();
                }
            }
        }

        System.out.format("%s %s, total: %d, success: %d, failed: %d\n",
                cl.getName(),
                successTestCount == totalTestCount ? "OK" : "NOK",
                totalTestCount,
                successTestCount,
                totalTestCount - successTestCount);

    }

    public static void main(String[] args) throws Exception {
        for (String className : args) {
            lancer(Class.forName(className));
        }
    }
}
