package tec;

import java.lang.reflect.InvocationTargetException;

final class TestArretCalme extends TestPassagerAbstrait {
    protected PassagerAbstrait creerPassager(String nom, int destination, ComportementNouvelArret cna)
            throws CombinaisonInterditeException {
        if (cna != ArretCalme.getInstance() && cna != null) {
            throw new IllegalArgumentException("Le comportement d'arrêt d'un passager standard doit être ArretCalme");
        }

        return new FausseMontee(nom, destination, ArretCalme.getInstance());
    }

    public TestArretCalme() {
    }

    public void testCombinaisonsAutorisees() throws CombinaisonInterditeException {
    }

    public void testCombinaisonsInterdites() throws CombinaisonInterditeException {
    }

    /* Etat apres instanciation
     * Un seul cas
     */
    public void testInstanciation() throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("xxx", 3, null);

        assert false == p.estAssis();
        assert false == p.estDebout();
        assert true == p.estDehors();
    }

    /* Interaction a la montee
     * Trois cas
     *  - des places assises et debout
     *  - pas de place assise
     *  - aucune place.
     */
    public void testChoixPlaceMontee() throws CombinaisonInterditeException {
    }

    /* Interaction a un arret
     * Deux cas
     *  - numero d'arret < a la destination
     *  - numero d'arret >= a la destination
     */
    public void testChoixPlaceArret() throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("yyy", 5, null);

        FauxVehicule faux = new FauxVehicule(FauxVehicule.VIDE);

        p.nouvelArret(faux, 1);
        assert 0 == faux.logs.size() : "pas a destination";

        p.nouvelArret(faux, 5);
        assert "arretDemanderSortie" == getLastLog(faux) : "destination";
    }

    public void testGestionEtat() throws CombinaisonInterditeException {
        this.gestionEtat(ArretCalme.getInstance());
    }
}
