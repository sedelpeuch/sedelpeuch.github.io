package tec;

/**
 * Classe faussaire pour le test unitaire fonctionnel
 * de PassagerStandard et Greffon
 * <p>
 * Ce faussaire ne declenche pas d'appel aux methodes
 * de PassagerStandard et Greffon.
 * <p>
 * Il ne change pas son etat (la variable d'instance status).
 * C'est le test qui change directement la valeur de cette variable.
 * <p>
 * Il enregistre l'appel aux méthodes qui
 * doivent modifier son etat.
 */
final class FauxVehicule extends Vehicule implements Transport {
    static final byte VIDE = 0;
    static final byte DEBOUT = 1;
    static final byte ASSIS = 2;
    static final byte PLEIN = 4;
    byte status;

    final java.util.List<String> logs = new java.util.LinkedList<String>();

    FauxVehicule() {
        this(VIDE);
    }

    FauxVehicule(byte init) {
        status = init;
    }

    public boolean aPlaceAssise() {
        return status == ASSIS
                || status == VIDE;
    }

    public boolean aPlaceDebout() {
        return status == DEBOUT
                || status == VIDE;
    }

    // Enregistrements des appels effectues par PassagerStandard.
    @Override
    public void monteeDemanderAssis(Passager p) {
        logs.add("monteeDemanderAssis");
    }

    @Override
    public void monteeDemanderDebout(Passager p) {
        logs.add("monteeDemanderDebout");
    }

    @Override
    public void arretDemanderDebout(Passager p) {
        logs.add("arretDemanderDebout");
    }

    @Override
    public void arretDemanderAssis(Passager p) {
        logs.add("arretDemanderAssis");
    }

    @Override
    public void arretDemanderSortie(Passager p) {
        logs.add("arretDemanderSortie");
    }

    @Override
    public void allerArretSuivant() {
    }

    @Override
    public void allerArretSuivant(Vehicule autobus) {
        logs.add("allerArretSuivant");
    }
}
