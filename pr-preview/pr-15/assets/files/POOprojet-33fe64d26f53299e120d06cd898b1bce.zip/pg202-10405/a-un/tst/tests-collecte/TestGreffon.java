package tec;

import java.lang.reflect.InvocationTargetException;

final class TestGreffon {

    /**
     * Etat apres instanciation
     */
    public void testInstanciation() {
        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.VIDE);

        Greffon greffon = new Greffon((Transport) fVec, fCol);
        assert fVec.aPlaceAssise() == true;
        assert fVec.aPlaceDebout() == true;
    }

    /**
     * Gestion des places a la montee.
     * <p>
     * Vérifier les appels aux méthodes de vérification des places disponibles
     * et des montees du Vehicule par le greffon.
     * <p>
     * Vérifier les appels à la méthode de montee de la Collecte par le greffon.
     */
    public void testGestionDemander() {

        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.VIDE);
        FauxPassager fPas = new FauxPassager();

        Greffon greffon = new Greffon((Transport) fVec, fCol);


        //********* Assis *******************************

        assert true == greffon.aPlaceAssise() : "Vehicule vide";

        greffon.monteeDemanderAssis(fPas);
        assert getLastLog(fVec) == "monteeDemanderAssis" : "Montee assis demandee";
        assert getLastLog(fCol) == "uneEntree" : "Montee assis demandee";

        fVec = new FauxVehicule(FauxVehicule.ASSIS);
        greffon = new Greffon((Transport) fVec, fCol);
        assert true == greffon.aPlaceAssise() : "Vehicule à place assise";

        fVec = new FauxVehicule(FauxVehicule.PLEIN);
        greffon = new Greffon((Transport) fVec, fCol);
        assert false == greffon.aPlaceAssise() : "Vehicule plein";


        //*********** Debout ******************************
        fVec = new FauxVehicule(FauxVehicule.VIDE);
        greffon = new Greffon((Transport) fVec, fCol);
        assert true == greffon.aPlaceDebout() : "Vehicule vide";

        greffon.monteeDemanderDebout(fPas);
        assert getLastLog(fVec) == "monteeDemanderDebout" : "Montee debout demandee";
        assert getLastLog(fCol) == "uneEntree" : "Montee debout demandee";

        fVec = new FauxVehicule(FauxVehicule.DEBOUT);
        greffon = new Greffon((Transport) fVec, fCol);
        assert true == greffon.aPlaceDebout() : "Vehicule à place debout";

        fVec = new FauxVehicule(FauxVehicule.PLEIN);
        greffon = new Greffon((Transport) fVec, fCol);
        assert false == greffon.aPlaceDebout() : "Vehicule plein";
    }


    /**
     * Gestion des places à la sortie.
     * <p>
     * Vérifier l'appel à la méthode de sortie d'un véhicule par le greffon.
     * <p>
     * Vérifier les appels à la méthode de sortie de la Collecte par le greffon.
     */
    public void testGestionSortie() {

        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        //*************** Remplir **********************
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.PLEIN);

        Greffon greffon = new Greffon((Transport) fVec, fCol);

        //***************** Sortir *************************
        FauxPassager fPas = new FauxPassager();
        greffon.arretDemanderSortie(fPas);

        assert getLastLog(fVec) == "arretDemanderSortie" : "Sortie demandee";
        assert getLastLog(fCol) == "uneSortie" : "Sortie demandee";
    }

    /**
     * Gestion du changement de places a un arret.
     * <p>
     * Vérifier l'appel aux méthodes d'arrêt d'un Véhicule par le greffon.
     */
    public void testGestionChanger() {

        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        //*************** Remplir **********************
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.PLEIN);

        Greffon greffon = new Greffon((Transport) fVec, fCol);

        //***************** Changer *************************
        FauxPassager fPas = new FauxPassager();

        greffon.arretDemanderAssis(fPas);
        assert getLastLog(fVec) == "arretDemanderAssis" : "Arret assis demandee";

        greffon.arretDemanderDebout(fPas);
        assert getLastLog(fVec) == "arretDemanderDebout" : "Arret debout demandee";

    }

    /**
     * Gestion du changement de places a un arret.
     * <p>
     * Verifier l'appel aux methodes d'arret d'un Vehicule par le greffon.
     * <p>
     * Vérifier les appels à la méthode d'arrêt de la Collecte par le greffon.
     */
    public void testGestionAllerArretSuivant() {

        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.VIDE);

        Greffon greffon = new Greffon((Transport) fVec, fCol);

        //***************** Arret suivant *************************
        greffon.allerArretSuivant();
        assert getLastLog(fVec) == "allerArretSuivant" : "Aller arret suivant";
        assert getLastLog(fCol) == "changerArret" : "Arret assis demandee";

    }

    /**
     * Gestion de l'ajout d'une collecte.
     * <p>
     * Vérifier qu'une collecte est bien crée lors de l'ajout d'une collecte
     * au greffon.
     */
    public void testAjoutCollecte() {
        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.VIDE);

        Greffon greffon = new Greffon((Transport) fVec, fCol);

        //***************** Ajout collecte *************************
        FausseCollecteVehicule fCol2 = new FausseCollecteVehicule();

        greffon.ajouterCollecte(fCol2);
        assert getLastLog(fCol2) == "FausseCollecteVehicule" : "Ajout d'une collecte";

    }

    /**
     * Gestion de l'affichage d'une collecte.
     * <p>
     * Vérifier l'appel à la méthode d'affichage d'une Collecte par le greffon.
     */
    public void testAffichageCollecte() {
        FausseCollecteVehicule fCol = new FausseCollecteVehicule();
        FauxVehicule fVec = new FauxVehicule(FauxVehicule.VIDE);

        Greffon greffon = new Greffon((Transport) fVec, fCol);

        //***************** Affichage collecte *************************

        greffon.afficherCollectes();
        assert getLastLog(fCol) == "afficher" : "Affichage d'une collecte";

    }

    private String getLastLog(FauxVehicule f) {
        return f.logs.get(f.logs.size() - 1);
    }

    private String getLastLog(FausseCollecteVehicule c) {
        return c.logs.get(c.logs.size() - 1);
    }

}
