package tec;

import java.lang.reflect.InvocationTargetException;

final class TestArretNerveux extends TestPassagerAbstrait {
    protected PassagerAbstrait creerPassager(String nom, int destination, ComportementNouvelArret comportNouvelArret)
            throws CombinaisonInterditeException {
        if (comportNouvelArret != ArretNerveux.getInstance() && comportNouvelArret != null) {
            throw new IllegalArgumentException("Le comportement d'arrêt doit être ArretNerveux");
        }

        return new FausseMontee(nom, destination, ArretNerveux.getInstance());
    }

    public TestArretNerveux() {
    }

    public void testCombinaisonsAutorisees() throws CombinaisonInterditeException {
    }

    public void testCombinaisonsInterdites() throws CombinaisonInterditeException {
    }

    /* Etat apres instanciation
     * Un seul cas
     */
    public void testInstanciation() throws CombinaisonInterditeException {
    }

    public void testChoixPlaceMontee() throws CombinaisonInterditeException {
    }

    public void testChoixPlaceArret() throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("a", 4, null);

        /* Premier cas : le passager est assis, demande une place debout et
         * de la place est disponible
         */
        FauxVehicule faux = new FauxVehicule(FauxVehicule.DEBOUT);
        p.changerEnAssis();

        p.choixPlaceArret(faux, 2);

        assert "arretDemanderDebout" == getLastLog(faux) : "debout";

        /* Deuxième cas : le passager est assis, demande une place debout mais
         * il n'y a pas de place
         */
        faux = new FauxVehicule(FauxVehicule.ASSIS);
        p.changerEnAssis();

        p.choixPlaceArret(faux, 2);

        assert 0 == faux.logs.size() : "pas de place debout";

        /* Troisième cas : le passager est debout, demande une place assise et
         * de la place est disponible
         */
        faux = new FauxVehicule(FauxVehicule.ASSIS);
        p.changerEnDebout();

        p.choixPlaceArret(faux, 2);

        assert "arretDemanderAssis" == getLastLog(faux) : "assis";

        /* Quatrième cas : le passager est debout, demande une place assise mais
         * il n'y a pas de place
         */
        faux = new FauxVehicule(FauxVehicule.PLEIN);
        p.changerEnDebout();

        p.choixPlaceArret(faux, 2);

        assert 0 == faux.logs.size() : "pas de place";
    }

    public void testGestionEtat() throws CombinaisonInterditeException {
        this.gestionEtat(ArretNerveux.getInstance());
    }
}
