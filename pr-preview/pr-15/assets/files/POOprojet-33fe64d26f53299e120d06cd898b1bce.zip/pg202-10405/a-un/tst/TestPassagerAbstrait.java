package tec;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

abstract class TestPassagerAbstrait {
    abstract protected PassagerAbstrait creerPassager(String nom, int destination,
                                                      ComportementNouvelArret comportNouvArret)
            throws CombinaisonInterditeException;

    abstract public void testInstanciation() throws CombinaisonInterditeException;

    abstract public void testChoixPlaceMontee() throws CombinaisonInterditeException, TecException;

    abstract public void testChoixPlaceArret() throws CombinaisonInterditeException;

    abstract public void testCombinaisonsAutorisees() throws CombinaisonInterditeException;

    abstract public void testCombinaisonsInterdites() throws CombinaisonInterditeException;


    abstract public void testGestionEtat() throws CombinaisonInterditeException;

    /**
     * Vérifie que la montée d'un passager dans un `Transport` qui n'implémente pas un `Vehicule`
     * lève une `TecException`.
     */
    public void testMonterDansTransportNonVehicule() throws CombinaisonInterditeException {
        Transport t = new FauxTransportNonVehicule();
        Usager u = new FausseMontee("David Goodenough", 5, FauxArret.getInstance());

        try {
            u.monterDans(t);
            assert false : "Exception `TecException` non levée.";
        } catch (TecException ignored) {
        }
    }

    /**
     * Vérifie que la création d'un passager à destination négative lève bien une `IllegalArgumentException`.
     */
    public void testInstanciationDestinationNegative() throws CombinaisonInterditeException {
        try {
            this.creerPassager("Jean-Michel Cameraman", -1, FauxArret.getInstance());
            assert false : "Exception `IllegalArgumentException` non levée.";
        } catch (IllegalArgumentException ignored) {
        }

        try {
            this.creerPassager("Jean-Michel Cameraman", -2, FauxArret.getInstance());
            assert false : "Exception `IllegalArgumentException` non levée.";
        } catch (IllegalArgumentException ignored) {
        }
    }

    /**
     * Gestion des changement d'état.
     * <p>
     * Changer Debout puis Dehors puis assis.
     */
    public void gestionEtat(ComportementNouvelArret cna) throws CombinaisonInterditeException {
        PassagerAbstrait p = creerPassager("yyy", 3, cna);

        p.changerEnDebout();
        assert false == p.estAssis();
        assert true == p.estDebout();
        assert false == p.estDehors();

        p.changerEnDehors();
        assert false == p.estAssis();
        assert false == p.estDebout();
        assert true == p.estDehors();

        p.changerEnAssis();
        assert true == p.estAssis();
        assert false == p.estDebout();
        assert false == p.estDehors();
    }

    protected String getLastLog(FauxVehicule f) {
        return f.logs.get(f.logs.size() - 1);
    }
}
