package tec;

/**
 * Classe faussaire pour le test unitaire fonctionnel
 * de Greffon
 * <p>
 * Ce faussaire ne declenche pas d'appel aux methodes
 * de Greffon.
 * <p>
 * Il enregistre l'appel aux méthodes qui
 * enregistre.
 */
final public class FausseCollecteVehicule implements CollecteVehicule {

    final static java.util.List<String> logs = new java.util.LinkedList<String>();

    FausseCollecteVehicule() {
        logs.add("FausseCollecteVehicule");
    }

    // Enregistrements des appels effectues par Greffon.
    @Override
    public void uneEntree(Passager p) {
        logs.add("uneEntree");
    }

    @Override
    public void uneSortie(Passager p) {
        logs.add("uneSortie");
    }

    @Override
    public void changerArret() throws Exception {
        logs.add("changerArret");
    }

    @Override
    public void afficher() {
        logs.add("afficher");
    }

    @Override
    public CollecteVehicule clone() {
        return new FausseCollecteVehicule();
    }
}
